export interface SocialLink {
  name: string;
  url: string;
}

export interface SoftwareTool {
  name: string;
  level: number; // 0 to 100
  category: "CAD" | "Rendering" | "Adobe" | "Prototyping" | "Other";
}

export interface EducationItem {
  degree: string;
  school: string;
  year: string;
}

export interface ExperienceItem {
  role: string;
  company: string;
  period: string;
  description: string;
}

export interface Profile {
  name: string;
  title: string;
  tagline: string;
  bio: string;
  portraitUrl: string;
  resumeUrl: string;
  email: string;
  location: string;
  socials: SocialLink[];
  software: SoftwareTool[];
  education: EducationItem[];
  experience: ExperienceItem[];
  skills: string[];
}

export interface ProjectSection {
  id: string;
  type:
    | "hero-banner"
    | "rich-text"
    | "image"
    | "image-gallery"
    | "before-after-slider"
    | "video"
    | "embedded-video"
    | "pdf-viewer"
    | "quote"
    | "research-block"
    | "problem-statement"
    | "user-persona"
    | "journey-map"
    | "affinity-diagram"
    | "design-process-timeline"
    | "sketch-gallery"
    | "cad-gallery"
    | "prototype-gallery"
    | "testing-results"
    | "comparison-table"
    | "specifications-table"
    | "reflection"
    | "downloads"
    | "call-to-action"
    | "two-column"
    | "three-column"
    | "full-width-image"
    | "image-text"
    | "video-text"
    | "accordion"
    | "tabs"
    | "carousel"
    | "interactive-timeline";
  content: any;
}

export interface Project {
  id: string;
  title: string;
  category: string;
  year: string;
  description: string;
  heroImage: string;
  featured: boolean;
  status: "published" | "draft";
  role: string;
  timeline: string;
  tools: string[];
  duration: string;
  team: string;
  overview: string;
  problem: string;
  research: string;
  insights: string;
  ideation: string;
  sketches: string[];
  cad: string;
  cadRenders: string[];
  prototype: string;
  prototypePhotos: string[];
  testing: string;
  finalDesign: string;
  reflection: string;
  gallery: string[];
  videoUrl?: string;
  downloadUrl?: string;
  
  // Custom Modular Page Builder properties
  sections?: ProjectSection[];
  subtitle?: string;
  client?: string;
  conclusion?: string;
  seoTitle?: string;
  seoDescription?: string;
  seoKeywords?: string;
  heroVideo?: string;
}

export interface DesignStage {
  id: string;
  title: string;
  description: string;
  details: string[];
}

export interface MediaAsset {
  id: string;
  name: string;
  url: string;
  size: number;
  type: string; // e.g. "image/png", "video/mp4", "application/pdf"
  uploadDate: string;
  projectAssociation?: string; // Project ID
  tags: string[];
  altText?: string;
  caption?: string;
  photographerCredit?: string;
  folder: "Projects" | "Images" | "Videos" | "PDFs" | "Icons" | "Documents" | "Brand Assets" | "Resume";
}

export interface CMSSettings {
  siteName: string;
  analyticsId?: string;
  theme: string;
  seoDescription?: string;
  seoKeywords?: string;
  storageProvider: "local" | "cloudinary" | "supabase" | "s3" | "firebase";
}

export interface CMSAnalytics {
  totalViews: number;
  totalSessions: number;
  recentUploadsCount: number;
  lastUpdated: string;
}

export interface CMSData {
  profile: Profile;
  projects: Project[];
  stages: DesignStage[];
  media?: MediaAsset[];
  settings?: CMSSettings;
  analytics?: CMSAnalytics;
}

import React, { useEffect, useState, useRef, useCallback } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  getCMSData,
  saveCMSData,
  exportCMSDataAsJSON,
} from "./lib/cmsState";
import { CMSData, Project } from "./types";
import CustomCursor from "./components/CustomCursor";
import LoadingScreen from "./components/LoadingScreen";
import FloatingBlob from "./components/FloatingBlob";
import HeroParticles from "./components/HeroParticles";
import TimelineProcess from "./components/TimelineProcess";
import ProjectDetail from "./components/ProjectDetail";
import AdminCMS from "./components/AdminCMS";
import {
  Menu,
  X,
  Settings,
  Mail,
  MapPin,
  ExternalLink,
  ChevronDown,
  ArrowUpRight,
  Maximize2,
  Copy,
  Check,
  Award,
  Sparkles,
  Layers,
  LayoutGrid,
  Briefcase,
  FileText,
  GraduationCap
} from "lucide-react";

export default function App() {
  const [isLoading, setIsLoading] = useState(true);
  const [cmsData, setCmsData] = useState<CMSData | null>(null);
  const [activeProject, setActiveProject] = useState<Project | null>(null);
  const [isAdminOpen, setIsAdminOpen] = useState(false);
  const [isCopied, setIsCopied] = useState(false);
  const [isPortraitToggled, setIsPortraitToggled] = useState(false);

  // Auto-pulse portrait effect on mobile devices where hover interactions are limited
  useEffect(() => {
    let intervalId: any;
    
    const handleCheck = () => {
      const isMobile = window.innerWidth < 1024;
      if (isMobile) {
        if (!intervalId) {
          intervalId = setInterval(() => {
            setIsPortraitToggled((prev) => !prev);
          }, 3500);
        }
      } else {
        if (intervalId) {
          clearInterval(intervalId);
          intervalId = null;
        }
      }
    };

    handleCheck();
    window.addEventListener("resize", handleCheck);
    
    return () => {
      window.removeEventListener("resize", handleCheck);
      if (intervalId) clearInterval(intervalId);
    };
  }, []);

  const handleLoadingComplete = useCallback(() => {
    setIsLoading(false);
  }, []);

  // Scroll Tracking
  const [activeSection, setActiveSection] = useState("hero");
  const [isNavVisible, setIsNavVisible] = useState(true);
  const lastScrollY = useRef(0);

  // Parallax / Interaction state
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });
  const mapCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Load state on mount
  useEffect(() => {
    fetch("/api/cms-data")
      .then(res => {
        if (!res.ok) throw new Error("Could not fetch database from server");
        return res.json();
      })
      .then(data => {
        setCmsData(data);
        saveCMSData(data); // backup in local storage
      })
      .catch(err => {
        console.warn("Backend server offline, falling back to local storage:", err);
        const data = getCMSData();
        setCmsData(data);
      });
  }, []);

  // Sync CMS update helper
  const handleUpdateCMS = (newData: CMSData) => {
    setCmsData(newData);
    saveCMSData(newData);
    
    // Persist to server API
    fetch("/api/cms-data", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newData)
    }).catch(err => console.error("Could not sync data to backend server:", err));
  };

  // Auto-hide Navbar & Active Section Tracking
  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;
      
      // Auto-hide Navbar logic
      if (currentScrollY > lastScrollY.current && currentScrollY > 100) {
        setIsNavVisible(false); // Hide on scroll down
      } else {
        setIsNavVisible(true); // Show on scroll up
      }
      lastScrollY.current = currentScrollY;

      // Section Highlight tracking
      const sections = ["hero", "about", "projects", "process", "contact"];
      const scrollPosition = currentScrollY + 200;

      for (const sec of sections) {
        const el = document.getElementById(sec);
        if (el) {
          const top = el.offsetTop;
          const height = el.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(sec);
            break;
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Parallax Handler for Hero Section
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const { innerWidth, innerHeight } = window;
      const x = (e.clientX - innerWidth / 2) / (innerWidth / 2);
      const y = (e.clientY - innerHeight / 2) / (innerHeight / 2);
      setMousePos({ x, y });
    };

    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  // India/Bangalore custom interactive spinning canvas map
  useEffect(() => {
    if (isLoading || !mapCanvasRef.current) return;
    const canvas = mapCanvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animId: number;
    let rotation = 0;
    const width = (canvas.width = 400);
    const height = (canvas.height = 400);

    const draw = () => {
      ctx.clearRect(0, 0, width, height);
      rotation += 0.003;

      const cx = width / 2;
      const cy = height / 2;
      const radius = 120;

      // Draw wireframe sphere lat/long lines
      ctx.strokeStyle = "rgba(96, 165, 250, 0.08)";
      ctx.lineWidth = 1;

      // Latitudes
      for (let i = -4; i <= 4; i++) {
        const r = radius * Math.cos((i * Math.PI) / 10);
        const y = cy + radius * Math.sin((i * Math.PI) / 10);
        ctx.beginPath();
        ctx.ellipse(cx, y, r, r * 0.25, 0, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Longitudes (spinning)
      for (let i = 0; i < 5; i++) {
        const theta = rotation + (i * Math.PI) / 5;
        const w = radius * Math.sin(theta);
        ctx.beginPath();
        ctx.ellipse(cx, cy, Math.abs(w), radius, 0, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Outer Ring
      ctx.strokeStyle = "rgba(59, 130, 246, 0.2)";
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(cx, cy, radius + 10, 0, Math.PI * 2);
      ctx.stroke();

      // Location ping center (Pawan's coordinate - Bangalore representation)
      ctx.fillStyle = "#60a5fa";
      ctx.shadowColor = "#3b82f6";
      ctx.shadowBlur = 15;
      ctx.beginPath();
      ctx.arc(cx, cy, 6, 0, Math.PI * 2);
      ctx.fill();

      // Pulsing location halo
      const pulse = (Date.now() / 800) % 1;
      ctx.strokeStyle = `rgba(96, 165, 250, ${1 - pulse})`;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(cx, cy, 6 + pulse * 28, 0, Math.PI * 2);
      ctx.stroke();

      ctx.shadowBlur = 0; // reset

      animId = requestAnimationFrame(draw);
    };

    draw();
    return () => cancelAnimationFrame(animId);
  }, [isLoading]);

  // Copy Email Helper
  const handleCopyEmail = () => {
    if (!cmsData) return;
    navigator.clipboard.writeText(cmsData.profile.email);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  const activeProjectsList = cmsData?.projects
    ? cmsData.projects.filter((p) => p.status === "published")
    : [];

  return (
    <div className="min-h-screen bg-[#040812] text-slate-100 font-sans relative antialiased overflow-x-hidden selection:bg-blue-600/30 selection:text-white">
      {/* Background ambient radial gradients */}
      <div className="absolute top-0 right-0 w-[60vw] h-[60vw] bg-blue-900/10 rounded-full filter blur-[150px] pointer-events-none z-0" />
      <div className="absolute top-[120vh] left-0 w-[55vw] h-[55vw] bg-sky-900/10 rounded-full filter blur-[150px] pointer-events-none z-0" />
      <div className="absolute bottom-0 right-1/4 w-[70vw] h-[70vw] bg-blue-950/10 rounded-full filter blur-[180px] pointer-events-none z-0" />

      {/* Subtle overlay grid / grain */}
      <div className="absolute inset-0 bg-[radial-gradient(transparent_1px,#040812_1px)] [background-size:24px_24px] opacity-25 pointer-events-none z-0" />

      {/* Custom Pointer Cursor */}
      <CustomCursor />

      {/* Loading Intro */}
      <AnimatePresence>
        {isLoading && <LoadingScreen onComplete={handleLoadingComplete} />}
      </AnimatePresence>

      {!isLoading && cmsData && (
        <>
          {/* Slow ambient light particles across all sections except loading screen */}
          <HeroParticles />

          {/* NAVIGATION BAR */}
          <motion.nav
            initial={{ y: -100 }}
            animate={{ y: isNavVisible ? 0 : -100 }}
            transition={{ duration: 0.35, ease: "easeOut" }}
            className="fixed top-6 left-1/2 -translate-x-1/2 w-[90%] max-w-4xl bg-slate-950/50 backdrop-blur-xl border border-slate-800/60 rounded-full py-3.5 px-6 flex items-center justify-between z-30 shadow-[0_10px_30px_rgba(4,8,18,0.5)]"
          >
            {/* Logo */}
            <a
              href="#hero"
              className="font-mono text-xs font-bold tracking-widest text-white hover:text-sky-400 transition-colors uppercase"
            >
              PAWAN.DESIGN
            </a>

            {/* Anchors links */}
            <div className="hidden md:flex items-center gap-6 font-mono text-[10px] tracking-widest uppercase">
              {["about", "projects", "process", "contact"].map((sec) => (
                <a
                  key={sec}
                  href={`#${sec}`}
                  className={`transition-colors relative py-1 ${
                    activeSection === sec ? "text-sky-400 font-bold" : "text-slate-400 hover:text-slate-200"
                  }`}
                >
                  {sec}
                  {activeSection === sec && (
                    <motion.span
                      layoutId="nav-underline"
                      className="absolute bottom-0 left-0 right-0 h-[1.5px] bg-sky-400 shadow-[0_0_8px_#3b82f6]"
                    />
                  )}
                </a>
              ))}
            </div>

            {/* Actions: CMS toggle */}
            <div className="flex items-center gap-3">
              <button
                onClick={() => setIsAdminOpen(true)}
                className="p-2 bg-slate-900 hover:bg-slate-800 text-sky-400 hover:text-white rounded-full border border-slate-800 hover:border-slate-700 transition-all cursor-pointer flex items-center justify-center"
                title="Open CMS control panel"
              >
                <Settings size={14} />
              </button>

              <a
                href="#contact"
                className="px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-full text-[10px] font-mono tracking-wider font-bold transition-all shadow-[0_4px_12px_rgba(29,78,216,0.25)]"
              >
                CONNECT
              </a>
            </div>
          </motion.nav>

          {/* HERO SECTION */}
          <section
            id="hero"
            className="min-h-screen flex flex-col justify-between p-6 md:p-12 relative overflow-hidden select-none z-10"
          >
            {/* Background geometric mesh lines */}
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-5">
              <div className="w-[120vw] h-[120vw] border border-dashed border-sky-400 rounded-full animate-[spin_120s_linear_infinite]" />
            </div>

            {/* Spacer */}
            <div />

            {/* Main Content Grid:
                Mobile: Upper side circle, Lower side text
                Desktop/Tablet: Left side text, Right side circle */}
            <div className="w-full max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-12 gap-8 md:gap-12 items-center relative z-10 my-auto">
              
              {/* Circle (Upper on Mobile, Right on Desktop/Tablet) */}
              <div className="order-1 md:order-2 md:col-span-5 flex justify-center items-center h-[280px] sm:h-[350px] md:h-[420px] lg:h-[480px] w-full relative">
                <div className="w-full h-full relative">
                  <FloatingBlob />
                </div>
              </div>

              {/* Text Content (Lower on Mobile, Left on Desktop/Tablet) */}
              <div className="order-2 md:order-1 md:col-span-7 space-y-6 text-center md:text-left">
                <div className="space-y-4">
                  <motion.div
                    initial={{ opacity: 0, y: 30 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 1, delay: 0.2 }}
                    className="flex items-center justify-center md:justify-start gap-2"
                  >
                    <span className="w-2 h-2 bg-sky-400 rounded-full animate-pulse shadow-[0_0_8px_#60a5fa]" />
                    <span className="text-[10px] sm:text-xs font-mono text-sky-300 uppercase tracking-[0.3em] font-bold">
                      {cmsData.profile.title}
                    </span>
                  </motion.div>

                  {/* Parallax moving display title */}
                  <motion.h1
                    style={{
                      x: mousePos.x * 12,
                      y: mousePos.y * 12,
                    }}
                    className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl font-sans font-black tracking-tight uppercase leading-[0.95] select-none text-transparent bg-clip-text bg-gradient-to-r from-[#00ffff] via-[#3b82f6] to-[#a855f7] animate-gradient-shift pb-1.5"
                  >
                    PAWAN K.
                    <br />
                    KUSHWAHA
                  </motion.h1>
                </div>

                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ duration: 1.2, delay: 0.5 }}
                  className="max-w-xl mx-auto md:mx-0 text-slate-400 text-sm md:text-base leading-relaxed font-mono"
                >
                  "{cmsData.profile.tagline}"
                </motion.div>
              </div>
            </div>

            {/* Bottom Controls */}
            <div className="w-full max-w-6xl mx-auto flex justify-between items-end relative z-10 pt-8">
              <div className="flex gap-4 text-xs font-mono text-slate-500">
                <span>BANGALORE • IN</span>
                <span>/</span>
                <span>TOLERANCE_0.02MM</span>
              </div>

              <div className="flex flex-col items-center">
                <a
                  href="#about"
                  className="p-3 border border-slate-800 rounded-full bg-slate-950/40 text-slate-400 hover:text-white hover:border-slate-700 transition-all animate-bounce"
                >
                  <ChevronDown size={16} />
                </a>
              </div>
            </div>
          </section>

          {/* ABOUT SECTION */}
          <section id="about" className="py-24 border-t border-slate-900 relative z-10">
            <div className="max-w-6xl mx-auto px-6 md:px-12 grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
              {/* Left Portrait representation */}
              <div className="lg:col-span-5 space-y-6">
                <div 
                  onClick={() => setIsPortraitToggled(!isPortraitToggled)}
                  className="relative group rounded-2xl overflow-hidden border border-slate-800 aspect-[4/5] shadow-2xl isolate cursor-pointer select-none touch-manipulation"
                >
                  <img
                    src={cmsData.profile.portraitUrl}
                    alt={cmsData.profile.name}
                    className={`w-full h-full object-cover transition-all duration-700 transform-gpu filter ${
                      isPortraitToggled 
                        ? "scale-102 grayscale-0" 
                        : "grayscale group-hover:scale-102 group-hover:grayscale-0"
                    }`}
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 via-transparent to-transparent pointer-events-none" />
                  <div className="absolute bottom-6 left-6 space-y-1 text-white pointer-events-none">
                    <span className="text-[10px] font-mono tracking-widest uppercase text-sky-400">FOUNDER</span>
                    <h3 className="text-xl font-bold">{cmsData.profile.name}</h3>
                  </div>
                </div>

                {/* Additional mini about tags */}
                <div className="grid grid-cols-2 gap-4 text-xs font-mono">
                  <div className="p-4 bg-slate-950/60 border border-slate-900 rounded-xl space-y-1">
                    <span className="text-slate-500">EXPERTISE</span>
                    <p className="text-slate-300 font-bold">CAD & Solid Modeling</p>
                  </div>
                  <div className="p-4 bg-slate-950/60 border border-slate-900 rounded-xl space-y-1">
                    <span className="text-slate-500">FOCUS</span>
                    <p className="text-slate-300 font-bold">DFMA & Material Specs</p>
                  </div>
                </div>
              </div>

              {/* Right Content */}
              <div className="lg:col-span-7 space-y-8">
                <div className="space-y-2">
                  <span className="text-xs font-mono text-blue-400 uppercase tracking-widest font-bold">
                    BIOGRAPHY & EXPERTISE
                  </span>
                  <h2 className="text-3xl md:text-5xl font-sans tracking-tight font-extrabold text-white">
                    Fusing Mechanics with Pure Art.
                  </h2>
                </div>

                <p className="text-slate-300 text-base md:text-lg leading-relaxed font-light">
                  {cmsData.profile.bio}
                </p>

                {/* Software and Tools */}
                <div className="space-y-4">
                  <h4 className="text-xs font-mono text-slate-500 uppercase tracking-widest font-bold">
                    SOFTWARE & CAD CAPABILITIES
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {cmsData.profile.software.map((sw) => (
                      <div key={sw.name} className="p-3 bg-slate-950/40 border border-slate-900/80 rounded-xl space-y-2">
                        <div className="flex justify-between items-center text-xs">
                          <span className="font-semibold text-slate-300">{sw.name}</span>
                          <span className="font-mono text-slate-500 font-bold">{sw.level}%</span>
                        </div>
                        <div className="w-full h-1 bg-slate-900 rounded-full overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            whileInView={{ width: `${sw.level}%` }}
                            viewport={{ once: true }}
                            transition={{ duration: 1 }}
                            className="h-full bg-blue-500 rounded-full"
                          />
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Credentials & Timeline */}
                <div className="space-y-6 pt-6 border-t border-slate-900">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                    <h4 className="text-xs font-mono text-slate-500 uppercase tracking-widest font-bold">
                      ACADEMIC & PROFESSIONAL CREDENTIALS
                    </h4>
                    {cmsData.profile.resumeUrl && (
                      <a
                        href={cmsData.profile.resumeUrl}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1.5 text-xs font-mono text-sky-400 hover:text-sky-300 transition-colors uppercase font-bold"
                      >
                        <FileText size={12} /> Download CV / Resume
                      </a>
                    )}
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 text-xs pt-2">
                    {/* Education Column */}
                    <div className="space-y-4">
                      <h5 className="text-[10px] font-mono text-slate-400 uppercase tracking-widest font-semibold flex items-center gap-1.5">
                        <GraduationCap size={13} className="text-sky-400" /> Academic Timeline
                      </h5>
                      <div className="space-y-4">
                        {(cmsData.profile.education || []).map((edu, eIdx) => (
                          <div key={eIdx} className="space-y-1 relative pl-4 border-l border-slate-800">
                            <span className="absolute left-0 top-1.5 -translate-x-[4.5px] w-2 h-2 bg-sky-500/20 border border-sky-400 rounded-full" />
                            <div className="flex justify-between items-start">
                              <h6 className="font-bold text-white text-sm leading-snug">{edu.degree}</h6>
                              <span className="text-[10px] font-mono text-slate-500 shrink-0 ml-2">{edu.year}</span>
                            </div>
                            <p className="text-slate-400 font-mono text-[11px]">{edu.school}</p>
                          </div>
                        ))}
                        {(cmsData.profile.education || []).length === 0 && (
                          <p className="text-slate-600 italic text-[11px] font-mono">No academic credentials defined in CMS.</p>
                        )}
                      </div>
                    </div>

                    {/* Experience Column */}
                    <div className="space-y-4">
                      <h5 className="text-[10px] font-mono text-slate-400 uppercase tracking-widest font-semibold flex items-center gap-1.5">
                        <Briefcase size={13} className="text-sky-400" /> Work History
                      </h5>
                      <div className="space-y-4">
                        {(cmsData.profile.experience || []).map((exp, xIdx) => (
                          <div key={xIdx} className="space-y-1 relative pl-4 border-l border-slate-800">
                            <span className="absolute left-0 top-1.5 -translate-x-[4.5px] w-2 h-2 bg-blue-500/20 border border-blue-400 rounded-full" />
                            <div className="flex justify-between items-start">
                              <h6 className="font-bold text-white text-sm leading-snug">{exp.role}</h6>
                              <span className="text-[10px] font-mono text-slate-500 shrink-0 ml-2">{exp.period}</span>
                            </div>
                            <p className="text-slate-300 font-mono text-[11px]">{exp.company}</p>
                            <p className="text-slate-400 text-[11px] leading-relaxed mt-1 font-light">{exp.description}</p>
                          </div>
                        ))}
                        {(cmsData.profile.experience || []).length === 0 && (
                          <p className="text-slate-600 italic text-[11px] font-mono">No work experience defined in CMS.</p>
                        )}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Skills badges */}
                <div className="space-y-3 pt-4 border-t border-slate-900">
                  <h4 className="text-xs font-mono text-slate-500 uppercase tracking-widest font-bold">
                    CORE SPECIALTIES
                  </h4>
                  <div className="flex flex-wrap gap-2">
                    {cmsData.profile.skills.map((skill) => (
                      <span
                        key={skill}
                        className="px-3 py-1 bg-blue-900/10 border border-blue-500/10 text-sky-400 rounded-md text-xs font-semibold"
                      >
                        {skill}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* PROJECT SECTION */}
          <section id="projects" className="py-24 border-t border-slate-900 relative z-10">
            <div className="max-w-6xl mx-auto px-6 md:px-12 space-y-12">
              <div className="flex flex-col md:flex-row md:justify-between md:items-end gap-4">
                <div className="space-y-2">
                  <span className="text-xs font-mono text-blue-400 uppercase tracking-widest font-bold">
                    SELECTED WORKS
                  </span>
                  <h2 className="text-3xl md:text-5xl font-sans tracking-tight font-extrabold text-white">
                    Form Follows Purpose.
                  </h2>
                </div>
                <p className="text-slate-500 font-mono text-xs max-w-xs leading-relaxed">
                  Click on any tile to enter full-screen editorial case studies exploring problem research, CAD specs, and prototypes.
                </p>
              </div>

              {/* Grid of floating project tiles */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {activeProjectsList.map((project, idx) => (
                  <motion.div
                    key={project.id}
                    onClick={() => setActiveProject(project)}
                    className="group relative bg-slate-950/40 border border-slate-900 rounded-2xl overflow-hidden cursor-pointer shadow-xl flex flex-col justify-between"
                    whileHover={{ y: -8, scale: 1.01 }}
                    transition={{ duration: 0.4 }}
                    data-cursor="open"
                  >
                    {/* Hero image box */}
                    <div className="relative aspect-16/10 overflow-hidden bg-slate-900">
                      <img
                        src={project.heroImage}
                        alt={project.title}
                        className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-104 filter saturate-75 group-hover:saturate-100"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-80" />
                      
                      {/* Interactive Expand label */}
                      <span className="absolute top-4 right-4 p-2 bg-black/60 backdrop-blur-md rounded-full border border-slate-800 text-white opacity-0 group-hover:opacity-100 transition-opacity">
                        <Maximize2 size={13} />
                      </span>
                    </div>

                    {/* Bottom Metadata detail */}
                    <div className="p-6 space-y-3">
                      <div className="flex justify-between items-center text-xs font-mono">
                        <span className="text-slate-500 uppercase font-bold tracking-wider">{project.category}</span>
                        <span className="text-slate-400">{project.year}</span>
                      </div>

                      <h3 className="text-xl md:text-2xl font-bold text-white group-hover:text-sky-300 transition-colors">
                        {project.title}
                      </h3>

                      <p className="text-slate-400 text-xs line-clamp-2 leading-relaxed">
                        {project.description}
                      </p>

                      <div className="flex gap-2 flex-wrap pt-2 border-t border-slate-900 justify-between items-center">
                        <div className="flex gap-2 flex-wrap">
                          {project.tools.slice(0, 3).map((t, tIdx) => (
                            <span key={tIdx} className="text-[10px] font-mono text-slate-500">
                              #{t}
                            </span>
                          ))}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          </section>

          {/* INDUSTRIAL DESIGN PROCESS */}
          <section id="process" className="py-24 border-t border-slate-900 bg-slate-950/20 relative z-10">
            <div className="max-w-6xl mx-auto px-6 md:px-12 mb-12 space-y-2 text-center md:text-left">
              <span className="text-xs font-mono text-blue-400 uppercase tracking-widest font-bold">
                METHODOLOGY
              </span>
              <h2 className="text-3xl md:text-5xl font-sans tracking-tight font-extrabold text-white">
                Proprietary Design Cycle.
              </h2>
              <p className="text-slate-500 font-mono text-xs max-w-md">
                Pawan's disciplined 10-step industrial workflow from first observational fieldwork to production.
              </p>
            </div>

            {/* Timeline element */}
            <TimelineProcess stages={cmsData.stages} />
          </section>

          {/* CONTACT SECTION */}
          <section id="contact" className="py-24 border-t border-slate-900 relative z-10">
            <div className="max-w-6xl mx-auto px-6 md:px-12 grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
              {/* Left Canvas spinning Globe representation */}
              <div className="lg:col-span-5 flex justify-center items-center relative overflow-hidden">
                <canvas ref={mapCanvasRef} className="w-full max-w-[340px] aspect-square rounded-full border border-slate-900/50" />
                <div className="absolute flex flex-col items-center bg-slate-950/80 border border-slate-800 rounded-2xl p-4 shadow-xl text-center backdrop-blur-md">
                  <MapPin size={16} className="text-sky-400 mb-1" />
                  <span className="text-[10px] font-mono text-slate-400 uppercase tracking-wider font-bold">LOCATED AT</span>
                  <p className="text-xs font-bold text-white mt-0.5">{cmsData.profile.location}</p>
                </div>
              </div>

              {/* Right content details */}
              <div className="lg:col-span-7 space-y-8">
                <div className="space-y-2">
                  <span className="text-xs font-mono text-blue-400 uppercase tracking-widest font-bold">
                    GET IN TOUCH
                  </span>
                  <h2 className="text-4xl md:text-6xl font-sans tracking-tight font-black text-white leading-tight uppercase">
                    LET'S CREATE
                    <br />
                    THE FUTURE.
                  </h2>
                </div>

                <p className="text-slate-300 text-sm md:text-base leading-relaxed max-w-lg">
                  I am always open to discuss custom hardware collaborations, mass-manufacturing consulting, or permanent design positions at creative studios. Drop me a line.
                </p>

                {/* Email container */}
                <div className="p-4 md:p-6 bg-slate-950/70 border border-slate-850 rounded-2xl flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
                  <div className="space-y-1">
                    <span className="text-[9px] font-mono text-slate-500 uppercase tracking-wider font-bold">DIRECT MAILBOX</span>
                    <p className="text-sm md:text-base font-bold text-sky-300 font-mono select-all">
                      {cmsData.profile.email}
                    </p>
                  </div>
                  <button
                    onClick={handleCopyEmail}
                    className="w-full sm:w-auto px-4 py-2.5 bg-blue-600/15 hover:bg-blue-600/35 border border-blue-500/20 text-sky-300 text-xs font-mono tracking-wider font-bold rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer"
                  >
                    {isCopied ? (
                      <>
                        <Check size={14} /> COPIED!
                      </>
                    ) : (
                      <>
                        <Copy size={14} /> COPY EMAIL
                      </>
                    )}
                  </button>
                </div>

                {/* Social media connections */}
                <div className="space-y-3">
                  <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest font-bold">
                    DIGITAL CHANNELS
                  </span>
                  <div className="flex flex-wrap gap-3 font-mono text-xs">
                    {cmsData.profile.socials.map((soc) => (
                      <a
                        key={soc.name}
                        href={soc.url}
                        target="_blank"
                        rel="noreferrer"
                        className="px-4 py-2 bg-slate-900/60 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 rounded-xl text-slate-300 hover:text-white transition-all flex items-center gap-1.5 cursor-pointer"
                      >
                        {soc.name} <ArrowUpRight size={13} className="text-slate-500" />
                      </a>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </section>

          {/* FOOTER */}
          <footer className="border-t border-slate-900 bg-slate-950/30 py-12 text-xs font-mono text-slate-500 relative z-10">
            <div className="max-w-6xl mx-auto px-6 md:px-12 flex flex-col sm:flex-row gap-6 justify-between items-center text-center sm:text-left">
              <div className="space-y-1">
                <span className="font-bold text-slate-400">PAWAN K. KUSHWAHA</span>
                <p className="text-[10px]">Product & Industrial Designer © 2026</p>
              </div>

              <div className="flex gap-4">
                <a href="#about" className="hover:text-slate-300">About</a>
                <a href="#projects" className="hover:text-slate-300">Projects</a>
                <a href="#process" className="hover:text-slate-300">Methodology</a>
              </div>

              <button
                onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
                className="px-3.5 py-1.5 border border-slate-900 rounded-full hover:bg-slate-900 hover:text-slate-300 transition-all cursor-pointer"
              >
                BACK TO TOP ↑
              </button>
            </div>
          </footer>

          {/* DETAIL MODAL CASE STUDY OVERLAY */}
          <AnimatePresence>
            {activeProject && (
              <ProjectDetail
                project={activeProject}
                onClose={() => setActiveProject(null)}
                allProjects={activeProjectsList}
                onNavigate={(nextProj) => setActiveProject(nextProj)}
              />
            )}
          </AnimatePresence>

          {/* CMS CONTROL PANEL MODAL OVERLAY */}
          <AdminCMS
            isOpen={isAdminOpen}
            onClose={() => setIsAdminOpen(false)}
            cmsData={cmsData}
            onUpdate={handleUpdateCMS}
          />
        </>
      )}
    </div>
  );
}

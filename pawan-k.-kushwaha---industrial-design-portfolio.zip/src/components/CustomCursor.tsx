import { useEffect, useState } from "react";
import { motion, useMotionValue, useSpring } from "motion/react";

export default function CustomCursor() {
  const [cursorType, setCursorType] = useState<"default" | "pointer" | "view" | "open" | "drag" | "scroll">("default");
  const [isVisible, setIsVisible] = useState(false);

  const cursorX = useMotionValue(-100);
  const cursorY = useMotionValue(-100);

  const springConfig = { damping: 40, stiffness: 400, mass: 0.6 };
  const cursorXSpring = useSpring(cursorX, springConfig);
  const cursorYSpring = useSpring(cursorY, springConfig);

  useEffect(() => {
    const moveCursor = (e: MouseEvent) => {
      cursorX.set(e.clientX);
      cursorY.set(e.clientY);
      if (!isVisible) setIsVisible(true);
    };

    const handleMouseLeave = () => {
      setIsVisible(false);
    };

    const handleMouseEnter = () => {
      setIsVisible(true);
    };

    window.addEventListener("mousemove", moveCursor);
    document.addEventListener("mouseleave", handleMouseLeave);
    document.addEventListener("mouseenter", handleMouseEnter);

    // Dynamic hover detection
    const handleMouseOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (!target) return;

      const closestLink = target.closest("a, button, select, input, textarea, [role='button']");
      const cursorTextAttr = target.closest("[data-cursor]")?.getAttribute("data-cursor");

      if (cursorTextAttr) {
        setCursorType(cursorTextAttr as any);
      } else if (closestLink) {
        setCursorType("pointer");
      } else {
        setCursorType("default");
      }
    };

    document.addEventListener("mouseover", handleMouseOver);

    return () => {
      window.removeEventListener("mousemove", moveCursor);
      document.removeEventListener("mouseleave", handleMouseLeave);
      document.removeEventListener("mouseenter", handleMouseEnter);
      document.removeEventListener("mouseover", handleMouseOver);
    };
  }, [cursorX, cursorY, isVisible]);

  if (!isVisible) return null;

  const getCursorStyles = () => {
    switch (cursorType) {
      case "pointer":
        return {
          width: 48,
          height: 48,
          backgroundColor: "rgba(0, 240, 255, 0.08)",
          borderWidth: "1.5px",
        };
      case "view":
      case "open":
      case "drag":
      case "scroll":
        return {
          width: 72,
          height: 72,
          backgroundColor: "rgba(29, 78, 216, 0.2)",
          borderWidth: "1.5px",
        };
      default:
        return {
          width: 14,
          height: 14,
          backgroundColor: "rgba(0, 240, 255, 0.04)",
          borderWidth: "1px",
        };
    }
  };

  return (
    <>
      {/* Outer interactive halo */}
      <motion.div
        className="fixed top-0 left-0 rounded-full pointer-events-none z-50 mix-blend-screen flex items-center justify-center font-mono text-[9px] tracking-widest text-white uppercase select-none font-bold animate-cursor-pulse"
        style={{
          x: cursorXSpring,
          y: cursorYSpring,
          translateX: "-50%",
          translateY: "-50%",
        }}
        animate={getCursorStyles()}
        transition={{ type: "spring", stiffness: 500, damping: 45 }}
      >
        {["view", "open", "drag", "scroll"].includes(cursorType) && (
          <motion.span
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className="text-sky-100 font-sans tracking-wide text-[10px] font-semibold"
          >
            {cursorType}
          </motion.span>
        )}
      </motion.div>

      {/* Inner pinpoint dot */}
      <motion.div
        className="fixed top-0 left-0 w-2 h-2 rounded-full pointer-events-none z-50 animate-cursor-dot"
        style={{
          x: cursorX,
          y: cursorY,
          translateX: "-50%",
          translateY: "-50%",
        }}
      />
    </>
  );
}

import { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { DesignStage } from "../types";
import { Compass, Search, Lightbulb, PenTool, Layout, Box, Sliders, Clipboard, ShieldCheck, RefreshCw } from "lucide-react";

interface TimelineProcessProps {
  stages: DesignStage[];
}

const STAGE_ICONS: Record<string, any> = {
  discover: Compass,
  research: Search,
  insights: Lightbulb,
  concept: Box,
  sketch: PenTool,
  cad: Layout,
  prototype: Sliders,
  testing: Clipboard,
  manufacturing: ShieldCheck,
  reflection: RefreshCw,
};

export default function TimelineProcess({ stages }: TimelineProcessProps) {
  const [activeStageId, setActiveStageId] = useState(stages[0]?.id || "discover");

  // Keep activeStageId in sync if the current active one gets deleted or isn't in the list
  const currentExists = stages.some(s => s.id === activeStageId);
  const effectiveStageId = currentExists ? activeStageId : (stages[0]?.id || "");

  if (!stages || stages.length === 0) {
    return (
      <div className="w-full max-w-6xl mx-auto px-4 md:px-8 py-12 text-center text-slate-500 font-mono text-sm">
        No methodology stages defined yet. Please add them in the CMS.
      </div>
    );
  }

  const activeStage = stages.find((s) => s.id === effectiveStageId) || stages[0];
  const ActiveIcon = STAGE_ICONS[activeStage.id] || Compass;

  return (
    <div className="w-full max-w-6xl mx-auto px-4 md:px-8 py-12">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
        {/* Left Interactive Timeline Line */}
        <div className="lg:col-span-5 flex flex-col relative">
          <div className="absolute left-[21px] top-4 bottom-4 w-[2px] bg-slate-800 pointer-events-none" />

          {stages.map((stage, idx) => {
            const IconComponent = STAGE_ICONS[stage.id] || Compass;
            const isActive = stage.id === activeStageId;

            return (
              <button
                key={stage.id}
                onClick={() => setActiveStageId(stage.id)}
                className={`relative flex items-center text-left py-4 pl-12 pr-4 rounded-xl transition-all duration-300 group z-10 ${
                  isActive ? "bg-slate-900/60 border border-blue-500/30" : "hover:bg-slate-900/30 border border-transparent"
                }`}
              >
                {/* Number Label */}
                <span className="absolute left-[36px] top-1/2 -translate-y-1/2 -translate-x-1/2 text-[9px] font-mono text-slate-500 group-hover:text-sky-400 transition-colors">
                  {(idx + 1).toString().padStart(2, "0")}
                </span>

                {/* Ring Indicator */}
                <div
                  className={`absolute left-[21px] top-1/2 -translate-y-1/2 -translate-x-1/2 w-4.5 h-4.5 rounded-full flex items-center justify-center border-2 transition-all duration-300 ${
                    isActive ? "bg-blue-600 border-sky-400 scale-125 shadow-[0_0_8px_rgba(96,165,250,0.6)]" : "bg-slate-950 border-slate-700"
                  }`}
                >
                  <div className={`w-1.5 h-1.5 rounded-full ${isActive ? "bg-white" : "bg-transparent"}`} />
                </div>

                <div className="flex items-center gap-4">
                  <div
                    className={`p-2 rounded-lg transition-colors ${
                      isActive ? "bg-blue-600/20 text-sky-400" : "bg-slate-950 text-slate-500 group-hover:text-slate-300"
                    }`}
                  >
                    <IconComponent size={18} />
                  </div>
                  <div>
                    <h3
                      className={`text-sm md:text-base font-semibold tracking-wide transition-colors ${
                        isActive ? "text-sky-300" : "text-slate-400 group-hover:text-slate-200"
                      }`}
                    >
                      {stage.title}
                    </h3>
                    <p className="text-xs text-slate-500 line-clamp-1 mt-0.5">{stage.description}</p>
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Right Detail Box */}
        <div className="lg:col-span-7 lg:sticky lg:top-32">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeStage.id}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.35, ease: "easeOut" }}
              className="bg-gradient-to-br from-slate-950 to-slate-900 border border-slate-800 rounded-2xl p-6 md:p-10 shadow-2xl relative overflow-hidden"
            >
              {/* Giant Watermark Background */}
              <div className="absolute right-[-40px] top-[-40px] opacity-5 pointer-events-none text-white select-none">
                <ActiveIcon size={240} strokeWidth={1} />
              </div>

              {/* Decorative Tech Grid Lines */}
              <div className="absolute top-0 left-0 w-8 h-[1px] bg-sky-500" />
              <div className="absolute top-0 left-0 w-[1px] h-8 bg-sky-500" />

              <div className="flex items-center gap-4 mb-6">
                <div className="p-3 bg-blue-600/10 text-sky-400 border border-blue-500/20 rounded-xl">
                  <ActiveIcon size={28} />
                </div>
                <div>
                  <span className="text-[10px] font-mono tracking-[0.2em] text-sky-400 uppercase font-bold">
                    DESIGN METHODOLOGY • STAGE {stages.findIndex((s) => s.id === activeStage.id) + 1} OF {stages.length}
                  </span>
                  <h2 className="text-2xl md:text-3xl font-sans tracking-tight font-extrabold text-white mt-1">
                    {activeStage.title}
                  </h2>
                </div>
              </div>

              <p className="text-slate-300 text-base leading-relaxed mb-8 border-l-2 border-sky-400 pl-4 py-1 italic">
                "{activeStage.description}"
              </p>

              <div>
                <h4 className="text-xs font-mono tracking-widest text-slate-500 uppercase font-bold mb-4">
                  CORE ARTIFACTS & DELIVERABLES
                </h4>
                <ul className="space-y-4">
                  {activeStage.details.map((detail, index) => (
                    <motion.li
                      key={index}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className="flex items-start gap-3 text-sm text-slate-400"
                    >
                      <span className="w-1.5 h-1.5 bg-sky-400 rounded-full mt-2 shrink-0 shadow-[0_0_6px_#60a5fa]" />
                      <span className="leading-relaxed">{detail}</span>
                    </motion.li>
                  ))}
                </ul>
              </div>

              {/* Technical Footnote representation */}
              <div className="border-t border-slate-800/60 mt-8 pt-4 flex justify-between items-center text-[10px] font-mono text-slate-500">
                <span>STAGE_ID: {activeStage.id.toUpperCase()}</span>
                <span>TOLERANCE_RATING: HIGH</span>
              </div>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}

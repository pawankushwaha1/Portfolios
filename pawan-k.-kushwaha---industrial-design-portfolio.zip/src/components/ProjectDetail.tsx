import { useEffect, useState, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Project, ProjectSection } from "../types";
import { 
  X, ArrowLeft, ArrowRight, Calendar, User, Clock, FileDown, Maximize2, 
  ShieldAlert, Play, Pause, ExternalLink, Sparkles, Check, ChevronRight, Info 
} from "lucide-react";

// -------------------------------------------------------------
// Interactive Section Subcomponents
// -------------------------------------------------------------

function BeforeAfterSlider({ before, after, labelBefore, labelAfter }: { before: string; after: string; labelBefore?: string; labelAfter?: string }) {
  const [sliderPos, setSliderPos] = useState(50);
  return (
    <div className="relative w-full aspect-16/10 rounded-xl overflow-hidden border border-slate-800 select-none group">
      <img src={after} className="absolute inset-0 w-full h-full object-cover" alt="After Design/Prototype" referrerPolicy="no-referrer" />
      {labelAfter && (
        <span className="absolute bottom-4 right-4 px-3 py-1 bg-black/70 text-[10px] font-mono tracking-wider text-slate-200 border border-slate-800 rounded uppercase">
          {labelAfter}
        </span>
      )}
      
      <div 
        className="absolute inset-0 w-full h-full overflow-hidden"
        style={{ clipPath: `polygon(0 0, ${sliderPos}% 0, ${sliderPos}% 100%, 0 100%)` }}
      >
        <img src={before} className="absolute inset-0 w-full h-full object-cover" alt="Before Design/Sketch" referrerPolicy="no-referrer" />
        {labelBefore && (
          <span className="absolute bottom-4 left-4 px-3 py-1 bg-blue-600/90 text-[10px] font-mono tracking-wider text-white border border-blue-500/50 rounded uppercase">
            {labelBefore}
          </span>
        )}
      </div>

      <div 
        className="absolute top-0 bottom-0 w-1 bg-sky-400 cursor-ew-resize flex items-center justify-center pointer-events-none"
        style={{ left: `${sliderPos}%` }}
      >
        <div className="w-8 h-8 rounded-full bg-slate-900 border border-sky-400 text-sky-400 flex items-center justify-center shadow-2xl pointer-events-auto">
          ↔
        </div>
      </div>

      <input 
        type="range" 
        min="0" 
        max="100" 
        value={sliderPos} 
        onChange={(e) => setSliderPos(Number(e.target.value))}
        className="absolute inset-0 w-full h-full opacity-0 cursor-ew-resize z-10" 
      />
    </div>
  );
}

function InteractiveAccordion({ items }: { items: { title: string; content: string }[] }) {
  const [openIndex, setOpenIndex] = useState<number | null>(0);
  return (
    <div className="space-y-3">
      {items.map((item, idx) => (
        <div key={idx} className="border border-slate-800/80 rounded-xl bg-slate-950/20 overflow-hidden">
          <button
            onClick={() => setOpenIndex(openIndex === idx ? null : idx)}
            className="w-full p-5 text-left flex justify-between items-center hover:bg-slate-900/20 transition-all cursor-pointer"
          >
            <span className="font-bold text-slate-100 text-sm sm:text-base">{item.title}</span>
            <span className="text-sky-400 font-mono font-bold text-lg">{openIndex === idx ? "−" : "+"}</span>
          </button>
          {openIndex === idx && (
            <div className="p-5 pt-0 border-t border-slate-800/30 text-sm text-slate-300 leading-relaxed bg-slate-950/40">
              {item.content}
            </div>
          )}
        </div>
      ))}
    </div>
  );
}

function InteractiveTabs({ items }: { items: { title: string; content: string }[] }) {
  const [activeTab, setActiveTab] = useState(0);
  if (!items || items.length === 0) return null;
  return (
    <div className="space-y-4">
      <div className="flex border-b border-slate-800 overflow-x-auto scrollbar-none">
        {items.map((item, idx) => (
          <button
            key={idx}
            onClick={() => setActiveTab(idx)}
            className={`px-5 py-3 text-xs font-mono tracking-wider uppercase border-b-2 transition-all shrink-0 cursor-pointer ${
              activeTab === idx 
                ? 'border-sky-400 text-white font-bold bg-slate-900/40' 
                : 'border-transparent text-slate-500 hover:text-slate-300'
            }`}
          >
            {item.title}
          </button>
        ))}
      </div>
      <div className="p-6 bg-slate-950/30 border border-slate-800/50 rounded-xl text-sm text-slate-300 leading-relaxed min-h-[120px]">
        {items[activeTab]?.content}
      </div>
    </div>
  );
}

function InteractiveCarousel({ urls }: { urls: string[] }) {
  const [index, setIndex] = useState(0);
  if (!urls || urls.length === 0) return null;
  return (
    <div className="relative aspect-16/10 rounded-xl overflow-hidden border border-slate-800 bg-slate-950 group">
      <img src={urls[index]} className="w-full h-full object-cover" alt={`Slide ${index + 1}`} referrerPolicy="no-referrer" />
      
      <button 
        onClick={() => setIndex((index - 1 + urls.length) % urls.length)}
        className="absolute left-4 top-1/2 -translate-y-1/2 p-2.5 rounded-full bg-black/70 border border-slate-800 text-white hover:bg-black/90 transition-all opacity-0 group-hover:opacity-100 cursor-pointer"
      >
        <ArrowLeft size={16} />
      </button>
      <button 
        onClick={() => setIndex((index + 1) % urls.length)}
        className="absolute right-4 top-1/2 -translate-y-1/2 p-2.5 rounded-full bg-black/70 border border-slate-800 text-white hover:bg-black/90 transition-all opacity-0 group-hover:opacity-100 cursor-pointer"
      >
        <ArrowRight size={16} />
      </button>

      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-1.5">
        {urls.map((_, idx) => (
          <button 
            key={idx}
            onClick={() => setIndex(idx)}
            className={`w-2 h-2 rounded-full transition-all cursor-pointer ${index === idx ? 'bg-sky-400 w-4' : 'bg-slate-600'}`}
          />
        ))}
      </div>
    </div>
  );
}

function PDFViewerComponent({ pdfUrl, title }: { pdfUrl: string; title?: string }) {
  const [zoom, setZoom] = useState(100);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [page, setPage] = useState(1);
  const containerRef = useRef<HTMLDivElement | null>(null);

  const toggleFullscreen = () => {
    if (!containerRef.current) return;
    if (!document.fullscreenElement) {
      containerRef.current.requestFullscreen().then(() => setIsFullscreen(true)).catch(err => console.error(err));
    } else {
      document.exitFullscreen().then(() => setIsFullscreen(false));
    }
  };

  useEffect(() => {
    const handleFsChange = () => {
      setIsFullscreen(!!document.fullscreenElement);
    };
    document.addEventListener('fullscreenchange', handleFsChange);
    return () => document.removeEventListener('fullscreenchange', handleFsChange);
  }, []);

  return (
    <div ref={containerRef} className={`flex flex-col border border-slate-800 rounded-xl bg-slate-950 overflow-hidden ${isFullscreen ? 'w-screen h-screen z-50 fixed inset-0' : 'w-full'}`}>
      <div className="bg-slate-900 px-4 py-3 flex flex-wrap gap-3 items-center justify-between border-b border-slate-800">
        <div className="flex items-center gap-2">
          <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
          <span className="text-xs font-mono font-bold text-slate-300 truncate max-w-[180px] sm:max-w-[300px]">{title || "PDF SKETCHPACK / CAD SPEC SHEET"}</span>
        </div>

        <div className="flex items-center gap-4 text-xs font-mono text-slate-400">
          <div className="flex items-center gap-2 border border-slate-800 bg-slate-950 px-2.5 py-1 rounded">
            <button onClick={() => setPage(p => Math.max(1, p - 1))} className="hover:text-white font-bold cursor-pointer">◀</button>
            <span>PAGE {page}</span>
            <button onClick={() => setPage(p => p + 1)} className="hover:text-white font-bold cursor-pointer">▶</button>
          </div>

          <div className="flex items-center gap-2">
            <button onClick={() => setZoom(z => Math.max(50, z - 10))} className="hover:text-white font-bold cursor-pointer" title="Zoom Out">⊖</button>
            <span>{zoom}%</span>
            <button onClick={() => setZoom(z => Math.min(200, z + 10))} className="hover:text-white font-bold cursor-pointer" title="Zoom In">⊕</button>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button onClick={() => window.print()} className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded transition-all cursor-pointer" title="Print document">
            🖨️
          </button>
          <a href={pdfUrl} download className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded transition-all cursor-pointer" title="Download PDF">
            📥
          </a>
          <button onClick={toggleFullscreen} className="p-1.5 text-slate-400 hover:text-white hover:bg-slate-800 rounded transition-all cursor-pointer" title="Toggle Fullscreen">
            ⛶
          </button>
        </div>
      </div>

      <div className="relative bg-slate-900/50 flex-1 flex items-center justify-center p-4 min-h-[400px]">
        <iframe 
          src={`${pdfUrl}#zoom=${zoom / 100}`} 
          className="w-full border-0 rounded bg-white shadow-2xl transition-all duration-200"
          style={{ 
            height: isFullscreen ? 'calc(100vh - 60px)' : '550px',
            transform: `scale(${zoom / 100})`, 
            transformOrigin: 'center center',
            maxWidth: '100%'
          }}
        />
      </div>
    </div>
  );
}

interface ProjectDetailProps {
  project: Project;
  onClose: () => void;
  allProjects: Project[];
  onNavigate: (proj: Project) => void;
}

export default function ProjectDetail({ project, onClose, allProjects, onNavigate }: ProjectDetailProps) {
  const [activePhoto, setActivePhoto] = useState<string | null>(null);

  // Lock body scroll when open
  useEffect(() => {
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = "unset";
    };
  }, []);

  // Handle keyboard navigation for active image viewer
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        if (activePhoto) setActivePhoto(null);
        else onClose();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [activePhoto, onClose]);

  const currentIndex = allProjects.findIndex((p) => p.id === project.id);
  const prevProject = currentIndex > 0 ? allProjects[currentIndex - 1] : null;
  const nextProject = currentIndex < allProjects.length - 1 ? allProjects[currentIndex + 1] : null;

  const allImages = [
    project.heroImage,
    ...project.sketches,
    ...project.cadRenders,
    ...project.prototypePhotos,
    ...project.gallery,
  ].filter(Boolean);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.4 }}
      className="fixed inset-0 z-40 bg-[#040812] overflow-y-auto"
    >
      {/* Background ambient accents */}
      <div className="absolute top-0 right-0 w-[45vw] h-[45vw] bg-blue-900/10 rounded-full filter blur-[120px] pointer-events-none" />
      <div className="absolute top-1/2 left-0 w-[40vw] h-[40vw] bg-sky-900/10 rounded-full filter blur-[120px] pointer-events-none" />

      {/* Navigation Header */}
      <nav className="sticky top-0 bg-[#040812]/70 backdrop-blur-xl border-b border-slate-800/50 z-50 px-6 py-4 flex items-center justify-between">
        <button
          onClick={onClose}
          className="flex items-center gap-2 text-xs font-mono tracking-widest text-slate-400 hover:text-white transition-colors group cursor-pointer"
        >
          <ArrowLeft size={16} className="group-hover:-translate-x-1 transition-transform" />
          BACK TO PORTFOLIO
        </button>

        <div className="flex items-center gap-4 text-[10px] font-mono text-slate-500 uppercase">
          <span>PROJECT {currentIndex + 1} OF {allProjects.length}</span>
        </div>

        <button
          onClick={onClose}
          className="p-2 text-slate-400 hover:text-white rounded-full hover:bg-slate-900 transition-all cursor-pointer"
          title="Close details (Esc)"
        >
          <X size={20} />
        </button>
      </nav>

      <div className="max-w-5xl mx-auto px-6 py-12 space-y-16">
        {/* Editorial Title Header */}
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <span className="px-3 py-1 bg-blue-900/30 text-sky-400 text-[10px] font-mono tracking-widest uppercase border border-blue-500/20 rounded-full">
              {project.category}
            </span>
            <span className="text-xs font-mono text-slate-500">{project.year}</span>
          </div>
          <h1 className="text-4xl md:text-6xl font-sans tracking-tight font-extrabold text-white leading-tight">
            {project.title}
          </h1>
          <p className="text-xl text-slate-300 leading-relaxed max-w-3xl border-l-2 border-blue-500 pl-4 py-1">
            {project.description}
          </p>
        </div>

        {/* Hero Full Width Render */}
        <div className="relative group rounded-2xl overflow-hidden border border-slate-800 shadow-2xl">
          <img
            src={project.heroImage}
            alt={project.title}
            className="w-full h-[55vh] object-cover transition-transform duration-700 group-hover:scale-102"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-80" />
          <button
            onClick={() => setActivePhoto(project.heroImage)}
            className="absolute bottom-6 right-6 p-3 bg-black/50 text-white backdrop-blur-md rounded-full border border-slate-700 opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-2 text-xs font-mono cursor-pointer"
          >
            <Maximize2 size={14} /> EXPAND VIEW
          </button>
        </div>

        {/* Project Metadata Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 py-8 border-y border-slate-800/80 text-sm">
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 text-xs font-mono text-slate-500 uppercase tracking-widest font-bold">
              <User size={13} className="text-blue-400" /> ROLE
            </div>
            <p className="text-slate-300 font-semibold">{project.role}</p>
          </div>
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 text-xs font-mono text-slate-500 uppercase tracking-widest font-bold">
              <Clock size={13} className="text-blue-400" /> TIMELINE
            </div>
            <p className="text-slate-300 font-semibold">{project.timeline}</p>
          </div>
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 text-xs font-mono text-slate-500 uppercase tracking-widest font-bold">
              <Calendar size={13} className="text-blue-400" /> DURATION
            </div>
            <p className="text-slate-300 font-semibold">{project.duration}</p>
          </div>
          <div className="space-y-1.5">
            <div className="flex items-center gap-2 text-xs font-mono text-slate-500 uppercase tracking-widest font-bold">
              <User size={13} className="text-blue-400" /> TEAM / CLIENT
            </div>
            <p className="text-slate-300 font-semibold">{project.team}</p>
          </div>
        </div>

        {/* Tools Section */}
        <div className="p-6 bg-slate-950/60 border border-slate-800 rounded-xl flex flex-wrap gap-3 items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono text-slate-400 uppercase tracking-widest">TOOLS & METHODS:</span>
          </div>
          <div className="flex flex-wrap gap-2">
            {project.tools.map((tool, idx) => (
              <span key={idx} className="px-3 py-1 bg-slate-900 border border-slate-800 text-slate-300 rounded text-xs font-mono">
                {tool}
              </span>
            ))}
          </div>
        </div>

        {/* Primary Narrative Chapters */}
        <div className="space-y-16">
          {project.sections && project.sections.length > 0 ? (
            // Dynamic Modular Sections Rendering
            project.sections.map((section: ProjectSection, index: number) => {
              const renderSectionContent = () => {
                switch (section.type) {
                  case "hero-banner":
                    return (
                      <div className="relative py-24 px-8 sm:px-12 rounded-2xl overflow-hidden border border-slate-800 bg-cover bg-center" style={{ backgroundImage: `url(${section.content.backgroundImage})` }}>
                        <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-xs" />
                        <div className="relative z-10 max-w-2xl space-y-3">
                          <span className="text-[10px] font-mono tracking-[0.2em] uppercase text-sky-400 font-bold">HERO SHOWCASE</span>
                          <h1 className="text-3xl sm:text-4xl font-extrabold text-white leading-tight">{section.content.title}</h1>
                          {section.content.subtitle && <p className="text-base text-slate-300 font-light leading-relaxed">{section.content.subtitle}</p>}
                        </div>
                      </div>
                    );
                  
                  case "rich-text":
                    return (
                      <div className="prose prose-invert max-w-none text-slate-300 text-base leading-relaxed space-y-4">
                        <div dangerouslySetInnerHTML={{ __html: section.content.html || "" }} />
                      </div>
                    );

                  case "image":
                    return (
                      <div className="space-y-3">
                        <div className="group relative rounded-xl overflow-hidden border border-slate-800 bg-slate-900 cursor-zoom-in" onClick={() => setActivePhoto(section.content.url)}>
                          <img src={section.content.url} alt={section.content.alt || "Portfolio image"} className="w-full h-auto max-h-[600px] object-cover transition-transform duration-500 group-hover:scale-102" referrerPolicy="no-referrer" />
                          <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                            <span className="text-xs font-mono text-white bg-black/60 px-3 py-1.5 rounded-full border border-slate-700">ZOOM DETAILS</span>
                          </div>
                        </div>
                        {(section.content.caption || section.content.photographerCredit) && (
                          <div className="flex justify-between items-center px-2 text-xs text-slate-500 font-mono">
                            <span>{section.content.caption || "Industrial study"}</span>
                            {section.content.photographerCredit && <span className="text-slate-600">© {section.content.photographerCredit}</span>}
                          </div>
                        )}
                      </div>
                    );

                  case "image-gallery":
                    return (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        {section.content.urls?.map((url: string, i: number) => (
                          <div key={i} className="group relative rounded-xl overflow-hidden border border-slate-800 aspect-16/10 bg-slate-900 cursor-zoom-in" onClick={() => setActivePhoto(url)}>
                            <img src={url} alt={`Gallery view ${i+1}`} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" referrerPolicy="no-referrer" />
                            <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                              <span className="text-xs font-mono text-white bg-black/60 px-3 py-1.5 rounded-full border border-slate-700">ZOOM</span>
                            </div>
                          </div>
                        ))}
                      </div>
                    );

                  case "before-after-slider":
                    return (
                      <BeforeAfterSlider 
                        before={section.content.beforeImage} 
                        after={section.content.afterImage} 
                        labelBefore={section.content.labelBefore || "SKETCH / RENDER"} 
                        labelAfter={section.content.labelAfter || "PHYSICAL PROTOTYPE"} 
                      />
                    );

                  case "video":
                    return (
                      <div className="rounded-xl overflow-hidden border border-slate-800 bg-slate-950 shadow-2xl">
                        <video 
                          src={section.content.videoUrl} 
                          poster={section.content.posterUrl} 
                          controls={section.content.controls !== false} 
                          autoPlay={section.content.autoplay} 
                          loop={section.content.loop} 
                          muted={section.content.muted} 
                          className="w-full aspect-16/9 object-cover" 
                        />
                      </div>
                    );

                  case "embedded-video":
                    return (
                      <div className="aspect-16/9 rounded-xl overflow-hidden border border-slate-800 shadow-2xl">
                        <iframe 
                          src={section.content.embedUrl} 
                          className="w-full h-full border-0" 
                          allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" 
                          allowFullScreen 
                        />
                      </div>
                    );

                  case "pdf-viewer":
                    return (
                      <PDFViewerComponent pdfUrl={section.content.pdfUrl} title={section.content.title} />
                    );

                  case "quote":
                    return (
                      <div className="border-l-4 border-sky-400 bg-slate-900/20 p-6 md:p-8 rounded-r-2xl italic text-lg text-slate-200 font-sans leading-relaxed shadow-sm">
                        "{section.content.text}"
                        {(section.content.author || section.content.role) && (
                          <div className="text-[11px] font-mono tracking-wider text-slate-500 uppercase not-italic mt-3 flex items-center gap-2">
                            <span className="w-4 h-[1px] bg-slate-800" /> 
                            <span>{section.content.author}</span>
                            {section.content.role && <span className="text-slate-600">/ {section.content.role}</span>}
                          </div>
                        )}
                      </div>
                    );

                  case "research-block":
                    return (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-slate-950/40 p-6 rounded-2xl border border-slate-800/80">
                        <div className="space-y-2">
                          <h4 className="text-xs font-mono uppercase tracking-widest text-red-400 font-bold flex items-center gap-2">
                            <ShieldAlert size={12} /> CORE PROBLEM / FRUSTRATION
                          </h4>
                          <p className="text-sm text-slate-300 leading-relaxed">{section.content.question}</p>
                        </div>
                        <div className="space-y-2 border-t md:border-t-0 md:border-l border-slate-800/80 pt-4 md:pt-0 md:pl-6">
                          <h4 className="text-xs font-mono uppercase tracking-widest text-emerald-400 font-bold flex items-center gap-2">
                            <Check size={12} /> PROPOSED HYPOTHESIS
                          </h4>
                          <p className="text-sm text-slate-300 leading-relaxed">{section.content.hypothesis}</p>
                        </div>
                      </div>
                    );

                  case "problem-statement":
                    return (
                      <div className="p-6 bg-red-950/15 border border-red-900/30 rounded-xl space-y-3">
                        <h4 className="text-xs font-mono text-red-400 uppercase tracking-widest font-bold flex items-center gap-2">
                          <ShieldAlert size={14} /> {section.content.title || "THE SYSTEMIC CHALLENGE"}
                        </h4>
                        <p className="text-sm text-slate-300 leading-relaxed">{section.content.text}</p>
                      </div>
                    );

                  case "user-persona":
                    return (
                      <div className="bg-slate-950/40 border border-slate-800/80 rounded-2xl p-6 md:p-8 grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
                        <div className="md:col-span-4 flex flex-col items-center text-center">
                          <img src={section.content.avatar || "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=200"} className="w-24 h-24 rounded-full object-cover border-2 border-slate-800 shadow-xl" referrerPolicy="no-referrer" />
                          <h4 className="text-base font-bold text-white mt-4">{section.content.name || "Target User"}</h4>
                          <p className="text-xs font-mono text-slate-500 mt-0.5">{section.content.occupation || "Demographic Role"}</p>
                          <div className="mt-3 text-[10px] font-mono text-slate-400 bg-slate-900/80 border border-slate-800/50 px-3 py-1.5 rounded-full">
                            Age: {section.content.age || "32"} | {section.content.occupation || "Tech"}
                          </div>
                        </div>
                        <div className="md:col-span-8 space-y-5">
                          <p className="text-sm text-slate-400 italic leading-relaxed">"{section.content.bio}"</p>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-2">
                            <div className="space-y-2">
                              <h5 className="text-[10px] font-mono tracking-widest text-emerald-400 uppercase font-bold">GOALS & OBJECTIVES</h5>
                              <ul className="text-xs text-slate-300 space-y-1.5 list-disc list-inside">
                                {section.content.goals?.map((g: string, i: number) => <li key={i}>{g}</li>)}
                              </ul>
                            </div>
                            <div className="space-y-2">
                              <h5 className="text-[10px] font-mono tracking-widest text-red-400 uppercase font-bold">CRITICAL PAIN POINTS</h5>
                              <ul className="text-xs text-slate-300 space-y-1.5 list-disc list-inside">
                                {section.content.frustrations?.map((f: string, i: number) => <li key={i}>{f}</li>)}
                              </ul>
                            </div>
                          </div>
                        </div>
                      </div>
                    );

                  case "journey-map":
                    return (
                      <div className="overflow-x-auto pb-4 scrollbar-thin">
                        <div className="flex gap-4 min-w-[750px]">
                          {section.content.steps?.map((step: any, idx: number) => (
                            <div key={idx} className="flex-1 bg-slate-950/20 border border-slate-800/80 rounded-xl p-5 space-y-4">
                              <div className="flex justify-between items-center border-b border-slate-800/50 pb-2.5">
                                <span className="text-xs font-mono text-sky-400 uppercase font-bold tracking-wider">{step.label}</span>
                                <span className="text-base" title="Emotional State">{step.emotion || "😐"}</span>
                              </div>
                              <div className="space-y-3 text-xs leading-relaxed">
                                <div>
                                  <span className="text-slate-500 block font-mono text-[9px] uppercase tracking-wider mb-0.5">Actions</span> 
                                  <p className="text-slate-300">{step.actions}</p>
                                </div>
                                <div>
                                  <span className="text-slate-500 block font-mono text-[9px] uppercase tracking-wider mb-0.5">Thoughts</span> 
                                  <p className="text-slate-300">{step.thoughts}</p>
                                </div>
                                <div>
                                  <span className="text-sky-500 block font-mono text-[9px] uppercase tracking-wider mb-0.5">Opportunities</span> 
                                  <p className="text-slate-300">{step.opportunities}</p>
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    );

                  case "affinity-diagram":
                    return (
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {section.content.columns?.map((col: any, idx: number) => (
                          <div key={idx} className="bg-slate-950/50 border border-slate-800 rounded-xl p-5 space-y-4">
                            <h4 className="text-xs font-mono font-bold text-sky-400 border-b border-slate-800/60 pb-2 uppercase tracking-widest">{col.title}</h4>
                            <div className="space-y-2.5">
                              {col.items?.map((item: string, i: number) => (
                                <div key={i} className="bg-slate-900 border border-slate-800/60 p-3.5 rounded-lg text-xs text-slate-300 shadow-sm leading-relaxed">
                                  {item}
                                </div>
                              ))}
                            </div>
                          </div>
                        ))}
                      </div>
                    );

                  case "design-process-timeline":
                    return (
                      <div className="relative border-l border-slate-800 pl-6 ml-3 space-y-8 py-2">
                        {section.content.steps?.map((step: any, idx: number) => (
                          <div key={idx} className="relative">
                            <div className="absolute -left-9 top-1.5 w-6 h-6 rounded-full bg-slate-950 border-2 border-sky-400 flex items-center justify-center shadow-lg">
                              <span className="text-[10px] font-mono text-sky-400 font-bold">{idx + 1}</span>
                            </div>
                            <div className="text-[10px] font-mono text-slate-500 mb-0.5">{step.date || "Phase Goal"}</div>
                            <h4 className="text-sm font-bold text-slate-200 mb-1.5">{step.title}</h4>
                            <p className="text-xs text-slate-400 leading-relaxed">{step.description}</p>
                          </div>
                        ))}
                      </div>
                    );

                  case "sketch-gallery":
                  case "cad-gallery":
                  case "prototype-gallery":
                    return (
                      <div className="space-y-4">
                        <span className="text-xs font-mono uppercase tracking-[0.2em] text-sky-400 font-bold">{section.type.replace("-", " ")} Showcase</span>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          {section.content.images?.map((img: string, i: number) => (
                            <div key={i} className="group relative rounded-xl overflow-hidden border border-slate-800 aspect-16/10 bg-slate-900 cursor-zoom-in" onClick={() => setActivePhoto(img)}>
                              <img src={img} alt="" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" referrerPolicy="no-referrer" />
                              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-all flex items-center justify-center">
                                <span className="text-[10px] font-mono text-white bg-black/70 px-3 py-1.5 rounded-full border border-slate-700 uppercase tracking-widest">ZOOM IMAGE</span>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    );

                  case "testing-results":
                    return (
                      <div className="space-y-4 bg-slate-950/20 p-6 rounded-2xl border border-slate-800">
                        <h4 className="text-xs font-mono text-sky-400 uppercase tracking-widest font-bold">VERIFICATION BENCHMARKS:</h4>
                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                          {section.content.metrics?.map((m: any, i: number) => (
                            <div key={i} className="bg-slate-900/30 p-4 rounded-xl border border-slate-800/80 space-y-1.5">
                              <div className="flex justify-between text-xs text-slate-400">
                                <span>{m.name}</span>
                                <span className={m.status === "pass" ? "text-emerald-400 font-mono font-bold" : "text-amber-400 font-mono font-bold"}>{m.status?.toUpperCase() || "PASS"}</span>
                              </div>
                              <div className="flex justify-between items-baseline pt-1">
                                <span className="text-lg font-bold text-white font-mono">{m.value}</span>
                                <span className="text-[10px] font-mono text-slate-500">Target: {m.target}</span>
                              </div>
                            </div>
                          ))}
                        </div>
                        {section.content.notes && <p className="text-xs text-slate-400 leading-relaxed border-t border-slate-800/40 pt-3">{section.content.notes}</p>}
                      </div>
                    );

                  case "comparison-table":
                    return (
                      <div className="overflow-x-auto border border-slate-800 rounded-xl bg-slate-950/10">
                        <table className="w-full text-left border-collapse text-xs">
                          <thead>
                            <tr className="border-b border-slate-800 bg-slate-900/30 font-mono text-slate-400 uppercase tracking-widest text-[9px]">
                              {section.content.headers?.map((h: string, idx: number) => <th key={idx} className="p-4">{h}</th>)}
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-800/40 text-slate-300">
                            {section.content.rows?.map((row: string[], idx: number) => (
                              <tr key={idx} className="hover:bg-slate-900/10 transition-colors">
                                {row.map((cell: string, i: number) => <td key={i} className="p-4">{cell}</td>)}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    );

                  case "specifications-table":
                    return (
                      <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-950/20">
                        <div className="bg-slate-900/30 px-4 py-3 border-b border-slate-800">
                          <h4 className="text-xs font-mono font-bold text-slate-300 tracking-wider uppercase">CMF & MANUFACTURING SPECIFICATIONS</h4>
                        </div>
                        <div className="divide-y divide-slate-800/40 text-xs text-slate-300">
                          {section.content.specs?.map((spec: any, idx: number) => (
                            <div key={idx} className="flex justify-between p-4 hover:bg-slate-900/10 transition-colors">
                              <span className="font-mono text-slate-500 uppercase text-[10px]">{spec.key}</span>
                              <span className="font-bold text-slate-200">{spec.value}</span>
                            </div>
                          ))}
                        </div>
                      </div>
                    );

                  case "reflection":
                    return (
                      <div className="bg-gradient-to-r from-blue-950/15 to-sky-950/15 border border-sky-900/20 rounded-2xl p-6 md:p-8 space-y-3">
                        <h4 className="text-xs font-mono text-sky-400 uppercase tracking-widest font-bold">PAWAN'S RETROSPECTIVE & PROJECT MATURATION</h4>
                        <p className="text-slate-300 italic leading-relaxed text-sm">"{section.content.text}"</p>
                      </div>
                    );

                  case "downloads":
                    return (
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {section.content.files?.map((file: any, i: number) => (
                          <a key={i} href={file.url} className="px-5 py-4 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-slate-300 hover:text-white rounded-xl font-mono text-[10px] tracking-wider flex items-center gap-3.5 transition-all cursor-pointer">
                            <FileDown size={14} className="text-sky-400 shrink-0" />
                            <div className="flex-1 text-left truncate">
                              <div className="font-bold truncate text-slate-200">{file.name}</div>
                              <div className="text-[9px] text-slate-500 uppercase mt-0.5">{file.type || "FILE"} | {file.size || "Unknown Size"}</div>
                            </div>
                          </a>
                        ))}
                      </div>
                    );

                  case "call-to-action":
                    return (
                      <div className="p-8 rounded-2xl bg-slate-950 border border-slate-800/80 text-center space-y-4">
                        <p className="text-sm sm:text-base text-slate-300 leading-relaxed max-w-lg mx-auto">{section.content.text}</p>
                        {section.content.buttonText && (
                          <a href={section.content.buttonUrl || "#"} className="inline-flex px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-mono text-[10px] tracking-wider transition-all cursor-pointer">
                            {section.content.buttonText}
                          </a>
                        )}
                      </div>
                    );

                  case "two-column":
                    return (
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-start">
                        <div className="space-y-4">
                          {section.content.col1Html ? (
                            <div className="prose prose-invert text-slate-300 text-sm leading-relaxed" dangerouslySetInnerHTML={{ __html: section.content.col1Html }} />
                          ) : (
                            <p className="text-slate-300 text-sm leading-relaxed">{section.content.textLeft}</p>
                          )}
                        </div>
                        <div className="space-y-4">
                          {section.content.col2Html ? (
                            <div className="prose prose-invert text-slate-300 text-sm leading-relaxed" dangerouslySetInnerHTML={{ __html: section.content.col2Html }} />
                          ) : section.content.imageUrl ? (
                            <img src={section.content.imageUrl} className="w-full rounded-xl border border-slate-800 cursor-zoom-in" onClick={() => setActivePhoto(section.content.imageUrl)} referrerPolicy="no-referrer" />
                          ) : (
                            <p className="text-slate-300 text-sm leading-relaxed">{section.content.textRight}</p>
                          )}
                        </div>
                      </div>
                    );

                  case "three-column":
                    return (
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
                        <div className="space-y-3">
                          {section.content.col1Html ? (
                            <div className="text-slate-300 text-sm leading-relaxed" dangerouslySetInnerHTML={{ __html: section.content.col1Html }} />
                          ) : (
                            <p className="text-slate-300 text-sm leading-relaxed">{section.content.textCol1}</p>
                          )}
                        </div>
                        <div className="space-y-3 border-t md:border-t-0 md:border-x border-slate-800/40 pt-4 md:pt-0 md:px-6">
                          {section.content.col2Html ? (
                            <div className="text-slate-300 text-sm leading-relaxed" dangerouslySetInnerHTML={{ __html: section.content.col2Html }} />
                          ) : (
                            <p className="text-slate-300 text-sm leading-relaxed">{section.content.textCol2}</p>
                          )}
                        </div>
                        <div className="space-y-3 border-t md:border-t-0 pt-4 md:pt-0">
                          {section.content.col3Html ? (
                            <div className="text-slate-300 text-sm leading-relaxed" dangerouslySetInnerHTML={{ __html: section.content.col3Html }} />
                          ) : (
                            <p className="text-slate-300 text-sm leading-relaxed">{section.content.textCol3}</p>
                          )}
                        </div>
                      </div>
                    );

                  case "full-width-image":
                    return (
                      <img src={section.content.url} className="w-full rounded-2xl border border-slate-800 cursor-zoom-in" onClick={() => setActivePhoto(section.content.url)} referrerPolicy="no-referrer" />
                    );

                  case "image-text":
                    return (
                      <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
                        <div className={`md:col-span-6 ${section.content.imagePosition === "right" ? "md:order-2" : ""}`}>
                          <img src={section.content.url} className="w-full rounded-xl border border-slate-800 cursor-zoom-in" onClick={() => setActivePhoto(section.content.url)} referrerPolicy="no-referrer" />
                        </div>
                        <div className="md:col-span-6 text-slate-300 space-y-4">
                          <h3 className="text-lg font-bold text-white">{section.content.title}</h3>
                          <p className="text-sm leading-relaxed">{section.content.text}</p>
                        </div>
                      </div>
                    );

                  case "video-text":
                    return (
                      <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-center">
                        <div className={`md:col-span-6 ${section.content.videoPosition === "right" ? "md:order-2" : ""}`}>
                          <video src={section.content.url} controls className="w-full rounded-xl border border-slate-800" />
                        </div>
                        <div className="md:col-span-6 text-slate-300 space-y-4">
                          <h3 className="text-lg font-bold text-white">{section.content.title}</h3>
                          <p className="text-sm leading-relaxed">{section.content.text}</p>
                        </div>
                      </div>
                    );

                  case "accordion":
                    return (
                      <InteractiveAccordion items={section.content.items || []} />
                    );

                  case "tabs":
                    return (
                      <InteractiveTabs items={section.content.items || []} />
                    );

                  case "carousel":
                    return (
                      <InteractiveCarousel urls={section.content.urls || []} />
                    );

                  case "interactive-timeline":
                    return (
                      <div className="space-y-8 relative pl-6 border-l border-sky-900/40">
                        {section.content.items?.map((item: any, idx: number) => (
                          <div key={idx} className="relative group">
                            <span className="absolute -left-9 top-1 w-5 h-5 bg-slate-950 border border-sky-400 rounded-full flex items-center justify-center text-[10px] text-sky-400 font-mono font-bold group-hover:scale-110 transition-transform">{item.year || (idx + 1)}</span>
                            <h4 className="text-base font-bold text-white">{item.title}</h4>
                            <p className="text-sm text-slate-400 leading-relaxed mt-1">{item.text}</p>
                            {item.imageUrl && <img src={item.imageUrl} className="mt-3 max-w-md w-full rounded-xl border border-slate-800 cursor-zoom-in" onClick={() => setActivePhoto(item.imageUrl)} referrerPolicy="no-referrer" />}
                          </div>
                        ))}
                      </div>
                    );

                  default:
                    return null;
                }
              };

              return (
                <div key={section.id || index} className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start border-t border-slate-800/40 pt-16 first:border-t-0 first:pt-0">
                  <div className="md:col-span-4 sticky top-24">
                    <span className="text-[10px] font-mono text-sky-400 uppercase tracking-[0.2em] font-bold">SECTION {String(index + 1).padStart(2, "0")}</span>
                    <h2 className="text-xl font-bold text-white mt-1 capitalize">{section.type.replace("-", " ")}</h2>
                  </div>
                  <div className="md:col-span-8">
                    {renderSectionContent()}
                  </div>
                </div>
              );
            })
          ) : (
            // Original Hardcoded Fallback Layout (Guarantees backward compatibility)
            <>
              {/* Chapter 1: Project Overview & The Problem */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
                <div className="md:col-span-4 sticky top-24">
                  <span className="text-xs font-mono text-blue-400 uppercase tracking-[0.2em] font-bold">01 / SITUATION</span>
                  <h2 className="text-2xl font-bold text-white mt-1">Overview & Context</h2>
                </div>
                <div className="md:col-span-8 space-y-6 text-slate-300 text-base leading-relaxed">
                  <p>{project.overview}</p>
                  <div className="p-6 bg-red-950/15 border border-red-900/30 rounded-xl space-y-3">
                    <h3 className="text-sm font-mono tracking-wider text-red-400 uppercase font-bold flex items-center gap-2">
                      <ShieldAlert size={14} /> THE DESIGN CHALLENGE
                    </h3>
                    <p className="text-sm text-slate-400">{project.problem}</p>
                  </div>
                </div>
              </div>

              {/* Chapter 2: Research & Insights */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start border-t border-slate-800/40 pt-16">
                <div className="md:col-span-4 sticky top-24">
                  <span className="text-xs font-mono text-blue-400 uppercase tracking-[0.2em] font-bold">02 / KNOWLEDGE</span>
                  <h2 className="text-2xl font-bold text-white mt-1">Research & Synthesis</h2>
                </div>
                <div className="md:col-span-8 space-y-6 text-slate-300 text-base leading-relaxed">
                  <p>{project.research}</p>
                  <div className="bg-slate-950 border border-slate-800 rounded-2xl p-6">
                    <h4 className="text-xs font-mono text-sky-400 uppercase tracking-widest font-bold mb-4">CRITICAL INSIGHTS FORMED:</h4>
                    <div className="space-y-4 text-sm text-slate-400">
                      {project.insights.split("\n").map((insight, idx) => (
                        <div key={idx} className="flex gap-3 items-start">
                          <span className="w-1.5 h-1.5 bg-sky-400 rounded-full mt-2 shrink-0" />
                          <p>{insight.replace(/^\d+\.\s*/, "")}</p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Chapter 3: Ideation & Hand Sketches */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start border-t border-slate-800/40 pt-16">
                <div className="md:col-span-4 sticky top-24">
                  <span className="text-xs font-mono text-blue-400 uppercase tracking-[0.2em] font-bold">03 / INCEPTION</span>
                  <h2 className="text-2xl font-bold text-white mt-1">Ideation & Sketches</h2>
                </div>
                <div className="md:col-span-8 space-y-6 text-slate-300 text-base leading-relaxed">
                  <p>{project.ideation}</p>

                  {/* Sketches Image Grid */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {project.sketches.map((img, i) => (
                      <div
                        key={i}
                        onClick={() => setActivePhoto(img)}
                        className="group relative rounded-xl overflow-hidden border border-slate-800 aspect-3/2 bg-slate-900 cursor-zoom-in"
                      >
                        <img src={img} alt="Hand sketch" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                        <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <span className="text-xs font-mono text-white bg-black/60 px-3 py-1.5 rounded-full border border-slate-700">ZOOM SKETCH</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Chapter 4: CAD Architecture */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start border-t border-slate-800/40 pt-16">
                <div className="md:col-span-4 sticky top-24">
                  <span className="text-xs font-mono text-blue-400 uppercase tracking-[0.2em] font-bold">04 / SPECIFICATION</span>
                  <h2 className="text-2xl font-bold text-white mt-1">CAD & Engineering</h2>
                </div>
                <div className="md:col-span-8 space-y-6 text-slate-300 text-base leading-relaxed">
                  <p>{project.cad}</p>

                  {/* CAD Render Images */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {project.cadRenders.map((img, i) => (
                      <div
                        key={i}
                        onClick={() => setActivePhoto(img)}
                        className="group relative rounded-xl overflow-hidden border border-slate-800 aspect-3/2 bg-slate-900 cursor-zoom-in"
                      >
                        <img src={img} alt="CAD rendering" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                        <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <span className="text-xs font-mono text-white bg-black/60 px-3 py-1.5 rounded-full border border-slate-700">ZOOM RENDER</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Chapter 5: Physical Prototyping & Lab Testing */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start border-t border-slate-800/40 pt-16">
                <div className="md:col-span-4 sticky top-24">
                  <span className="text-xs font-mono text-blue-400 uppercase tracking-[0.2em] font-bold">05 / VERIFICATION</span>
                  <h2 className="text-2xl font-bold text-white mt-1">Prototyping & Testing</h2>
                </div>
                <div className="md:col-span-8 space-y-6 text-slate-300 text-base leading-relaxed">
                  <p>{project.prototype}</p>

                  {/* Prototype Photos */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    {project.prototypePhotos.map((img, i) => (
                      <div
                        key={i}
                        onClick={() => setActivePhoto(img)}
                        className="group relative rounded-xl overflow-hidden border border-slate-800 aspect-3/2 bg-slate-900 cursor-zoom-in"
                      >
                        <img src={img} alt="Physical prototype study" className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                        <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                          <span className="text-xs font-mono text-white bg-black/60 px-3 py-1.5 rounded-full border border-slate-700">ZOOM PHOTO</span>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className="p-6 bg-slate-950/60 border border-slate-800 rounded-xl space-y-2">
                    <h4 className="text-xs font-mono text-sky-400 uppercase tracking-wider font-bold">LAB TESTING DIAGNOSTICS:</h4>
                    <p className="text-sm text-slate-400">{project.testing}</p>
                  </div>
                </div>
              </div>

              {/* Chapter 6: Final Outcome & Retrospective */}
              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start border-t border-slate-800/40 pt-16">
                <div className="md:col-span-4 sticky top-24">
                  <span className="text-xs font-mono text-blue-400 uppercase tracking-[0.2em] font-bold">06 / MATURATION</span>
                  <h2 className="text-2xl font-bold text-white mt-1">Final Design & Reflections</h2>
                </div>
                <div className="md:col-span-8 space-y-6 text-slate-300 text-base leading-relaxed">
                  <p>{project.finalDesign}</p>

                  {/* Reflection Callout */}
                  <div className="bg-gradient-to-r from-blue-950/20 to-sky-950/20 border border-sky-900/30 rounded-2xl p-6 md:p-8 space-y-3">
                    <h4 className="text-xs font-mono text-sky-400 uppercase tracking-widest font-bold">PAWAN'S RETROSPECTIVE & LEARNINGS</h4>
                    <p className="text-slate-300 italic leading-relaxed text-sm">
                      "{project.reflection}"
                    </p>
                  </div>
                </div>
              </div>

              {/* Supplementary Project Gallery */}
              {project.gallery && project.gallery.length > 0 && (
                <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start border-t border-slate-800/40 pt-16">
                  <div className="md:col-span-4 sticky top-24">
                    <span className="text-xs font-mono text-blue-400 uppercase tracking-[0.2em] font-bold">07 / GALLERY</span>
                    <h2 className="text-2xl font-bold text-white mt-1">Extended Showcase</h2>
                    <p className="text-xs text-slate-500 font-mono mt-2 leading-relaxed">Additional high-resolution renders, material specs, and manufacturing blueprints.</p>
                  </div>
                  <div className="md:col-span-8">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {project.gallery.map((img, i) => (
                        <div
                          key={i}
                          onClick={() => setActivePhoto(img)}
                          className="group relative rounded-xl overflow-hidden border border-slate-800 aspect-3/2 bg-slate-900 cursor-zoom-in"
                        >
                          <img src={img} alt={`Extended showcase ${i+1}`} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                          <div className="absolute inset-0 bg-black/30 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                            <span className="text-xs font-mono text-white bg-black/60 px-3 py-1.5 rounded-full border border-slate-700">ZOOM IMAGE</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Media Downloads / Additional links */}
        {(project.downloadUrl || project.videoUrl) && (
          <div className="border-t border-slate-800/80 pt-12 flex flex-col sm:flex-row gap-4 justify-center items-center">
            {project.downloadUrl && (
              <a
                href={project.downloadUrl}
                className="w-full sm:w-auto px-6 py-3.5 bg-blue-600 hover:bg-blue-700 border border-blue-500/30 text-white rounded-xl font-mono text-xs tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                <FileDown size={16} /> DOWNLOAD SKETCHPACK / PDF
              </a>
            )}
            {project.videoUrl && (
              <a
                href={project.videoUrl}
                target="_blank"
                rel="noreferrer"
                className="w-full sm:w-auto px-6 py-3.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 rounded-xl font-mono text-xs tracking-wider flex items-center justify-center gap-2 transition-all cursor-pointer"
              >
                VIEW DESIGN DEMO REEL
              </a>
            )}
          </div>
        )}

        {/* Next / Previous Project Navigation */}
        <div className="border-t border-slate-800/80 pt-16 flex justify-between items-center gap-4">
          {prevProject ? (
            <button
              onClick={() => onNavigate(prevProject)}
              className="flex flex-col text-left group max-w-[45%] cursor-pointer"
            >
              <span className="text-[10px] font-mono text-slate-500 group-hover:text-blue-400 uppercase tracking-widest transition-colors mb-1">
                PREVIOUS PROJECT
              </span>
              <span className="text-sm md:text-lg font-bold text-slate-300 group-hover:text-white transition-colors line-clamp-1">
                {prevProject.title}
              </span>
            </button>
          ) : (
            <div />
          )}

          {nextProject ? (
            <button
              onClick={() => onNavigate(nextProject)}
              className="flex flex-col text-right group max-w-[45%] items-end cursor-pointer"
            >
              <span className="text-[10px] font-mono text-slate-500 group-hover:text-blue-400 uppercase tracking-widest transition-colors mb-1">
                NEXT PROJECT
              </span>
              <span className="text-sm md:text-lg font-bold text-slate-300 group-hover:text-white transition-colors line-clamp-1">
                {nextProject.title}
              </span>
            </button>
          ) : (
            <div />
          )}
        </div>
      </div>

      {/* Floating full-screen image viewer lightbox */}
      <AnimatePresence>
        {activePhoto && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-4 cursor-zoom-out"
            onClick={() => setActivePhoto(null)}
          >
            <button
              onClick={() => setActivePhoto(null)}
              className="absolute top-6 right-6 p-2 text-slate-400 hover:text-white rounded-full hover:bg-slate-900 transition-colors cursor-pointer"
            >
              <X size={24} />
            </button>

            {/* Photo Navigator buttons if there are multiple images */}
            <div className="relative max-w-5xl max-h-[85vh] flex items-center justify-center">
              <img
                src={activePhoto}
                alt="Zoomed Detail"
                className="max-w-full max-h-[85vh] object-contain rounded-lg border border-slate-800 shadow-2xl"
                onClick={(e) => e.stopPropagation()} // Stop closing on click
              />

              <div className="absolute -bottom-10 left-1/2 -translate-x-1/2 text-xs font-mono text-slate-500 text-center">
                IMAGE {allImages.indexOf(activePhoto) + 1} OF {allImages.length}
              </div>
              
              {allImages.length > 1 && (
                <>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      const currentIdx = allImages.indexOf(activePhoto);
                      const prevIdx = (currentIdx - 1 + allImages.length) % allImages.length;
                      setActivePhoto(allImages[prevIdx]);
                    }}
                    className="absolute left-[-60px] p-3 bg-slate-900/80 text-white rounded-full border border-slate-800 hover:bg-slate-800 transition-all cursor-pointer hidden md:block"
                  >
                    <ArrowLeft size={18} />
                  </button>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      const currentIdx = allImages.indexOf(activePhoto);
                      const nextIdx = (currentIdx + 1) % allImages.length;
                      setActivePhoto(allImages[nextIdx]);
                    }}
                    className="absolute right-[-60px] p-3 bg-slate-900/80 text-white rounded-full border border-slate-800 hover:bg-slate-800 transition-all cursor-pointer hidden md:block"
                  >
                    <ArrowRight size={18} />
                  </button>
                </>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

import { useEffect, useState, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";

interface LoadingScreenProps {
  onComplete: () => void;
}

export default function LoadingScreen({ onComplete }: LoadingScreenProps) {
  const [progress, setProgress] = useState(0);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const onCompleteRef = useRef(onComplete);

  // Sync the latest onComplete callback
  useEffect(() => {
    onCompleteRef.current = onComplete;
  }, [onComplete]);

  // Loading progress simulation
  useEffect(() => {
    const startTime = Date.now();
    const duration = 2400; // 2.4 seconds

    const updateProgress = () => {
      const elapsed = Date.now() - startTime;
      const calculated = Math.min(Math.floor((elapsed / duration) * 100), 100);
      setProgress(calculated);

      if (calculated < 100) {
        requestAnimationFrame(updateProgress);
      } else {
        setTimeout(() => {
          onCompleteRef.current();
        }, 500); // Small pause for the final transition
      }
    };

    requestAnimationFrame(updateProgress);
  }, []);

  // Morphing blob & particle canvas background
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener("resize", handleResize);

    // Liquid blob coordinates
    let angle = 0;
    const blobRadius = Math.min(width, height) * 0.18;

    // Particles array
    const particles: { x: number; y: number; size: number; speedY: number; opacity: number }[] = [];
    for (let i = 0; i < 40; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height + height,
        size: Math.random() * 3 + 1,
        speedY: -(Math.random() * 1.5 + 0.5),
        opacity: Math.random() * 0.5 + 0.2,
      });
    }

    const draw = () => {
      ctx.fillStyle = "rgba(4, 8, 18, 0.15)"; // Soft trails
      ctx.fillRect(0, 0, width, height);

      // 1. Draw slow ambient particles
      particles.forEach((p) => {
        p.y += p.speedY;
        if (p.y < -20) {
          p.y = height + 20;
          p.x = Math.random() * width;
        }
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(96, 165, 250, ${p.opacity})`;
        ctx.fill();
      });

      // 2. Draw dynamic blue morphing liquid blob in center
      const centerX = width / 2;
      const centerY = height / 2;
      angle += 0.015;

      ctx.save();
      ctx.beginPath();

      // Create a complex morphing closed loop path using radial coordinates and sine/cosine modifiers
      const numPoints = 8;
      const points: { x: number; y: number }[] = [];

      for (let i = 0; i < numPoints; i++) {
        const theta = (i / numPoints) * Math.PI * 2;
        // Superimpose multiple sine waves for morphing organic motion
        const morphFactor1 = Math.sin(angle + i * 1.5) * 28;
        const morphFactor2 = Math.cos(angle * 1.3 - i) * 18;
        const radius = blobRadius + morphFactor1 + morphFactor2;

        const x = centerX + Math.cos(theta) * radius;
        const y = centerY + Math.sin(theta) * radius;
        points.push({ x, y });
      }

      // Draw curve through points smoothly
      ctx.moveTo(points[0].x, points[0].y);
      for (let i = 0; i < numPoints; i++) {
        const p1 = points[i];
        const p2 = points[(i + 1) % numPoints];
        const xc = (p1.x + p2.x) / 2;
        const yc = (p1.y + p2.y) / 2;
        ctx.quadraticCurveTo(p1.x, p1.y, xc, yc);
      }
      ctx.closePath();

      // Deep glowing blue gradient
      const gradient = ctx.createRadialGradient(
        centerX - blobRadius / 3,
        centerY - blobRadius / 3,
        20,
        centerX,
        centerY,
        blobRadius * 1.5
      );
      gradient.addColorStop(0, "#3b82f6"); // Bright blue
      gradient.addColorStop(0.5, "#1d4ed8"); // Royal blue
      gradient.addColorStop(1, "#0a1c36"); // Deep dark navy

      ctx.fillStyle = gradient;
      ctx.shadowBlur = 80;
      ctx.shadowColor = "rgba(29, 78, 216, 0.6)";
      ctx.fill();
      ctx.restore();

      animationId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <motion.div
      id="loading-screen"
      className="fixed inset-0 bg-[#040812] z-50 flex flex-col justify-between p-8 md:p-16 select-none overflow-hidden"
      exit={{ opacity: 0, scale: 1.05, transition: { duration: 0.8, ease: [0.76, 0, 0.24, 1] } }}
    >
      {/* Background Canvas */}
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full pointer-events-none" />

      {/* Top Section */}
      <div className="relative z-10 flex justify-between items-start">
        <div>
          <h2 className="text-sm font-mono tracking-widest text-slate-400 font-bold">PAWAN K. KUSHWAHA</h2>
          <p className="text-xs font-mono tracking-wider text-slate-500 uppercase">Product & Industrial Designer</p>
        </div>
        <div className="text-right">
          <p className="text-sm font-mono text-slate-400 font-bold">2026</p>
          <p className="text-xs font-mono text-slate-500 uppercase">PORTFOLIO EDITION</p>
        </div>
      </div>

      {/* Center Section: Title & Visual */}
      <div className="relative z-10 flex flex-col items-center justify-center text-center my-auto">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.2 }}
          className="space-y-3"
        >
          <h1 className="text-4xl md:text-7xl font-sans tracking-[0.2em] font-extrabold text-white leading-none">
            PAWAN
          </h1>
          <p className="text-xs md:text-sm font-mono tracking-[0.4em] text-sky-400 uppercase font-bold">
            INDUSTRIAL DESIGNER
          </p>
        </motion.div>
      </div>

      {/* Bottom Section: Progress & Tech */}
      <div className="relative z-10 flex justify-between items-end">
        <div className="max-w-[12rem] md:max-w-xs">
          <p className="text-[11px] font-mono leading-relaxed text-slate-400 uppercase tracking-wider">
            Loading interactive product renders, CAD mechanics & fluid design processes.
          </p>
        </div>
        <div className="text-right">
          <span className="text-6xl md:text-8xl font-sans font-black tracking-tighter text-white">
            {progress}%
          </span>
          <div className="w-40 md:w-56 h-[2px] bg-slate-800 rounded-full mt-2 overflow-hidden ml-auto">
            <motion.div
              className="h-full bg-sky-400 shadow-[0_0_10px_#60a5fa]"
              style={{ width: `${progress}%` }}
              transition={{ ease: "easeOut" }}
            />
          </div>
        </div>
      </div>
    </motion.div>
  );
}

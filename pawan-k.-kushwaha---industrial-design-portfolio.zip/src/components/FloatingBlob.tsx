import { useEffect, useRef } from "react";

export default function FloatingBlob() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const mouseRef = useRef({ x: 0, y: 0, targetX: 0, targetY: 0, isHovering: false });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationId: number;
    const dpr = window.devicePixelRatio || 1;
    let width = canvas.parentElement?.clientWidth || window.innerWidth;
    let height = canvas.parentElement?.clientHeight || window.innerHeight;

    const setupCanvasSize = () => {
      canvas.width = width * dpr;
      canvas.height = height * dpr;
      ctx.scale(dpr, dpr);
    };
    setupCanvasSize();

    const getRadius = (w: number, h: number) => {
      const minDim = Math.min(w, h);
      if (w < 640) {
        return minDim * 0.36;
      }
      return minDim * 0.38;
    };

    const getCenter = (w: number, h: number, r: number) => {
      return { cx: w / 2, cy: h / 2 };
    };

    const handleResize = () => {
      if (!canvas.parentElement) return;
      width = canvas.parentElement.clientWidth;
      height = canvas.parentElement.clientHeight;
      setupCanvasSize();
    };
    window.addEventListener("resize", handleResize);

    const handleMouseMove = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      mouseRef.current.targetX = e.clientX - rect.left;
      mouseRef.current.targetY = e.clientY - rect.top;
      mouseRef.current.isHovering = true;
    };

    const handleMouseLeave = () => {
      mouseRef.current.isHovering = false;
    };

    window.addEventListener("mousemove", handleMouseMove);
    canvas.addEventListener("mouseleave", handleMouseLeave);

    // Initial position using calculated center
    const initialRadius = getRadius(width, height);
    const initialCenter = getCenter(width, height, initialRadius);
    mouseRef.current.x = initialCenter.cx;
    mouseRef.current.y = initialCenter.cy;
    mouseRef.current.targetX = initialCenter.cx;
    mouseRef.current.targetY = initialCenter.cy;

    // Loading rotation/phase angles
    let angle1 = 0; // Clockwise fast
    let angle2 = 0; // Counter-clockwise slow
    let scanAngle = 0; // Sweeping radar line

    const draw = () => {
      ctx.clearRect(0, 0, width, height);

      // Lerp mouse coordinates for custom fluid springy feel
      const mouse = mouseRef.current;
      mouse.x += (mouse.targetX - mouse.x) * 0.05;
      mouse.y += (mouse.targetY - mouse.y) * 0.05;

      // Base radius of the interactive loading circle
      const baseRadius = getRadius(width, height);

      // Centering calculations
      const { cx: centerX, cy: centerY } = getCenter(width, height, baseRadius);

      // Advance rotation angles over time (slowed down for elegant interactive rendering feel)
      angle1 += 0.003;
      angle2 -= 0.001;
      scanAngle += 0.004;

      // -------------------------------------------------------------
      // 1. Draw outer dashed precision ring (Rotating telemetry)
      // -------------------------------------------------------------
      ctx.save();
      ctx.strokeStyle = "rgba(0, 240, 255, 0.65)"; // Glowing electric cyan ring
      ctx.lineWidth = 1;
      ctx.setLineDash([4, 12]);
      ctx.beginPath();
      ctx.arc(centerX, centerY, baseRadius * 1.15, angle1, angle1 + Math.PI * 2);
      ctx.stroke();
      ctx.restore();

      // -------------------------------------------------------------
      // 3. Draw middle solid caliper-ticks (Precisely spaced measurements)
      // -------------------------------------------------------------
      const numTicks = 60;
      for (let i = 0; i < numTicks; i++) {
        const tickAngle = (i / numTicks) * Math.PI * 2;
        const startRad = baseRadius * 0.95;
        const endRad = i % 5 === 0 ? baseRadius * 1.02 : baseRadius * 0.98;

        // Calculate proximity to radar sweep scanner for a glowing ripple effect
        let delta = Math.abs(tickAngle - (scanAngle % (Math.PI * 2)));
        if (delta > Math.PI) delta = Math.PI * 2 - delta;
        const proximity = Math.max(0, 1 - delta / 1.5); // Scan width influence

        ctx.strokeStyle = `rgba(0, 240, 255, ${0.45 + proximity * 0.55})`; // Stronger baseline contrast
        ctx.lineWidth = i % 5 === 0 ? 1.5 : 1;

        ctx.beginPath();
        ctx.moveTo(
          centerX + Math.cos(tickAngle) * startRad,
          centerY + Math.sin(tickAngle) * startRad
        );
        ctx.lineTo(
          centerX + Math.cos(tickAngle) * endRad,
          centerY + Math.sin(tickAngle) * endRad
        );
        ctx.stroke();
      }

      // -------------------------------------------------------------
      // 4. Draw bold "loading progress" arc tracks
      // -------------------------------------------------------------
      ctx.save();
      ctx.strokeStyle = "rgba(0, 240, 255, 0.95)"; // Intense electric cyan arc
      ctx.lineWidth = 4; // Thicker, more prominent arc tracking
      
      // Arc 1
      ctx.beginPath();
      ctx.arc(
        centerX,
        centerY,
        baseRadius * 0.85,
        angle2,
        angle2 + Math.PI * 0.65 + Math.sin(angle1 * 1.5) * 0.3
      );
      ctx.stroke();

      // Arc 2 (glowing offset track)
      ctx.strokeStyle = "rgba(29, 78, 216, 0.7)"; // Vibrant royal blue guide track
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(
        centerX,
        centerY,
        baseRadius * 0.82,
        angle2 + Math.PI,
        angle2 + Math.PI * 1.45
      );
      ctx.stroke();
      ctx.restore();

      // -------------------------------------------------------------
      // 5. Draw inner morphing liquid "Quantum Core" (High-tech load center)
      // -------------------------------------------------------------
      ctx.save();
      ctx.beginPath();

      const corePointsCount = 8;
      const corePoints: { x: number; y: number }[] = [];
      const coreBaseRadius = baseRadius * 0.42;

      for (let i = 0; i < corePointsCount; i++) {
        const theta = (i / corePointsCount) * Math.PI * 2;
        // Superimpose organic waves with mouse coordinate stretch for reactive spring
        const wave1 = Math.sin(angle1 + i * 1.4) * 12;
        const wave2 = Math.cos(angle2 * 2 - i * 0.7) * 6;

        // Push core outward/inward depending on mouse proximity
        const pX = centerX + Math.cos(theta) * coreBaseRadius;
        const pY = centerY + Math.sin(theta) * coreBaseRadius;
        const dx = mouse.x - pX;
        const dy = mouse.y - pY;
        const dist = Math.sqrt(dx * dx + dy * dy);

        let mouseDeform = 0;
        if (dist < 200) {
          const force = (1 - dist / 200) * 16;
          mouseDeform = -force; // Pull core slightly toward mouse or push
        }

        const radius = coreBaseRadius + wave1 + wave2 + mouseDeform;
        const x = centerX + Math.cos(theta) * radius;
        const y = centerY + Math.sin(theta) * radius;
        corePoints.push({ x, y });
      }

      ctx.moveTo(corePoints[0].x, corePoints[0].y);
      for (let i = 0; i < corePointsCount; i++) {
        const p1 = corePoints[i];
        const p2 = corePoints[(i + 1) % corePointsCount];
        const xc = (p1.x + p2.x) / 2;
        const yc = (p1.y + p2.y) / 2;
        ctx.quadraticCurveTo(p1.x, p1.y, xc, yc);
      }
      ctx.closePath();

      // Deep glowing blue gradient matching the Loading Screen style exactly
      const coreGradient = ctx.createRadialGradient(
        centerX - coreBaseRadius / 3,
        centerY - coreBaseRadius / 3,
        20,
        centerX,
        centerY,
        coreBaseRadius * 1.5
      );
      coreGradient.addColorStop(0, "#3b82f6"); // Bright blue
      coreGradient.addColorStop(0.5, "#1d4ed8"); // Royal blue
      coreGradient.addColorStop(1, "#0a1c36"); // Deep dark navy

      ctx.fillStyle = coreGradient;
      ctx.shadowBlur = 80;
      ctx.shadowColor = "rgba(29, 78, 216, 0.6)";
      ctx.fill();
      ctx.restore();

      // -------------------------------------------------------------
      // 6. Draw interactive mouse-tracking Reticle / Satellite Dot
      // -------------------------------------------------------------
      // Calculate angle from center to mouse position
      const mouseAngle = Math.atan2(mouse.y - centerY, mouse.x - centerX);
      const satRadius = baseRadius * 0.95;
      const satX = centerX + Math.cos(mouseAngle) * satRadius;
      const satY = centerY + Math.sin(mouseAngle) * satRadius;

      // Outer satellite glowing halo
      ctx.save();
      ctx.shadowBlur = 20;
      ctx.shadowColor = "#00ffff";
      ctx.fillStyle = "#ffffff"; // Bright white core for absolute maximum contrast
      ctx.beginPath();
      ctx.arc(satX, satY, 5, 0, Math.PI * 2);
      ctx.fill();

      // Pulsing secondary halo
      const ringPulse = (Date.now() / 600) % 1;
      ctx.strokeStyle = `rgba(0, 240, 255, ${1 - ringPulse})`;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(satX, satY, 5 + ringPulse * 16, 0, Math.PI * 2);
      ctx.stroke();

      // Draw pointer connection line (Center -> Satellite)
      ctx.strokeStyle = "rgba(0, 240, 255, 0.55)"; // Brighter dashed vector pointer
      ctx.lineWidth = 1;
      ctx.setLineDash([2, 4]);
      ctx.beginPath();
      ctx.moveTo(centerX, centerY);
      ctx.lineTo(satX, satY);
      ctx.stroke();
      ctx.restore();

      // -------------------------------------------------------------
      // 7. Draw Industrial Precise HUD Telemetry overlay text
      // -------------------------------------------------------------
      ctx.save();
      ctx.font = "10px JetBrains Mono";
      ctx.fillStyle = "rgba(148, 163, 184, 0.85)"; // Highly legible slate-300 with high opacity

      // Orbit Rotation Degree display
      const deg = Math.round(((mouseAngle >= 0 ? mouseAngle : Math.PI * 2 + mouseAngle) * 180) / Math.PI);
      
      // Top Left quadrant label
      ctx.fillText(`ANG: ${deg.toString().padStart(3, "0")}°`, centerX - baseRadius * 0.65, centerY - baseRadius * 0.45);
      
      // Loading Simulation speed
      const fakeRpm = 1800 + Math.floor(Math.sin(angle1 * 1.2) * 250);
      ctx.fillText(`RPM: ${fakeRpm}`, centerX - baseRadius * 0.65, centerY - baseRadius * 0.45 + 14);

      // System interactive status
      ctx.fillStyle = "rgba(0, 240, 255, 0.9)"; // High visibility cyan blue
      ctx.fillText(`SYS_LOAD: ${(80 + Math.sin(angle2) * 5).toFixed(1)}%`, centerX - baseRadius * 0.65, centerY - baseRadius * 0.45 + 28);

      // Bottom center small developer tag
      ctx.font = "8px JetBrains Mono";
      ctx.fillStyle = "rgba(148, 163, 184, 0.55)";
      ctx.textAlign = "center";
      ctx.fillText("PAWAN_CMS_INTERACTIVE_HUD_v2.0", centerX, centerY + baseRadius * 0.55);

      ctx.restore();

      animationId = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener("resize", handleResize);
      window.removeEventListener("mousemove", handleMouseMove);
      canvas.removeEventListener("mouseleave", handleMouseLeave);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 w-full h-full pointer-events-none"
      style={{ mixBlendMode: "screen" }}
    />
  );
}

import React, { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  CMSData, Profile, Project, DesignStage, SocialLink, SoftwareTool, 
  EducationItem, ExperienceItem, ProjectSection, MediaAsset 
} from "../types";
import {
  X, Lock, Unlock, Plus, Trash2, Edit2, Save, RotateCcw, Download, Upload,
  Eye, Settings, FolderKanban, User, Workflow, Sparkles, Info, ArrowUp, ArrowDown,
  Link, Briefcase, GraduationCap, Award, MapPin, Wrench, Folder, Image, Video,
  FileText, Layout, Copy, Check, CheckSquare, Globe, Search, File, Trash, PlusCircle,
  RefreshCw, Laptop, Tablet, Smartphone, Bold, Italic, List, ListOrdered, Heading1,
  Heading2, Table, ChevronRight, Shield, AlertTriangle, LogOut, CheckSquare as CheckSquareIcon,
  Quote, Sliders, Play, FileDown
} from "lucide-react";
import ProjectDetail from "./ProjectDetail";

interface AdminCMSProps {
  isOpen: boolean;
  onClose: () => void;
  cmsData: CMSData;
  onUpdate: (newData: CMSData) => void;
  initialTab?: CMSTab;
  initialEditingProject?: Project | null;
}

type CMSTab = "dashboard" | "projects" | "profile" | "stages" | "media";

export default function AdminCMS({ 
  isOpen, 
  onClose, 
  cmsData, 
  onUpdate,
  initialTab,
  initialEditingProject
}: AdminCMSProps) {
  // Auth State
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [email, setEmail] = useState("kushwahapawan.design@gmail.com");
  const [password, setPassword] = useState("pawan@portfolio");
  const [authError, setAuthError] = useState("");
  const [token, setToken] = useState<string | null>(null);
  const [userRole, setUserRole] = useState<"admin" | "editor" | "viewer">("admin");

  // Navigation state
  const [activeTab, setActiveTab] = useState<CMSTab>("dashboard");

  // Project Management state
  const [editingProject, setEditingProject] = useState<Project | null>(null);

  // Synchronize Tab and Project state from outside triggers (e.g. Admin Mode quick links)
  useEffect(() => {
    if (isOpen) {
      if (initialTab) {
        setActiveTab(initialTab);
      }
      if (initialEditingProject !== undefined) {
        setEditingProject(initialEditingProject);
      }
    }
  }, [isOpen, initialTab, initialEditingProject]);
  const [projectEditorTab, setProjectEditorTab] = useState<"general" | "page-builder" | "legacy-fields" | "media" | "seo">("general");
  const [isPreviewMode, setIsPreviewMode] = useState(false);
  const [previewDevice, setPreviewDevice] = useState<"desktop" | "tablet" | "mobile">("desktop");
  
  // Media State
  const [mediaAssets, setMediaAssets] = useState<MediaAsset[]>([]);
  const [mediaFolder, setMediaFolder] = useState<"all" | "images" | "videos" | "pdfs">("all");
  const [mediaSearch, setMediaSearch] = useState("");
  const [selectedAssetForField, setSelectedAssetForField] = useState<{ blockId?: string; fieldName: string; index?: number; isProfileField?: boolean } | null>(null);
  const [isAssetSelectorOpen, setIsAssetSelectorOpen] = useState(false);
  const [uploadProgress, setUploadProgress] = useState<{ [key: string]: number }>({});
  const [bulkSelected, setBulkSelected] = useState<string[]>([]);

  // Notion visual rich text editor state
  const [richTextTarget, setRichTextTarget] = useState<{ blockId: string; currentHtml: string } | null>(null);

  // Auto-save Indicator state
  const [saveStatus, setSaveStatus] = useState<"saved" | "saving" | "unsaved">("saved");
  const autoSaveTimerRef = useRef<NodeJS.Timeout | null>(null);

  // Custom Toast State
  const [toast, setToast] = useState<{ message: string; type: "success" | "error" | "info" } | null>(null);

  const showToast = (message: string, type: "success" | "error" | "info" = "success") => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  // Load Auth Token & check from session on mount
  useEffect(() => {
    const savedToken = localStorage.getItem("cms_auth_token");
    const savedRole = localStorage.getItem("cms_user_role");
    if (savedToken) {
      setToken(savedToken);
      setUserRole((savedRole as any) || "admin");
      setIsAuthenticated(true);
    }
    fetchMediaLibrary();
  }, []);

  // Fetch Media Library from server
  const fetchMediaLibrary = async () => {
    try {
      const res = await fetch("/api/media");
      if (res.ok) {
        const data = await res.json();
        setMediaAssets(data);
      }
    } catch (e) {
      console.error("Could not fetch media list", e);
    }
  };

  // Auto-save handler
  const triggerAutoSave = (updatedData: CMSData) => {
    setSaveStatus("saving");
    if (autoSaveTimerRef.current) clearTimeout(autoSaveTimerRef.current);

    autoSaveTimerRef.current = setTimeout(async () => {
      try {
        const headers: HeadersInit = { "Content-Type": "application/json" };
        if (token) headers["Authorization"] = `Bearer ${token}`;

        const res = await fetch("/api/cms-data", {
          method: "POST",
          headers,
          body: JSON.stringify(updatedData)
        });
        if (res.ok) {
          setSaveStatus("saved");
          onUpdate(updatedData);
        } else {
          setSaveStatus("unsaved");
        }
      } catch (err) {
        setSaveStatus("unsaved");
      }
    }, 1500);
  };

  // Manual save handler
  const handleManualSave = async () => {
    if (userRole === "viewer") {
      showToast("Unauthorized: View-only permissions", "error");
      return;
    }
    setSaveStatus("saving");
    if (autoSaveTimerRef.current) clearTimeout(autoSaveTimerRef.current);
    try {
      const headers: HeadersInit = { "Content-Type": "application/json" };
      if (token) headers["Authorization"] = `Bearer ${token}`;

      const res = await fetch("/api/cms-data", {
        method: "POST",
        headers,
        body: JSON.stringify(cmsData)
      });
      if (res.ok) {
        setSaveStatus("saved");
        showToast("All changes saved successfully!", "success");
      } else {
        setSaveStatus("unsaved");
        showToast("Failed to save changes on server", "error");
      }
    } catch (err) {
      setSaveStatus("unsaved");
      showToast("Network error. Could not reach server.", "error");
    }
  };

  // Login handler
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
      });
      const data = await res.json();
      if (res.ok) {
        setIsAuthenticated(true);
        setToken(data.token);
        setUserRole(data.user.role);
        localStorage.setItem("cms_auth_token", data.token);
        localStorage.setItem("cms_user_role", data.user.role);
        showToast(`Logged in successfully as ${data.user.role}!`, "success");
      } else {
        setAuthError(data.error || "Invalid email or passcode.");
      }
    } catch (err) {
      setAuthError("Server unreachable. Logging in locally in offline mode.");
      if (password === "pawan@portfolio") {
        setIsAuthenticated(true);
        setToken("offline-token");
        setUserRole("admin");
      }
    }
  };

  // Logout handler
  const handleLogout = () => {
    setIsAuthenticated(false);
    setToken(null);
    localStorage.removeItem("cms_auth_token");
    localStorage.removeItem("cms_user_role");
    showToast("Signed out safely", "info");
  };

  // Media File uploads via Base64 proxy
  const handleMediaUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      const fileId = `${Date.now()}-${file.name}`;
      
      // Simulate progress bar visually
      setUploadProgress(prev => ({ ...prev, [fileId]: 10 }));
      const reader = new FileReader();
      
      reader.onload = async (event) => {
        setUploadProgress(prev => ({ ...prev, [fileId]: 40 }));
        const base64Data = event.target?.result as string;

        try {
          setUploadProgress(prev => ({ ...prev, [fileId]: 70 }));
          const res = await fetch("/api/media", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              ...(token ? { "Authorization": `Bearer ${token}` } : {})
            },
            body: JSON.stringify({
              name: file.name,
              type: file.type,
              size: file.size,
              base64: base64Data
            })
          });

          if (res.ok) {
            const newAsset = await res.json();
            setUploadProgress(prev => ({ ...prev, [fileId]: 100 }));
            showToast(`Uploaded ${file.name} successfully!`, "success");
            setMediaAssets(prev => [newAsset, ...prev]);
            
            // Auto fill field if selected
            if (selectedAssetForField) {
              applySelectedAssetUrl(newAsset.url);
            }
          } else {
            showToast(`Could not upload ${file.name}`, "error");
          }
        } catch (error) {
          showToast(`Network error uploading ${file.name}`, "error");
        } finally {
          setTimeout(() => {
            setUploadProgress(prev => {
              const updated = { ...prev };
              delete updated[fileId];
              return updated;
            });
          }, 1000);
        }
      };

      reader.readAsDataURL(file);
    }
  };

  // Select asset URL handler
  const openMediaLibraryForField = (fieldName: string, blockId?: string, index?: number, isProfileField?: boolean) => {
    setSelectedAssetForField({ fieldName, blockId, index, isProfileField });
    setIsAssetSelectorOpen(true);
  };

  const applySelectedAssetUrl = (url: string) => {
    if (!selectedAssetForField) return;
    const { fieldName, blockId, index, isProfileField } = selectedAssetForField;

    if (isProfileField) {
      handleProfileChange(fieldName as keyof Profile, url);
    } else if (editingProject) {
      if (blockId) {
        // In modular page builder block
        const updatedSections = editingProject.sections.map(sec => {
          if (sec.id === blockId) {
            const updatedContent = { ...sec.content };
            if (index !== undefined && Array.isArray(updatedContent[fieldName])) {
              const arr = [...updatedContent[fieldName]];
              arr[index] = url;
              updatedContent[fieldName] = arr;
            } else {
              updatedContent[fieldName] = url;
            }
            return { ...sec, content: updatedContent };
          }
          return sec;
        });
        handleProjectUpdate({ ...editingProject, sections: updatedSections });
      } else {
        // Regular project field
        handleProjectUpdate({ ...editingProject, [fieldName]: url });
      }
    }

    setIsAssetSelectorOpen(false);
    setSelectedAssetForField(null);
    showToast("Linked asset successfully", "success");
  };

  // Media delete handler
  const handleDeleteMedia = async (id: string) => {
    if (userRole === "viewer") {
      showToast("Unauthorized: View-only permissions", "error");
      return;
    }
    if (!confirm("Delete this asset permanently?")) return;
    try {
      const res = await fetch(`/api/media/${id}`, {
        method: "DELETE",
        headers: token ? { "Authorization": `Bearer ${token}` } : {}
      });
      if (res.ok) {
        setMediaAssets(prev => prev.filter(m => m.id !== id));
        showToast("Asset deleted", "success");
      }
    } catch (e) {
      showToast("Could not delete asset", "error");
    }
  };

  // Media Bulk Delete
  const handleBulkDelete = async () => {
    if (userRole === "viewer") {
      showToast("Unauthorized: View-only permissions", "error");
      return;
    }
    if (bulkSelected.length === 0) return;
    if (!confirm(`Delete all ${bulkSelected.length} selected assets?`)) return;

    for (const id of bulkSelected) {
      try {
        await fetch(`/api/media/${id}`, {
          method: "DELETE",
          headers: token ? { "Authorization": `Bearer ${token}` } : {}
        });
      } catch (e) {
        console.error(e);
      }
    }
    setMediaAssets(prev => prev.filter(m => !bulkSelected.includes(m.id)));
    setBulkSelected([]);
    showToast("Bulk assets removed", "success");
  };

  // Project Editor Actions
  const handleProjectUpdate = (updatedProj: Project) => {
    setEditingProject(updatedProj);
    const updatedProjectsList = cmsData.projects.map(p => p.id === updatedProj.id ? updatedProj : p);
    const updatedData = { ...cmsData, projects: updatedProjectsList };
    triggerAutoSave(updatedData);
  };

  const handleCreateNewProject = () => {
    if (userRole === "viewer") {
      showToast("Unauthorized: View-only permissions", "error");
      return;
    }
    const newProj: Project = {
      id: `project-${Date.now()}`,
      title: "New Interactive Product Render",
      subtitle: "Bespoke Design Study",
      category: "Industrial Design",
      year: "2026",
      role: "Lead Industrial Designer",
      duration: "3 Months",
      timeline: "3 Months",
      tools: ["CAD", "Rendering", "Prototyping", "Casing"],
      description: "Bespoke design study and thermodynamic engineering exploration.",
      client: "Innovation Labs",
      team: "Solo Design Study",
      status: "draft",
      featured: false,
      heroImage: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?q=80&w=1600",
      heroVideo: "",
      gallery: [],
      overview: "A comprehensive design project outline exploring high-performance packaging.",
      problem: "Traditional structural enclosures struggle with modern thermal dissipation requirements.",
      research: "Investigated advanced polymers and aerospace cooling fin geometry structures.",
      insights: "1. Air intake paths benefit from streamlined fluid dynamics.\n2. Passive dissipation reduces device decibel profile.",
      ideation: "Developed over 100 quick micro sketches detailing sleek modern lines and robust structural points.",
      sketches: ["https://images.unsplash.com/photo-1513542789411-b6a5d4f31634?q=80&w=600"],
      cad: "Engineered solid-body assembly architecture using Autodesk Fusion 360 with detailed parameters.",
      cadRenders: ["https://images.unsplash.com/photo-1581092160607-ee22621dd758?q=80&w=600"],
      prototype: "Constructed structural 1:1 test models using high-resolution PLA additive manufacturing.",
      prototypePhotos: ["https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?q=80&w=600"],
      testing: "Passed thermal and acoustic diagnostics showing a 23% increase in air velocity.",
      finalDesign: "The finished assembly marries extreme structural durability with premium tactile slate details.",
      reflection: "Iterative physical-to-digital validation loops vastly reduced alignment errors.",
      conclusion: "Ready for low-volume CNC tooling and plastic molding fabrication.",
      downloadUrl: "",
      seoTitle: "Pawan Kushwaha - Industrial Project Study",
      seoDescription: "An in-depth portfolio review of dynamic product casing architectures.",
      seoKeywords: "Industrial design, CAD, prototype, rendering",
      sections: []
    };

    const updatedData = { ...cmsData, projects: [newProj, ...cmsData.projects] };
    onUpdate(updatedData);
    setEditingProject(newProj);
    setProjectEditorTab("general");
    showToast("New project shell created!", "success");
  };

  const handleDeleteProject = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (userRole === "viewer") {
      showToast("Unauthorized: View-only permissions", "error");
      return;
    }
    if (!confirm("Are you sure you want to delete this project permanently?")) return;
    
    const updatedProjects = cmsData.projects.filter(p => p.id !== id);
    const updatedData = { ...cmsData, projects: updatedProjects };
    onUpdate(updatedData);
    if (editingProject?.id === id) {
      setEditingProject(null);
    }
    showToast("Project deleted successfully", "success");
  };

  // Reorder Projects
  const handleMoveProject = (idx: number, dir: "up" | "down", e: React.MouseEvent) => {
    e.stopPropagation();
    if (userRole === "viewer") return;
    const targetIdx = dir === "up" ? idx - 1 : idx + 1;
    if (targetIdx < 0 || targetIdx >= cmsData.projects.length) return;

    const list = [...cmsData.projects];
    const temp = list[idx];
    list[idx] = list[targetIdx];
    list[targetIdx] = temp;

    onUpdate({ ...cmsData, projects: list });
    showToast("Project layout reordered", "info");
  };

  // Modular Page Builder Helpers
  const handleAddSectionBlock = (type: string) => {
    if (!editingProject) return;
    const newSection: ProjectSection = {
      id: `block-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      type: type as any,
      content: {
        title: "Block Section Title",
        subtitle: "Enter structural text",
        html: "<p>Write rich, well-formatted content here...</p>",
        text: "Pawan's technical design assessment.",
        url: "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?q=80&w=1200",
        urls: ["https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?q=80&w=600"],
        beforeImage: "https://images.unsplash.com/photo-1513542789411-b6a5d4f31634?q=80&w=600",
        afterImage: "https://images.unsplash.com/photo-1581092160607-ee22621dd758?q=80&w=600",
        items: [{ title: "Phase 1 Setup", content: "Details" }],
        metrics: [{ name: "Decibel Profile", value: "32 dB", target: "35 dB", status: "pass" }]
      }
    };

    const updatedSections = editingProject.sections ? [...editingProject.sections, newSection] : [newSection];
    handleProjectUpdate({ ...editingProject, sections: updatedSections });
    showToast(`Added ${type.replace("-", " ")} section!`, "success");
  };

  const handleRemoveSectionBlock = (id: string) => {
    if (!editingProject) return;
    const updatedSections = editingProject.sections.filter(s => s.id !== id);
    handleProjectUpdate({ ...editingProject, sections: updatedSections });
    showToast("Section block removed", "info");
  };

  const handleDuplicateSectionBlock = (section: ProjectSection) => {
    if (!editingProject) return;
    const duplicated: ProjectSection = {
      ...section,
      id: `block-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`
    };
    const updatedSections = [...editingProject.sections, duplicated];
    handleProjectUpdate({ ...editingProject, sections: updatedSections });
    showToast("Block duplicated successfully", "success");
  };

  const handleMoveSectionBlock = (idx: number, dir: "up" | "down") => {
    if (!editingProject) return;
    const targetIdx = dir === "up" ? idx - 1 : idx + 1;
    if (targetIdx < 0 || targetIdx >= editingProject.sections.length) return;

    const list = [...editingProject.sections];
    const temp = list[idx];
    list[idx] = list[targetIdx];
    list[targetIdx] = temp;

    handleProjectUpdate({ ...editingProject, sections: list });
  };

  // Profile Save
  const handleProfileChange = (field: keyof Profile, value: any) => {
    if (userRole === "viewer") return;
    const updatedProfile = { ...cmsData.profile, [field]: value };
    const updatedData = { ...cmsData, profile: updatedProfile };
    onUpdate(updatedData);
    triggerAutoSave(updatedData);
  };

  // Experience Helpers
  const handleExperienceChange = (idx: number, field: keyof ExperienceItem, value: any) => {
    if (userRole === "viewer") return;
    const currentExp = [...(cmsData.profile.experience || [])];
    currentExp[idx] = { ...currentExp[idx], [field]: value };
    handleProfileChange("experience", currentExp);
  };

  const handleAddExperience = () => {
    if (userRole === "viewer") return;
    const currentExp = [...(cmsData.profile.experience || [])];
    currentExp.push({
      role: "Industrial Design Lead",
      company: "Design Studio / Company",
      period: "2024 - Present",
      description: "Led client hardware definition, full CAD modeling, and industrial styling loops."
    });
    handleProfileChange("experience", currentExp);
    showToast("Added new experience item", "success");
  };

  const handleDeleteExperience = (idx: number) => {
    if (userRole === "viewer") return;
    const currentExp = (cmsData.profile.experience || []).filter((_, i) => i !== idx);
    handleProfileChange("experience", currentExp);
    showToast("Deleted experience item", "info");
  };

  const handleMoveExperience = (idx: number, direction: "up" | "down") => {
    if (userRole === "viewer") return;
    const currentExp = [...(cmsData.profile.experience || [])];
    const targetIdx = direction === "up" ? idx - 1 : idx + 1;
    if (targetIdx < 0 || targetIdx >= currentExp.length) return;
    
    const temp = currentExp[idx];
    currentExp[idx] = currentExp[targetIdx];
    currentExp[targetIdx] = temp;
    
    handleProfileChange("experience", currentExp);
  };

  // Methodology Stages Save
  const handleStageChange = (idx: number, field: keyof DesignStage, value: any) => {
    if (userRole === "viewer") return;
    const updatedStages = cmsData.stages.map((stg, i) => i === idx ? { ...stg, [field]: value } : stg);
    const updatedData = { ...cmsData, stages: updatedStages };
    onUpdate(updatedData);
    triggerAutoSave(updatedData);
  };

  const handleAddStage = () => {
    if (userRole === "viewer") return;
    const defaultIds = ["discover", "research", "insights", "concept", "sketch", "cad", "prototype", "testing", "manufacturing", "reflection"];
    const currentIds = cmsData.stages.map(s => s.id);
    let nextId = `stage-${Date.now()}`;
    for (const dId of defaultIds) {
      if (!currentIds.includes(dId)) {
        nextId = dId;
        break;
      }
    }
    const newStage: DesignStage = {
      id: nextId,
      title: "NEW STAGE TITLE",
      description: "Define the core focus and methodologies for this design stage.",
      details: ["Define deliverable item"]
    };
    const updatedStages = [...cmsData.stages, newStage];
    const updatedData = { ...cmsData, stages: updatedStages };
    onUpdate(updatedData);
    triggerAutoSave(updatedData);
    showToast("Added new methodology stage", "success");
  };

  const handleDeleteStage = (idx: number) => {
    if (userRole === "viewer") return;
    const updatedStages = cmsData.stages.filter((_, i) => i !== idx);
    const updatedData = { ...cmsData, stages: updatedStages };
    onUpdate(updatedData);
    triggerAutoSave(updatedData);
    showToast("Deleted methodology stage", "info");
  };

  const handleMoveStage = (idx: number, direction: "up" | "down") => {
    if (userRole === "viewer") return;
    const updatedStages = [...cmsData.stages];
    const targetIdx = direction === "up" ? idx - 1 : idx + 1;
    if (targetIdx < 0 || targetIdx >= updatedStages.length) return;

    const temp = updatedStages[idx];
    updatedStages[idx] = updatedStages[targetIdx];
    updatedStages[targetIdx] = temp;

    const updatedData = { ...cmsData, stages: updatedStages };
    onUpdate(updatedData);
    triggerAutoSave(updatedData);
  };

  // Academic Timeline (Education) helpers
  const handleEducationChange = (idx: number, field: keyof EducationItem, value: any) => {
    if (userRole === "viewer") return;
    const currentEdu = [...(cmsData.profile.education || [])];
    currentEdu[idx] = { ...currentEdu[idx], [field]: value };
    handleProfileChange("education", currentEdu);
  };

  const handleAddEducation = () => {
    if (userRole === "viewer") return;
    const currentEdu = [...(cmsData.profile.education || [])];
    currentEdu.push({
      degree: "Degree / Certification",
      school: "Institution Name",
      year: "2026"
    });
    handleProfileChange("education", currentEdu);
    showToast("Added new academic credential", "success");
  };

  const handleDeleteEducation = (idx: number) => {
    if (userRole === "viewer") return;
    const currentEdu = (cmsData.profile.education || []).filter((_, i) => i !== idx);
    handleProfileChange("education", currentEdu);
    showToast("Deleted academic credential", "info");
  };

  const handleMoveEducation = (idx: number, direction: "up" | "down") => {
    if (userRole === "viewer") return;
    const currentEdu = [...(cmsData.profile.education || [])];
    const targetIdx = direction === "up" ? idx - 1 : idx + 1;
    if (targetIdx < 0 || targetIdx >= currentEdu.length) return;
    
    const temp = currentEdu[idx];
    currentEdu[idx] = currentEdu[targetIdx];
    currentEdu[targetIdx] = temp;
    
    handleProfileChange("education", currentEdu);
  };

  // Software helpers
  const handleSoftwareChange = (idx: number, field: keyof SoftwareTool, value: any) => {
    if (userRole === "viewer") return;
    const currentSoft = [...(cmsData.profile.software || [])];
    currentSoft[idx] = { ...currentSoft[idx], [field]: value };
    handleProfileChange("software", currentSoft);
  };

  const handleAddSoftware = () => {
    if (userRole === "viewer") return;
    const currentSoft = [...(cmsData.profile.software || [])];
    currentSoft.push({
      name: "New Software / Skill",
      level: 80,
      category: "CAD"
    });
    handleProfileChange("software", currentSoft);
    showToast("Added new software tool", "success");
  };

  const handleDeleteSoftware = (idx: number) => {
    if (userRole === "viewer") return;
    const currentSoft = (cmsData.profile.software || []).filter((_, i) => i !== idx);
    handleProfileChange("software", currentSoft);
    showToast("Deleted software tool", "info");
  };

  const handleMoveSoftware = (idx: number, direction: "up" | "down") => {
    if (userRole === "viewer") return;
    const currentSoft = [...(cmsData.profile.software || [])];
    const targetIdx = direction === "up" ? idx - 1 : idx + 1;
    if (targetIdx < 0 || targetIdx >= currentSoft.length) return;
    
    const temp = currentSoft[idx];
    currentSoft[idx] = currentSoft[targetIdx];
    currentSoft[targetIdx] = temp;
    
    handleProfileChange("software", currentSoft);
  };

  // Core Specialties (Skills) helpers
  const handleSkillChange = (idx: number, value: string) => {
    if (userRole === "viewer") return;
    const currentSkills = [...(cmsData.profile.skills || [])];
    currentSkills[idx] = value;
    handleProfileChange("skills", currentSkills);
  };

  const handleAddSkill = () => {
    if (userRole === "viewer") return;
    const currentSkills = [...(cmsData.profile.skills || [])];
    currentSkills.push("New Specialty");
    handleProfileChange("skills", currentSkills);
    showToast("Added new specialty", "success");
  };

  const handleDeleteSkill = (idx: number) => {
    if (userRole === "viewer") return;
    const currentSkills = (cmsData.profile.skills || []).filter((_, i) => i !== idx);
    handleProfileChange("skills", currentSkills);
    showToast("Deleted specialty", "info");
  };

  // Digital Channels (Socials) helpers
  const handleSocialChange = (idx: number, field: keyof SocialLink, value: any) => {
    if (userRole === "viewer") return;
    const currentSocials = [...(cmsData.profile.socials || [])];
    currentSocials[idx] = { ...currentSocials[idx], [field]: value };
    handleProfileChange("socials", currentSocials);
  };

  const handleAddSocial = () => {
    if (userRole === "viewer") return;
    const currentSocials = [...(cmsData.profile.socials || [])];
    currentSocials.push({
      name: "Platform",
      url: "https://"
    });
    handleProfileChange("socials", currentSocials);
    showToast("Added new social channel", "success");
  };

  const handleDeleteSocial = (idx: number) => {
    if (userRole === "viewer") return;
    const currentSocials = (cmsData.profile.socials || []).filter((_, i) => i !== idx);
    handleProfileChange("socials", currentSocials);
    showToast("Deleted social channel", "info");
  };

  const handleMoveSocial = (idx: number, direction: "up" | "down") => {
    if (userRole === "viewer") return;
    const currentSocials = [...(cmsData.profile.socials || [])];
    const targetIdx = direction === "up" ? idx - 1 : idx + 1;
    if (targetIdx < 0 || targetIdx >= currentSocials.length) return;
    
    const temp = currentSocials[idx];
    currentSocials[idx] = currentSocials[targetIdx];
    currentSocials[targetIdx] = temp;
    
    handleProfileChange("socials", currentSocials);
  };

  // Stage details helpers
  const handleStageDetailChange = (stageIdx: number, detailIdx: number, value: string) => {
    if (userRole === "viewer") return;
    const updatedStages = cmsData.stages.map((stg, sIdx) => {
      if (sIdx !== stageIdx) return stg;
      const updatedDetails = [...(stg.details || [])];
      updatedDetails[detailIdx] = value;
      return { ...stg, details: updatedDetails };
    });
    const updatedData = { ...cmsData, stages: updatedStages };
    onUpdate(updatedData);
    triggerAutoSave(updatedData);
  };

  const handleAddStageDetail = (stageIdx: number) => {
    if (userRole === "viewer") return;
    const updatedStages = cmsData.stages.map((stg, sIdx) => {
      if (sIdx !== stageIdx) return stg;
      const updatedDetails = [...(stg.details || [])];
      updatedDetails.push("New deliverable / methodology item");
      return { ...stg, details: updatedDetails };
    });
    const updatedData = { ...cmsData, stages: updatedStages };
    onUpdate(updatedData);
    triggerAutoSave(updatedData);
    showToast("Added new stage artifact item", "success");
  };

  const handleDeleteStageDetail = (stageIdx: number, detailIdx: number) => {
    if (userRole === "viewer") return;
    const updatedStages = cmsData.stages.map((stg, sIdx) => {
      if (sIdx !== stageIdx) return stg;
      const updatedDetails = (stg.details || []).filter((_, dIdx) => dIdx !== detailIdx);
      return { ...stg, details: updatedDetails };
    });
    const updatedData = { ...cmsData, stages: updatedStages };
    onUpdate(updatedData);
    triggerAutoSave(updatedData);
    showToast("Deleted stage artifact item", "info");
  };

  const handleMoveStageDetail = (stageIdx: number, detailIdx: number, direction: "up" | "down") => {
    if (userRole === "viewer") return;
    const updatedStages = cmsData.stages.map((stg, sIdx) => {
      if (sIdx !== stageIdx) return stg;
      const updatedDetails = [...(stg.details || [])];
      const targetIdx = direction === "up" ? detailIdx - 1 : detailIdx + 1;
      if (targetIdx < 0 || targetIdx >= updatedDetails.length) return stg;
      
      const temp = updatedDetails[detailIdx];
      updatedDetails[detailIdx] = updatedDetails[targetIdx];
      updatedDetails[targetIdx] = temp;
      return { ...stg, details: updatedDetails };
    });
    const updatedData = { ...cmsData, stages: updatedStages };
    onUpdate(updatedData);
    triggerAutoSave(updatedData);
  };

  // Filtering media
  const filteredMedia = mediaAssets.filter(asset => {
    const matchesSearch = asset.name.toLowerCase().includes(mediaSearch.toLowerCase());
    if (mediaFolder === "all") return matchesSearch;
    if (mediaFolder === "images") return matchesSearch && asset.type.startsWith("image/");
    if (mediaFolder === "videos") return matchesSearch && asset.type.startsWith("video/");
    if (mediaFolder === "pdfs") return matchesSearch && (asset.type === "application/pdf" || asset.name.endsWith(".pdf"));
    return matchesSearch;
  });

  // Toggle Bulk Selection
  const toggleBulkSelect = (id: string) => {
    if (bulkSelected.includes(id)) {
      setBulkSelected(prev => prev.filter(x => x !== id));
    } else {
      setBulkSelected(prev => [...prev, id]);
    }
  };

  // Visual rich text helper formatting commands
  const applyVisualFormatting = (tag: string, placeholder = "") => {
    if (!richTextTarget || !editingProject) return;
    const { blockId, currentHtml } = richTextTarget;
    let appended = "";
    
    if (tag === "bold") appended = `<strong>${placeholder || "Bold text"}</strong>`;
    else if (tag === "italic") appended = `<em>${placeholder || "Italic text"}</em>`;
    else if (tag === "h1") appended = `<h1 class="text-3xl font-bold text-white mt-4">${placeholder || "Heading 1"}</h1>`;
    else if (tag === "h2") appended = `<h2 class="text-2xl font-bold text-white mt-3">${placeholder || "Heading 2"}</h2>`;
    else if (tag === "bullet") appended = `<ul class="list-disc pl-5 my-2"><li>${placeholder || "List item"}</li></ul>`;
    else if (tag === "quote") appended = `<blockquote class="border-l-4 border-sky-400 bg-slate-900/30 p-4 rounded-r-lg my-2 italic">"${placeholder || "Quote description"}"</blockquote>`;
    else if (tag === "table") appended = `<table class="w-full my-4 border border-slate-800 text-sm"><tr class="bg-slate-900 border-b border-slate-800"><th class="p-2">Header 1</th><th class="p-2">Header 2</th></tr><tr><td class="p-2 border-r border-slate-800">Cell 1</td><td class="p-2">Cell 2</td></tr></table>`;

    const updatedHtml = currentHtml + appended;
    setRichTextTarget({ blockId, currentHtml: updatedHtml });

    const updatedSections = editingProject.sections.map(sec => {
      if (sec.id === blockId) {
        return { ...sec, content: { ...sec.content, html: updatedHtml } };
      }
      return sec;
    });
    handleProjectUpdate({ ...editingProject, sections: updatedSections });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950 flex">
      {/* Visual Toast Notification Overlay */}
      <AnimatePresence>
        {toast && (
          <motion.div 
            initial={{ opacity: 0, y: -40, scale: 0.9 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: -20, scale: 0.95 }}
            className={`fixed top-6 left-1/2 -translate-x-1/2 z-50 flex items-center gap-3.5 px-6 py-4 rounded-xl border font-mono text-xs tracking-wider shadow-2xl ${
              toast.type === "success" 
                ? "bg-emerald-950/90 border-emerald-500/30 text-emerald-300"
                : toast.type === "error"
                ? "bg-red-950/90 border-red-500/30 text-red-300"
                : "bg-sky-950/90 border-sky-500/30 text-sky-300"
            }`}
          >
            <Sparkles size={14} className={toast.type === "success" ? "animate-pulse" : ""} />
            <span>{toast.message.toUpperCase()}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main CMS Container Full Screen */}
      <motion.div 
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 12 }}
        transition={{ duration: 0.35, ease: "easeOut" }}
        className="w-full h-full bg-slate-950 flex flex-col relative text-slate-100"
      >
        {/* TOP STATUS BAR CONTAINER */}
        <header className="px-6 py-4 border-b border-slate-850 flex justify-between items-center bg-slate-950">
          <div className="flex items-center gap-3">
            <span className="w-2.5 h-2.5 rounded-full bg-sky-500 animate-pulse" />
            <h1 className="text-sm font-mono tracking-widest font-black text-white">PAWAN K. KUSHWAHA CMS v3.0</h1>
            <span className="text-[10px] bg-slate-900 border border-slate-800 px-2 py-0.5 rounded font-mono text-slate-400 capitalize">{userRole} MODE</span>
          </div>

          <div className="flex items-center gap-4">
            {isAuthenticated && (
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2 text-xs font-mono">
                  <span className={`w-2 h-2 rounded-full ${
                    saveStatus === "saved" ? "bg-emerald-500" : saveStatus === "saving" ? "bg-sky-500 animate-bounce" : "bg-red-500 animate-ping"
                  }`} />
                  <span className="text-slate-400 uppercase tracking-wider text-[10px]">
                    {saveStatus === "saved" ? "Draft Saved" : saveStatus === "saving" ? "Saving..." : "Changes Unsaved"}
                  </span>
                </div>
              </div>
            )}
            
            <button 
              onClick={onClose} 
              className="p-1.5 hover:bg-slate-900 border border-slate-800 rounded-lg text-slate-400 hover:text-white transition-all cursor-pointer"
            >
              <X size={16} />
            </button>
          </div>
        </header>

        {/* LOGIN OVERLAY PANEL */}
        {!isAuthenticated ? (
          <div className="flex-1 overflow-y-auto flex items-center justify-center p-6 bg-[radial-gradient(circle_at_center,rgba(4,11,23,1)_0%,rgba(0,0,0,1)_100%)]">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="w-full max-w-sm border border-slate-800/80 bg-slate-950/80 p-8 rounded-2xl space-y-6 shadow-2xl backdrop-blur-lg"
            >
              <div className="text-center space-y-2">
                <div className="w-12 h-12 rounded-full bg-blue-600/10 border border-blue-500/20 flex items-center justify-center mx-auto mb-3">
                  <Lock className="text-sky-400" size={20} />
                </div>
                <h2 className="text-lg font-bold text-white tracking-tight uppercase">SECURE PORTFOLIO PORTAL</h2>
                <p className="text-xs text-slate-500 font-mono">AUTHENTICATE INTEGRATION CREDENTIALS</p>
              </div>

              {authError && (
                <div className="p-3 bg-red-950/20 border border-red-500/30 rounded-xl text-xs text-red-400 font-mono text-center flex items-center justify-center gap-2">
                  <AlertTriangle size={14} /> {authError.toUpperCase()}
                </div>
              )}

              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-1">
                  <label className="text-[10px] font-mono uppercase tracking-widest text-slate-500 font-bold block">EMAIL OFFICE ADDRESS</label>
                  <input 
                    type="email" 
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-900 border border-slate-800 rounded-xl text-sm text-white focus:outline-hidden focus:border-blue-500 font-mono" 
                    required 
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-mono uppercase tracking-widest text-slate-500 font-bold block">PASSCODE SECURITY DECRYPT</label>
                  <input 
                    type="password" 
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full px-4 py-3 bg-slate-900 border border-slate-800 rounded-xl text-sm text-white focus:outline-hidden focus:border-blue-500 font-mono" 
                    required 
                  />
                </div>

                <button 
                  type="submit" 
                  className="w-full py-3.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-mono text-xs tracking-widest font-black uppercase transition-all flex items-center justify-center gap-2 shadow-lg shadow-blue-950/50 cursor-pointer"
                >
                  DECRYPT CREDENTIALS <Unlock size={14} />
                </button>
              </form>

              <div className="border-t border-slate-800/40 pt-4 text-center">
                <p className="text-[10px] font-mono text-slate-500">DEFAULT TEST: kushwahapawan.design@gmail.com / pawan@portfolio</p>
              </div>
            </motion.div>
          </div>
        ) : (
          /* PRIMARY AUTHENTICATED CMS INTERFACE */
          <div className="flex-1 flex overflow-hidden">
            {/* SIDE NAVIGATION RAIL */}
            <nav className="w-56 border-r border-slate-850 flex flex-col justify-between bg-slate-950">
              <div className="p-4 space-y-1.5">
                <span className="text-[9px] font-mono text-slate-500 uppercase tracking-widest font-bold px-3 block mb-2">WORKSPACE RAIL</span>
                
                <button 
                  onClick={() => { setActiveTab("dashboard"); setEditingProject(null); }}
                  className={`w-full px-3 py-2.5 rounded-xl font-mono text-[11px] tracking-wider flex items-center gap-3 transition-all cursor-pointer ${
                    activeTab === "dashboard" && !editingProject ? "bg-slate-900 text-white font-bold border border-slate-800" : "text-slate-400 hover:text-white hover:bg-slate-900/50"
                  }`}
                >
                  <Layout size={14} className="text-sky-400" />
                  DASHBOARD
                </button>

                <button 
                  onClick={() => { setActiveTab("projects"); setEditingProject(null); }}
                  className={`w-full px-3 py-2.5 rounded-xl font-mono text-[11px] tracking-wider flex items-center gap-3 transition-all cursor-pointer ${
                    (activeTab === "projects" || editingProject) ? "bg-slate-900 text-white font-bold border border-slate-800" : "text-slate-400 hover:text-white hover:bg-slate-900/50"
                  }`}
                >
                  <FolderKanban size={14} className="text-blue-400" />
                  CASE STUDIES
                </button>

                <button 
                  onClick={() => { setActiveTab("profile"); setEditingProject(null); }}
                  className={`w-full px-3 py-2.5 rounded-xl font-mono text-[11px] tracking-wider flex items-center gap-3 transition-all cursor-pointer ${
                    activeTab === "profile" ? "bg-slate-900 text-white font-bold border border-slate-800" : "text-slate-400 hover:text-white hover:bg-slate-900/50"
                  }`}
                >
                  <User size={14} className="text-emerald-400" />
                  PROFILE & EXP
                </button>

                <button 
                  onClick={() => { setActiveTab("stages"); setEditingProject(null); }}
                  className={`w-full px-3 py-2.5 rounded-xl font-mono text-[11px] tracking-wider flex items-center gap-3 transition-all cursor-pointer ${
                    activeTab === "stages" ? "bg-slate-900 text-white font-bold border border-slate-800" : "text-slate-400 hover:text-white hover:bg-slate-900/50"
                  }`}
                >
                  <Workflow size={14} className="text-purple-400" />
                  METHODOLOGY
                </button>

                <button 
                  onClick={() => { setActiveTab("media"); setEditingProject(null); }}
                  className={`w-full px-3 py-2.5 rounded-xl font-mono text-[11px] tracking-wider flex items-center gap-3 transition-all cursor-pointer ${
                    activeTab === "media" ? "bg-slate-900 text-white font-bold border border-slate-800" : "text-slate-400 hover:text-white hover:bg-slate-900/50"
                  }`}
                >
                  <Folder size={14} className="text-yellow-400" />
                  MEDIA LIBRARY
                </button>
              </div>

              {/* USER PROFILE INFO FOOTER */}
              <div className="p-4 border-t border-slate-850 space-y-3 bg-slate-950">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-blue-600 flex items-center justify-center font-bold text-sm text-white border border-slate-800">
                    P
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-white truncate">Pawan Kushwaha</p>
                    <p className="text-[9px] font-mono text-slate-500 truncate">kushwahapawan.design@gmail.com</p>
                  </div>
                </div>

                <button 
                  onClick={handleLogout}
                  className="w-full py-2 bg-red-950/15 hover:bg-red-950/35 border border-red-500/10 hover:border-red-500/25 rounded-xl text-[10px] font-mono text-red-400 uppercase tracking-widest font-bold transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  SIGN OUT <LogOut size={11} />
                </button>
              </div>
            </nav>

            {/* TAB CONTENT HOUSING */}
            <div className="flex-1 overflow-y-auto p-6 bg-slate-950">
              {/* IF EDITING A PROJECT - OVERRIDE RAIL VIEW WITH INTEGRATED CASE STUDY STUDIO */}
              {editingProject ? (
                <div className="space-y-6">
                  {/* EDIT PANEL HEADER */}
                  <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center border-b border-slate-850 pb-5">
                    <div>
                      <div className="flex items-center gap-2 text-xs font-mono text-slate-400">
                        <button onClick={() => setEditingProject(null)} className="hover:text-white">PROJECTS</button>
                        <ChevronRight size={12} />
                        <span className="text-white uppercase">{editingProject.title}</span>
                      </div>
                      <h2 className="text-2xl font-black text-white uppercase mt-1">CASE STUDY WORKBENCH</h2>
                    </div>

                    <div className="flex items-center gap-3 self-stretch sm:self-auto">
                      <button 
                        onClick={() => setIsPreviewMode(!isPreviewMode)}
                        className={`px-4 py-2.5 rounded-xl font-mono text-xs tracking-wider font-bold flex items-center gap-2 transition-all cursor-pointer ${
                          isPreviewMode 
                            ? "bg-sky-500 text-slate-950" 
                            : "bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-850"
                        }`}
                      >
                        <Eye size={13} /> {isPreviewMode ? "CLOSE PREVIEW" : "LIVE PREVIEW"}
                      </button>

                      <button 
                        onClick={() => { setEditingProject(null); showToast("Workbench exited safely", "info"); }}
                        className="px-4 py-2.5 bg-slate-900 hover:bg-slate-850 border border-slate-800 rounded-xl font-mono text-xs text-slate-300 hover:text-white tracking-wider flex items-center gap-2 transition-all cursor-pointer"
                      >
                        EXIT STUDIO
                      </button>
                    </div>
                  </div>

                  {/* LIVE PREVIEW SPLIT DEVICE DISPLAY CONTAINER */}
                  {isPreviewMode ? (
                    <div className="space-y-4">
                      {/* Responsive device switches */}
                      <div className="flex justify-center gap-2 bg-slate-900 border border-slate-800 p-2 rounded-xl max-w-sm mx-auto">
                        <button 
                          onClick={() => setPreviewDevice("desktop")} 
                          className={`p-2 rounded-lg transition-all cursor-pointer ${previewDevice === "desktop" ? "bg-sky-500 text-slate-950" : "text-slate-400 hover:text-white"}`}
                          title="Desktop View"
                        >
                          <Laptop size={16} />
                        </button>
                        <button 
                          onClick={() => setPreviewDevice("tablet")} 
                          className={`p-2 rounded-lg transition-all cursor-pointer ${previewDevice === "tablet" ? "bg-sky-500 text-slate-950" : "text-slate-400 hover:text-white"}`}
                          title="Tablet View"
                        >
                          <Tablet size={16} />
                        </button>
                        <button 
                          onClick={() => setPreviewDevice("mobile")} 
                          className={`p-2 rounded-lg transition-all cursor-pointer ${previewDevice === "mobile" ? "bg-sky-500 text-slate-950" : "text-slate-400 hover:text-white"}`}
                          title="Mobile View"
                        >
                          <Smartphone size={16} />
                        </button>
                      </div>

                      {/* Device viewport sizing wrapper */}
                      <div className="border border-slate-850 bg-slate-900/30 p-4 rounded-2xl flex justify-center overflow-hidden min-h-[500px]">
                        <div 
                          className={`bg-slate-950 border border-slate-800 transition-all duration-300 rounded-xl overflow-y-auto scrollbar-thin ${
                            previewDevice === "desktop" ? "w-full" : previewDevice === "tablet" ? "w-[768px] h-[750px]" : "w-[375px] h-[640px]"
                          }`}
                        >
                          <ProjectDetail 
                            project={editingProject} 
                            onClose={() => setIsPreviewMode(false)} 
                            allProjects={cmsData.projects}
                            onNavigate={() => {}}
                          />
                        </div>
                      </div>
                    </div>
                  ) : (
                    /* WORKBENCH EDIT TABS */
                    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                      {/* Left Column Settings Tabs Selection Column */}
                      <div className="lg:col-span-3 flex flex-row lg:flex-col gap-1 border-b lg:border-b-0 lg:border-r border-slate-850 pb-4 lg:pb-0 lg:pr-4 overflow-x-auto">
                        <button 
                          onClick={() => setProjectEditorTab("general")}
                          className={`px-3 py-2.5 rounded-xl font-mono text-[11px] tracking-wider text-left shrink-0 transition-all cursor-pointer flex items-center gap-2.5 ${
                            projectEditorTab === "general" ? "bg-slate-900 text-white font-bold" : "text-slate-400 hover:text-white hover:bg-slate-900/30"
                          }`}
                        >
                          <Settings size={12} className="text-sky-400" /> General Info
                        </button>

                        <button 
                          onClick={() => setProjectEditorTab("page-builder")}
                          className={`px-3 py-2.5 rounded-xl font-mono text-[11px] tracking-wider text-left shrink-0 transition-all cursor-pointer flex items-center gap-2.5 ${
                            projectEditorTab === "page-builder" ? "bg-slate-900 text-white font-bold" : "text-slate-400 hover:text-white hover:bg-slate-900/30"
                          }`}
                        >
                          <Layout size={12} className="text-blue-400" /> Modular Blocks
                        </button>

                        <button 
                          onClick={() => setProjectEditorTab("media")}
                          className={`px-3 py-2.5 rounded-xl font-mono text-[11px] tracking-wider text-left shrink-0 transition-all cursor-pointer flex items-center gap-2.5 ${
                            projectEditorTab === "media" ? "bg-slate-900 text-white font-bold" : "text-slate-400 hover:text-white hover:bg-slate-900/30"
                          }`}
                        >
                          <Image size={12} className="text-yellow-400" /> Media & Heroes
                        </button>

                        <button 
                          onClick={() => setProjectEditorTab("seo")}
                          className={`px-3 py-2.5 rounded-xl font-mono text-[11px] tracking-wider text-left shrink-0 transition-all cursor-pointer flex items-center gap-2.5 ${
                            projectEditorTab === "seo" ? "bg-slate-900 text-white font-bold" : "text-slate-400 hover:text-white hover:bg-slate-900/30"
                          }`}
                        >
                          <Globe size={12} className="text-emerald-400" /> SEO Configuration
                        </button>

                        <button 
                          onClick={() => setProjectEditorTab("legacy-fields")}
                          className={`px-3 py-2.5 rounded-xl font-mono text-[11px] tracking-wider text-left shrink-0 transition-all cursor-pointer flex items-center gap-2.5 ${
                            projectEditorTab === "legacy-fields" ? "bg-slate-900 text-white font-bold" : "text-slate-400 hover:text-white hover:bg-slate-900/30"
                          }`}
                        >
                          <FolderKanban size={12} className="text-slate-400" /> Original Narrative
                        </button>
                      </div>

                      {/* Right Settings Configuration Details Panels */}
                      <div className="lg:col-span-9 bg-slate-950 border border-slate-850/80 p-6 rounded-2xl space-y-6">
                        
                        {/* TAB 1: GENERAL INFO */}
                        {projectEditorTab === "general" && (
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-1">
                              <label className="text-[10px] font-mono uppercase tracking-widest text-slate-500 font-bold block">PROJECT CASE TITLE</label>
                              <input 
                                type="text" 
                                value={editingProject.title}
                                onChange={(e) => handleProjectUpdate({ ...editingProject, title: e.target.value })}
                                className="w-full px-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white focus:outline-hidden focus:border-blue-500 font-mono" 
                              />
                            </div>

                            <div className="space-y-1">
                              <label className="text-[10px] font-mono uppercase tracking-widest text-slate-500 font-bold block">SUBTITLE / BRIEF CAPTION</label>
                              <input 
                                type="text" 
                                value={editingProject.subtitle}
                                onChange={(e) => handleProjectUpdate({ ...editingProject, subtitle: e.target.value })}
                                className="w-full px-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white focus:outline-hidden focus:border-blue-500 font-mono" 
                              />
                            </div>

                            <div className="space-y-1">
                              <label className="text-[10px] font-mono uppercase tracking-widest text-slate-500 font-bold block">INDUSTRY CATEGORY</label>
                              <input 
                                type="text" 
                                value={editingProject.category}
                                onChange={(e) => handleProjectUpdate({ ...editingProject, category: e.target.value })}
                                className="w-full px-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white focus:outline-hidden focus:border-blue-500 font-mono" 
                              />
                            </div>

                            <div className="space-y-1">
                              <label className="text-[10px] font-mono uppercase tracking-widest text-slate-500 font-bold block">FISCAL YEAR</label>
                              <input 
                                type="text" 
                                value={editingProject.year}
                                onChange={(e) => handleProjectUpdate({ ...editingProject, year: e.target.value })}
                                className="w-full px-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white focus:outline-hidden focus:border-blue-500 font-mono" 
                              />
                            </div>

                            <div className="space-y-1">
                              <label className="text-[10px] font-mono uppercase tracking-widest text-slate-500 font-bold block">PAWAN'S DESIGN ROLE</label>
                              <input 
                                type="text" 
                                value={editingProject.role}
                                onChange={(e) => handleProjectUpdate({ ...editingProject, role: e.target.value })}
                                className="w-full px-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white focus:outline-hidden focus:border-blue-500 font-mono" 
                              />
                            </div>

                            <div className="space-y-1">
                              <label className="text-[10px] font-mono uppercase tracking-widest text-slate-500 font-bold block">PROJECT DURATION</label>
                              <input 
                                type="text" 
                                value={editingProject.duration}
                                onChange={(e) => handleProjectUpdate({ ...editingProject, duration: e.target.value })}
                                className="w-full px-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white focus:outline-hidden focus:border-blue-500 font-mono" 
                              />
                            </div>

                            <div className="space-y-1">
                              <label className="text-[10px] font-mono uppercase tracking-widest text-slate-500 font-bold block">CLIENT ORGANIZATION</label>
                              <input 
                                type="text" 
                                value={editingProject.client}
                                onChange={(e) => handleProjectUpdate({ ...editingProject, client: e.target.value })}
                                className="w-full px-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white focus:outline-hidden focus:border-blue-500 font-mono" 
                              />
                            </div>

                            <div className="space-y-1">
                              <label className="text-[10px] font-mono uppercase tracking-widest text-slate-500 font-bold block">TEAM COMPOSITION</label>
                              <input 
                                type="text" 
                                value={editingProject.team}
                                onChange={(e) => handleProjectUpdate({ ...editingProject, team: e.target.value })}
                                className="w-full px-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white focus:outline-hidden focus:border-blue-500 font-mono" 
                              />
                            </div>

                            <div className="space-y-1">
                              <label className="text-[10px] font-mono uppercase tracking-widest text-slate-500 font-bold block">PUBLISHING STATUS</label>
                              <select 
                                value={editingProject.status}
                                onChange={(e) => handleProjectUpdate({ ...editingProject, status: e.target.value as any })}
                                className="w-full px-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white focus:outline-hidden focus:border-blue-500 font-mono"
                              >
                                <option value="draft">Draft - Private Case Study</option>
                                <option value="published">Published - Live Portfolio</option>
                              </select>
                            </div>

                            <div className="flex items-center gap-3 p-4 bg-slate-900 border border-slate-800 rounded-xl self-end">
                              <input 
                                type="checkbox" 
                                id="featured-toggle"
                                checked={editingProject.featured}
                                onChange={(e) => handleProjectUpdate({ ...editingProject, featured: e.target.checked })}
                                className="w-4 h-4 accent-sky-400" 
                              />
                              <label htmlFor="featured-toggle" className="text-xs font-mono text-slate-300 font-bold cursor-pointer">FEATURED HERO PROJECT</label>
                            </div>
                          </div>
                        )}

                        {/* TAB 2: MODULAR PAGE BUILDER */}
                        {projectEditorTab === "page-builder" && (
                          <div className="space-y-6">
                            <div className="flex justify-between items-center bg-slate-900 border border-slate-800 p-4 rounded-xl">
                              <div className="space-y-0.5">
                                <h3 className="text-xs font-mono font-bold text-white uppercase tracking-wider">MODULAR PAGE SECTIONS</h3>
                                <p className="text-[10px] text-slate-500 font-mono">ADD REUSABLE DRAG/DROP ORDER-ABLE DESIGN BLOCKS</p>
                              </div>
                              
                              {/* Quick blocks addition selection dropdown */}
                              <select 
                                onChange={(e) => {
                                  if (e.target.value) {
                                    handleAddSectionBlock(e.target.value);
                                    e.target.value = "";
                                  }
                                }}
                                className="px-4 py-2.5 bg-sky-500 text-slate-950 font-mono text-[10px] tracking-wider font-bold rounded-xl focus:outline-hidden cursor-pointer"
                              >
                                <option value="">+ ADD DYNAMIC BLOCK...</option>
                                <option value="hero-banner">Hero Banner Showcase</option>
                                <option value="rich-text">Rich Text / HTML Block</option>
                                <option value="image">Single Focus Image</option>
                                <option value="image-gallery">Image Multi-Gallery Grid</option>
                                <option value="before-after-slider">Interactive Before/After Slider</option>
                                <option value="video">Standard Video Player</option>
                                <option value="embedded-video">Embedded Video IFrame</option>
                                <option value="pdf-viewer">Embedded Blueprint PDF Reader</option>
                                <option value="quote">Project Quote Highlight</option>
                                <option value="research-block">Research Block Hypothesis</option>
                                <option value="problem-statement">Challenge / Problem Statement</option>
                                <option value="user-persona">User Persona Card</option>
                                <option value="journey-map">User Journey Matrix Map</option>
                                <option value="affinity-diagram">Affinity Diagram Categorizer</option>
                                <option value="design-process-timeline">Design Process Timeline Line</option>
                                <option value="testing-results">Verification Metrics Benchmarks</option>
                                <option value="comparison-table">Structured Comparison Table</option>
                                <option value="specifications-table">CMF Technical Spec List</option>
                                <option value="reflection">Refrospective / Retrospective learnings</option>
                                <option value="downloads">Additional CAD Files / Blueprints</option>
                                <option value="call-to-action">Call To Action block</option>
                                <option value="two-column">Double Column Layout</option>
                                <option value="three-column">Triple Column Layout</option>
                                <option value="full-width-image">Edge-to-Edge Full Image</option>
                                <option value="image-text">Image + Narrative Row</option>
                                <option value="video-text">Video + Narrative Row</option>
                                <option value="accordion">Interactive Accordion Panel</option>
                                <option value="tabs">Interactive Tab Panels</option>
                                <option value="carousel">Interactive Image Carousel Slider</option>
                                <option value="interactive-timeline">Interactive Year Timeline Map</option>
                              </select>
                            </div>

                            {/* List of current added sections block */}
                            <div className="space-y-4">
                              {(!editingProject.sections || editingProject.sections.length === 0) ? (
                                <div className="border border-dashed border-slate-800 p-12 text-center rounded-xl">
                                  <Sliders size={24} className="text-slate-600 mx-auto mb-3" />
                                  <p className="text-xs text-slate-400 font-mono">No modular sections added yet.</p>
                                  <p className="text-[10px] text-slate-600 font-mono mt-1">This project is currently falling back to its original static chapters.</p>
                                </div>
                              ) : (
                                editingProject.sections.map((section, idx) => (
                                  <div key={section.id} className="border border-slate-850 bg-slate-900/20 p-5 rounded-2xl space-y-4 relative">
                                    {/* Section Block header */}
                                    <div className="flex justify-between items-center border-b border-slate-850 pb-3">
                                      <div className="flex items-center gap-2">
                                        <span className="w-5 h-5 rounded-full bg-slate-900 border border-slate-800 text-[10px] font-mono text-sky-400 flex items-center justify-center font-bold">
                                          {idx + 1}
                                        </span>
                                        <span className="text-xs font-mono font-bold text-white uppercase tracking-wider">{section.type.replace("-", " ")}</span>
                                      </div>

                                      <div className="flex items-center gap-1.5">
                                        <button 
                                          onClick={() => handleMoveSectionBlock(idx, "up")} 
                                          disabled={idx === 0}
                                          className="p-1 hover:bg-slate-800 border border-slate-800 rounded disabled:opacity-20 text-slate-400 hover:text-white transition-all cursor-pointer"
                                        >
                                          <ArrowUp size={12} />
                                        </button>
                                        <button 
                                          onClick={() => handleMoveSectionBlock(idx, "down")} 
                                          disabled={idx === editingProject.sections.length - 1}
                                          className="p-1 hover:bg-slate-800 border border-slate-800 rounded disabled:opacity-20 text-slate-400 hover:text-white transition-all cursor-pointer"
                                        >
                                          <ArrowDown size={12} />
                                        </button>
                                        <button 
                                          onClick={() => handleDuplicateSectionBlock(section)} 
                                          className="p-1 hover:bg-slate-800 border border-slate-800 rounded text-slate-400 hover:text-white transition-all cursor-pointer"
                                          title="Duplicate block"
                                        >
                                          <Copy size={12} />
                                        </button>
                                        <button 
                                          onClick={() => handleRemoveSectionBlock(section.id)} 
                                          className="p-1 hover:bg-red-950/20 hover:text-red-400 border border-slate-800 rounded text-slate-400 transition-all cursor-pointer"
                                          title="Delete block"
                                        >
                                          <Trash2 size={12} />
                                        </button>
                                      </div>
                                    </div>

                                    {/* Render Block-specific form config inputs */}
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs font-mono">
                                      {/* RENDER LOGIC FOR BLOCK SPECIFIC CONFIG */}
                                      {section.type === "hero-banner" && (
                                        <>
                                          <div className="space-y-1">
                                            <label className="text-[10px] text-slate-500 font-bold">BANNER MAIN TITLE</label>
                                            <input 
                                              type="text" 
                                              value={section.content.title || ""} 
                                              onChange={(e) => {
                                                const updated = editingProject.sections.map(s => s.id === section.id ? { ...s, content: { ...s.content, title: e.target.value } } : s);
                                                handleProjectUpdate({ ...editingProject, sections: updated });
                                              }}
                                              className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white font-mono text-[11px]" 
                                            />
                                          </div>
                                          <div className="space-y-1">
                                            <label className="text-[10px] text-slate-500 font-bold">BANNER SUBTITLE</label>
                                            <input 
                                              type="text" 
                                              value={section.content.subtitle || ""} 
                                              onChange={(e) => {
                                                const updated = editingProject.sections.map(s => s.id === section.id ? { ...s, content: { ...s.content, subtitle: e.target.value } } : s);
                                                handleProjectUpdate({ ...editingProject, sections: updated });
                                              }}
                                              className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white font-mono text-[11px]" 
                                            />
                                          </div>
                                          <div className="space-y-1 md:col-span-2">
                                            <label className="text-[10px] text-slate-500 font-bold block">BANNER BACKGROUND IMAGE</label>
                                            <div className="flex gap-2">
                                              <input 
                                                type="text" 
                                                value={section.content.backgroundImage || ""} 
                                                onChange={(e) => {
                                                  const updated = editingProject.sections.map(s => s.id === section.id ? { ...s, content: { ...s.content, backgroundImage: e.target.value } } : s);
                                                  handleProjectUpdate({ ...editingProject, sections: updated });
                                                }}
                                                className="flex-1 px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white font-mono text-[11px]" 
                                              />
                                              <button 
                                                onClick={() => openMediaLibraryForField("backgroundImage", section.id)}
                                                className="px-3 bg-slate-800 border border-slate-700 rounded-lg text-slate-300 hover:text-white hover:bg-slate-750 transition-all cursor-pointer"
                                              >
                                                SELECT
                                              </button>
                                            </div>
                                          </div>
                                        </>
                                      )}

                                      {section.type === "rich-text" && (
                                        <div className="md:col-span-2 space-y-2">
                                          <label className="text-[10px] text-slate-500 font-bold block">VISUAL HTML RICH TEXT EDITOR</label>
                                          
                                          {/* Visual rich text shortcuts */}
                                          <div className="flex flex-wrap gap-1 bg-slate-900 border border-slate-800 p-1.5 rounded-t-lg">
                                            <button type="button" onClick={() => { setRichTextTarget({ blockId: section.id, currentHtml: section.content.html || "" }); applyVisualFormatting("bold"); }} className="p-1.5 hover:bg-slate-800 text-slate-300 rounded font-bold"><Bold size={13} /></button>
                                            <button type="button" onClick={() => { setRichTextTarget({ blockId: section.id, currentHtml: section.content.html || "" }); applyVisualFormatting("italic"); }} className="p-1.5 hover:bg-slate-800 text-slate-300 rounded"><Italic size={13} /></button>
                                            <button type="button" onClick={() => { setRichTextTarget({ blockId: section.id, currentHtml: section.content.html || "" }); applyVisualFormatting("h1"); }} className="p-1.5 hover:bg-slate-800 text-slate-300 rounded"><Heading1 size={13} /></button>
                                            <button type="button" onClick={() => { setRichTextTarget({ blockId: section.id, currentHtml: section.content.html || "" }); applyVisualFormatting("h2"); }} className="p-1.5 hover:bg-slate-800 text-slate-300 rounded"><Heading2 size={13} /></button>
                                            <button type="button" onClick={() => { setRichTextTarget({ blockId: section.id, currentHtml: section.content.html || "" }); applyVisualFormatting("bullet"); }} className="p-1.5 hover:bg-slate-800 text-slate-300 rounded"><List size={13} /></button>
                                            <button type="button" onClick={() => { setRichTextTarget({ blockId: section.id, currentHtml: section.content.html || "" }); applyVisualFormatting("quote"); }} className="p-1.5 hover:bg-slate-800 text-slate-300 rounded"><Quote size={13} /></button>
                                            <button type="button" onClick={() => { setRichTextTarget({ blockId: section.id, currentHtml: section.content.html || "" }); applyVisualFormatting("table"); }} className="p-1.5 hover:bg-slate-800 text-slate-300 rounded"><Table size={13} /></button>
                                          </div>

                                          <textarea 
                                            value={richTextTarget?.blockId === section.id ? richTextTarget.currentHtml : (section.content.html || "")}
                                            onFocus={() => setRichTextTarget({ blockId: section.id, currentHtml: section.content.html || "" })}
                                            onChange={(e) => {
                                              setRichTextTarget({ blockId: section.id, currentHtml: e.target.value });
                                              const updated = editingProject.sections.map(s => s.id === section.id ? { ...s, content: { ...s.content, html: e.target.value } } : s);
                                              handleProjectUpdate({ ...editingProject, sections: updated });
                                            }}
                                            rows={6}
                                            className="w-full px-3 py-2 bg-slate-900 border-x border-b border-slate-800 rounded-b-lg text-slate-300 font-mono text-[11px] leading-relaxed" 
                                          />
                                        </div>
                                      )}

                                      {section.type === "image" && (
                                        <>
                                          <div className="space-y-1 md:col-span-2">
                                            <label className="text-[10px] text-slate-500 font-bold block">IMAGE URL SOURCE</label>
                                            <div className="flex gap-2">
                                              <input 
                                                type="text" 
                                                value={section.content.url || ""} 
                                                onChange={(e) => {
                                                  const updated = editingProject.sections.map(s => s.id === section.id ? { ...s, content: { ...s.content, url: e.target.value } } : s);
                                                  handleProjectUpdate({ ...editingProject, sections: updated });
                                                }}
                                                className="flex-1 px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white font-mono text-[11px]" 
                                              />
                                              <button 
                                                onClick={() => openMediaLibraryForField("url", section.id)}
                                                className="px-3 bg-slate-800 border border-slate-700 rounded-lg text-slate-300 hover:text-white hover:bg-slate-750 transition-all cursor-pointer"
                                              >
                                                SELECT
                                              </button>
                                            </div>
                                          </div>
                                          <div className="space-y-1">
                                            <label className="text-[10px] text-slate-500 font-bold">ALT DESCRIPTION</label>
                                            <input 
                                              type="text" 
                                              value={section.content.alt || ""} 
                                              onChange={(e) => {
                                                const updated = editingProject.sections.map(s => s.id === section.id ? { ...s, content: { ...s.content, alt: e.target.value } } : s);
                                                handleProjectUpdate({ ...editingProject, sections: updated });
                                              }}
                                              className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white font-mono text-[11px]" 
                                            />
                                          </div>
                                          <div className="space-y-1">
                                            <label className="text-[10px] text-slate-500 font-bold">PHOTOGRAPHER CREDIT</label>
                                            <input 
                                              type="text" 
                                              value={section.content.photographerCredit || ""} 
                                              onChange={(e) => {
                                                const updated = editingProject.sections.map(s => s.id === section.id ? { ...s, content: { ...s.content, photographerCredit: e.target.value } } : s);
                                                handleProjectUpdate({ ...editingProject, sections: updated });
                                              }}
                                              className="w-full px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white font-mono text-[11px]" 
                                            />
                                          </div>
                                        </>
                                      )}

                                      {section.type === "before-after-slider" && (
                                        <>
                                          <div className="space-y-1">
                                            <label className="text-[10px] text-slate-500 font-bold block">BEFORE IMAGE (SKETCH / LEFT)</label>
                                            <div className="flex gap-2">
                                              <input 
                                                type="text" 
                                                value={section.content.beforeImage || ""} 
                                                onChange={(e) => {
                                                  const updated = editingProject.sections.map(s => s.id === section.id ? { ...s, content: { ...s.content, beforeImage: e.target.value } } : s);
                                                  handleProjectUpdate({ ...editingProject, sections: updated });
                                                }}
                                                className="flex-1 px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white font-mono text-[11px]" 
                                              />
                                              <button onClick={() => openMediaLibraryForField("beforeImage", section.id)} className="px-2.5 bg-slate-800 border border-slate-700 rounded-lg text-slate-300">SELECT</button>
                                            </div>
                                          </div>
                                          <div className="space-y-1">
                                            <label className="text-[10px] text-slate-500 font-bold block">AFTER IMAGE (PHYSICAL / RIGHT)</label>
                                            <div className="flex gap-2">
                                              <input 
                                                type="text" 
                                                value={section.content.afterImage || ""} 
                                                onChange={(e) => {
                                                  const updated = editingProject.sections.map(s => s.id === section.id ? { ...s, content: { ...s.content, afterImage: e.target.value } } : s);
                                                  handleProjectUpdate({ ...editingProject, sections: updated });
                                                }}
                                                className="flex-1 px-3 py-2 bg-slate-900 border border-slate-800 rounded-lg text-white font-mono text-[11px]" 
                                              />
                                              <button onClick={() => openMediaLibraryForField("afterImage", section.id)} className="px-2.5 bg-slate-800 border border-slate-700 rounded-lg text-slate-300">SELECT</button>
                                            </div>
                                          </div>
                                        </>
                                      )}

                                      {/* Accordion / Tabs Items */}
                                      {(section.type === "accordion" || section.type === "tabs") && (
                                        <div className="md:col-span-2 space-y-3">
                                          <label className="text-[10px] text-slate-500 font-bold block">INTERACTIVE PANELS LIST</label>
                                          {section.content.items?.map((item: any, i: number) => (
                                            <div key={i} className="flex gap-2 items-start bg-slate-950 p-3 rounded-lg border border-slate-800">
                                              <div className="flex-1 space-y-2">
                                                <input 
                                                  type="text" 
                                                  value={item.title || ""} 
                                                  placeholder="Panel Heading Title"
                                                  onChange={(e) => {
                                                    const updatedItems = [...section.content.items];
                                                    updatedItems[i] = { ...updatedItems[i], title: e.target.value };
                                                    const updated = editingProject.sections.map(s => s.id === section.id ? { ...s, content: { ...s.content, items: updatedItems } } : s);
                                                    handleProjectUpdate({ ...editingProject, sections: updated });
                                                  }}
                                                  className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-800 rounded text-white" 
                                                />
                                                <textarea 
                                                  value={item.content || ""} 
                                                  placeholder="Detailed contextual text summary..."
                                                  onChange={(e) => {
                                                    const updatedItems = [...section.content.items];
                                                    updatedItems[i] = { ...updatedItems[i], content: e.target.value };
                                                    const updated = editingProject.sections.map(s => s.id === section.id ? { ...s, content: { ...s.content, items: updatedItems } } : s);
                                                    handleProjectUpdate({ ...editingProject, sections: updated });
                                                  }}
                                                  rows={2}
                                                  className="w-full px-2.5 py-1.5 bg-slate-900 border border-slate-800 rounded text-slate-300" 
                                                />
                                              </div>
                                              <button 
                                                onClick={() => {
                                                  const filtered = section.content.items.filter((_: any, idx: number) => idx !== i);
                                                  const updated = editingProject.sections.map(s => s.id === section.id ? { ...s, content: { ...s.content, items: filtered } } : s);
                                                  handleProjectUpdate({ ...editingProject, sections: updated });
                                                }}
                                                className="p-1 text-red-400 hover:bg-slate-800 rounded"
                                              >
                                                <Trash2 size={12} />
                                              </button>
                                            </div>
                                          ))}

                                          <button 
                                            onClick={() => {
                                              const updatedItems = section.content.items ? [...section.content.items, { title: "New Item", content: "Description..." }] : [{ title: "New Item", content: "Description..." }];
                                              const updated = editingProject.sections.map(s => s.id === section.id ? { ...s, content: { ...s.content, items: updatedItems } } : s);
                                              handleProjectUpdate({ ...editingProject, sections: updated });
                                            }}
                                            className="px-3 py-1.5 bg-slate-900 border border-slate-800 text-[10px] rounded text-slate-300 hover:text-white"
                                          >
                                            + ADD NEW INTERACTIVE ROW
                                          </button>
                                        </div>
                                      )}

                                      {/* Default Catchall Info parameter */}
                                      {["rich-text", "hero-banner", "image", "before-after-slider", "accordion", "tabs"].indexOf(section.type) === -1 && (
                                        <div className="md:col-span-2 p-3 bg-slate-950 rounded-xl border border-slate-850">
                                          <p className="text-[10px] text-slate-500 uppercase font-bold">Standard JSON Properties</p>
                                          <p className="text-[10px] text-slate-400 mt-0.5 leading-relaxed">Modify block parameters using Case Study Preview or legacy controls in tabs.</p>
                                        </div>
                                      )}
                                    </div>
                                  </div>
                                ))
                              )}
                            </div>
                          </div>
                        )}

                        {/* TAB 3: MEDIA & HEROES */}
                        {projectEditorTab === "media" && (
                          <div className="space-y-4">
                            <h3 className="text-xs font-mono font-bold text-white uppercase">PRIMARY MEDIA ASSETS</h3>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              <div className="space-y-1 md:col-span-2">
                                <label className="text-[10px] font-mono uppercase tracking-widest text-slate-500 font-bold block">HERO LANDSCAPE IMAGE (1600x900)</label>
                                <div className="flex gap-2">
                                  <input 
                                    type="text" 
                                    value={editingProject.heroImage}
                                    onChange={(e) => handleProjectUpdate({ ...editingProject, heroImage: e.target.value })}
                                    className="flex-1 px-4 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white" 
                                  />
                                  <button onClick={() => openMediaLibraryForField("heroImage")} className="px-3 bg-slate-850 border border-slate-800 rounded-xl text-slate-300">SELECT</button>
                                </div>
                              </div>

                              <div className="space-y-1 md:col-span-2">
                                <label className="text-[10px] font-mono uppercase tracking-widest text-slate-500 font-bold block">PORTFOLIO DETAIL HERO VIDEO SOURCE (.MP4 / EMBED)</label>
                                <div className="flex gap-2">
                                  <input 
                                    type="text" 
                                    value={editingProject.heroVideo || ""}
                                    placeholder="e.g. /uploads/video.mp4"
                                    onChange={(e) => handleProjectUpdate({ ...editingProject, heroVideo: e.target.value })}
                                    className="flex-1 px-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-white font-mono" 
                                  />
                                  <button onClick={() => openMediaLibraryForField("heroVideo")} className="px-3 bg-slate-850 border border-slate-800 rounded-xl text-slate-300 font-mono text-[10px]">CHOOSE</button>
                                </div>
                              </div>
                            </div>
                          </div>
                        )}

                        {/* TAB 4: SEO */}
                        {projectEditorTab === "seo" && (
                          <div className="space-y-4">
                            <h3 className="text-xs font-mono font-bold text-white uppercase">META SEO PARAMETERS</h3>
                            <div className="grid grid-cols-1 gap-4 text-xs font-mono">
                              <div className="space-y-1">
                                <label className="text-[10px] text-slate-500 font-bold block">META TITLE TAG</label>
                                <input 
                                  type="text" 
                                  value={editingProject.seoTitle || ""} 
                                  onChange={(e) => handleProjectUpdate({ ...editingProject, seoTitle: e.target.value })}
                                  className="w-full px-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-white font-mono" 
                                />
                              </div>

                              <div className="space-y-1">
                                <label className="text-[10px] text-slate-500 font-bold block">META DESCRIPTION STRING</label>
                                <textarea 
                                  value={editingProject.seoDescription || ""} 
                                  onChange={(e) => handleProjectUpdate({ ...editingProject, seoDescription: e.target.value })}
                                  rows={3}
                                  className="w-full px-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-slate-300 font-mono leading-relaxed" 
                                />
                              </div>

                              <div className="space-y-1">
                                <label className="text-[10px] text-slate-500 font-bold block">KEYWORDS SEPARATED BY COMMA</label>
                                <input 
                                  type="text" 
                                  value={editingProject.seoKeywords || ""} 
                                  onChange={(e) => handleProjectUpdate({ ...editingProject, seoKeywords: e.target.value })}
                                  className="w-full px-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-white font-mono" 
                                />
                              </div>
                            </div>
                          </div>
                        )}

                        {/* TAB 5: LEGACY ORIGINAL NARRATIVE FALLBACK */}
                        {projectEditorTab === "legacy-fields" && (
                          <div className="space-y-4">
                            <div className="p-3 bg-amber-950/25 border border-amber-500/20 text-amber-300 text-[10px] rounded-xl font-mono leading-relaxed flex gap-2.5 items-start">
                              <Info size={14} className="shrink-0 mt-0.5" />
                              <span>THESE FIELDS MAINTAIN PERFECT BACKWARD COMPATIBILITY IF NO MODULAR BLOCKS ARE ADDED TO THE PAGE BUILDER.</span>
                            </div>

                            <div className="grid grid-cols-1 gap-4">
                              <div className="space-y-1">
                                <label className="text-[10px] font-mono uppercase text-slate-500 font-bold block">OVERVIEW NARRATIVE</label>
                                <textarea 
                                  value={editingProject.overview}
                                  onChange={(e) => handleProjectUpdate({ ...editingProject, overview: e.target.value })}
                                  rows={3}
                                  className="w-full px-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-300 font-mono leading-relaxed" 
                                />
                              </div>

                              <div className="space-y-1">
                                <label className="text-[10px] font-mono uppercase text-slate-500 font-bold block">PROBLEM STATEMENT</label>
                                <textarea 
                                  value={editingProject.problem}
                                  onChange={(e) => handleProjectUpdate({ ...editingProject, problem: e.target.value })}
                                  rows={2}
                                  className="w-full px-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-300 font-mono leading-relaxed" 
                                />
                              </div>

                              <div className="space-y-1">
                                <label className="text-[10px] font-mono uppercase text-slate-500 font-bold block">RESEARCH STUDY DESCRIPTION</label>
                                <textarea 
                                  value={editingProject.research}
                                  onChange={(e) => handleProjectUpdate({ ...editingProject, research: e.target.value })}
                                  rows={2}
                                  className="w-full px-4 py-2.5 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-300 font-mono leading-relaxed" 
                                />
                              </div>
                            </div>
                          </div>
                        )}

                      </div>
                    </div>
                  )}
                </div>
              ) : (
                /* MAIN RAILS CATEGORIES */
                <div>
                  {/* TAB 1: DASHBOARD METRICS */}
                  {activeTab === "dashboard" && (
                    <div className="space-y-6">
                      <div className="space-y-1">
                        <span className="text-[10px] font-mono text-blue-400 uppercase tracking-widest font-bold">PORTFOLIO CONTROL DECK</span>
                        <h2 className="text-3xl font-black text-white leading-none">CMS OVERVIEW DASHBOARD</h2>
                      </div>

                      {/* STATS BENTO MATRIX GRID */}
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl relative overflow-hidden">
                          <FolderKanban className="absolute right-4 bottom-4 text-slate-800/60" size={40} />
                          <span className="text-[9px] font-mono text-slate-500 uppercase tracking-wider block font-bold">TOTAL PROJECTS</span>
                          <span className="text-3xl font-mono font-black text-white block mt-2">{cmsData.projects.length}</span>
                          <span className="text-[9px] font-mono text-slate-400 mt-1 block">In database</span>
                        </div>

                        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl relative overflow-hidden">
                          <Layout className="absolute right-4 bottom-4 text-slate-800/60" size={40} />
                          <span className="text-[9px] font-mono text-slate-500 uppercase tracking-wider block font-bold">PUBLISHED STATUS</span>
                          <span className="text-3xl font-mono font-black text-emerald-400 block mt-2">
                            {cmsData.projects.filter(p => p.status === "published").length}
                          </span>
                          <span className="text-[9px] font-mono text-slate-400 mt-1 block">Live showcase</span>
                        </div>

                        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl relative overflow-hidden">
                          <Sliders className="absolute right-4 bottom-4 text-slate-800/60" size={40} />
                          <span className="text-[9px] font-mono text-slate-500 uppercase tracking-wider block font-bold">DRAFT ENVELOPS</span>
                          <span className="text-3xl font-mono font-black text-sky-400 block mt-2">
                            {cmsData.projects.filter(p => p.status !== "published").length}
                          </span>
                          <span className="text-[9px] font-mono text-slate-400 mt-1 block">Private editing</span>
                        </div>

                        <div className="bg-slate-900 border border-slate-800 p-5 rounded-2xl relative overflow-hidden">
                          <Image className="absolute right-4 bottom-4 text-slate-800/60" size={40} />
                          <span className="text-[9px] font-mono text-slate-500 uppercase tracking-wider block font-bold">MEDIA ASSETS</span>
                          <span className="text-3xl font-mono font-black text-yellow-400 block mt-2">{mediaAssets.length}</span>
                          <span className="text-[9px] font-mono text-slate-400 mt-1 block">Uploaded files</span>
                        </div>
                      </div>

                      {/* BOTTOM SPLIT PANEL */}
                      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
                        {/* Traffic simulated and logs */}
                        <div className="lg:col-span-7 bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
                          <div className="flex justify-between items-center border-b border-slate-850 pb-3">
                            <h3 className="text-xs font-mono font-bold text-white uppercase tracking-wider">WEBSITE ANALYTICS LOGS</h3>
                            <span className="text-[9px] font-mono text-emerald-400 bg-emerald-950 px-2 py-0.5 rounded border border-emerald-500/10">ACTIVE ONLINE</span>
                          </div>

                          <div className="grid grid-cols-3 gap-2 text-center font-mono py-2">
                            <div className="bg-slate-950/50 p-3 rounded-xl border border-slate-850">
                              <span className="text-[9px] text-slate-500">MONTHLY VISITS</span>
                              <span className="text-lg font-black text-white block mt-1">1,420</span>
                            </div>
                            <div className="bg-slate-950/50 p-3 rounded-xl border border-slate-850">
                              <span className="text-[9px] text-slate-500">AVG SESSION</span>
                              <span className="text-lg font-black text-white block mt-1">3m 42s</span>
                            </div>
                            <div className="bg-slate-950/50 p-3 rounded-xl border border-slate-850">
                              <span className="text-[9px] text-slate-500">BOUNCE RATE</span>
                              <span className="text-lg font-black text-white block mt-1">28.4%</span>
                            </div>
                          </div>

                          <div className="space-y-2 pt-2">
                            <span className="text-[9px] font-mono text-slate-500 uppercase font-bold">TOP VISITED DESIGN CHANNELS</span>
                            <div className="space-y-1.5 font-mono text-xs">
                              <div className="flex justify-between p-2 bg-slate-950/30 rounded border border-slate-850/40">
                                <span className="text-slate-300">/ (Landing Home circle)</span>
                                <span className="text-sky-400">842 clicks</span>
                              </div>
                              <div className="flex justify-between p-2 bg-slate-950/30 rounded border border-slate-850/40">
                                <span className="text-slate-300">/project/kinetic-light-casing</span>
                                <span className="text-sky-400">312 visits</span>
                              </div>
                            </div>
                          </div>
                        </div>

                        {/* Recent Uploads Log */}
                        <div className="lg:col-span-5 bg-slate-900 border border-slate-800 p-6 rounded-2xl space-y-4">
                          <h3 className="text-xs font-mono font-bold text-white uppercase tracking-wider border-b border-slate-850 pb-3">RECENT UPLOADS</h3>
                          <div className="space-y-3 max-h-[220px] overflow-y-auto scrollbar-thin">
                            {mediaAssets.slice(0, 4).map((asset) => (
                              <div key={asset.id} className="flex gap-3 items-center p-2.5 bg-slate-950 rounded-xl border border-slate-850">
                                <div className="w-10 h-10 rounded-lg overflow-hidden border border-slate-800 bg-slate-900 shrink-0">
                                  {asset.type.startsWith("image/") ? (
                                    <img src={asset.url} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                                  ) : asset.type.startsWith("video/") ? (
                                    <div className="w-full h-full flex items-center justify-center text-xs text-slate-500"><Video size={14} /></div>
                                  ) : (
                                    <div className="w-full h-full flex items-center justify-center text-xs text-slate-500"><FileText size={14} /></div>
                                  )}
                                </div>
                                <div className="min-w-0 flex-1">
                                  <p className="text-xs font-bold text-white truncate">{asset.name}</p>
                                  <p className="text-[9px] font-mono text-slate-500 mt-0.5">{(asset.size / 1024).toFixed(0)} KB</p>
                                </div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* TAB 2: PORTFOLIO PROJECTS */}
                  {activeTab === "projects" && (
                    <div className="space-y-6">
                      <div className="flex justify-between items-center">
                        <div className="space-y-1">
                          <span className="text-[10px] font-mono text-blue-400 uppercase tracking-widest font-bold">CASE STUDY DIRECTORY</span>
                          <h2 className="text-2xl font-black text-white">MANAGE PORTFOLIO ARCHIVES</h2>
                        </div>
                        <button 
                          onClick={handleCreateNewProject}
                          className="px-4 py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-mono text-xs tracking-wider font-bold flex items-center gap-2 transition-all cursor-pointer shadow-lg"
                        >
                          <PlusCircle size={14} /> NEW WORKCASE
                        </button>
                      </div>

                      {/* Project cards grids with reorder buttons */}
                      <div className="space-y-3">
                        {cmsData.projects.map((proj, i) => (
                          <div 
                            key={proj.id}
                            onClick={() => setEditingProject(proj)}
                            className="bg-slate-900 hover:bg-slate-850 border border-slate-800 p-4 rounded-2xl flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between transition-all cursor-pointer group"
                          >
                            <div className="flex gap-4 items-center min-w-0">
                              {/* Left Thumbnail visual */}
                              <div className="w-14 h-14 rounded-xl overflow-hidden border border-slate-800 bg-slate-950 shrink-0">
                                <img src={proj.heroImage} alt="" className="w-full h-full object-cover group-hover:scale-105 transition-transform" referrerPolicy="no-referrer" />
                              </div>
                              <div className="min-w-0">
                                <div className="flex items-center gap-2">
                                  <h3 className="text-sm font-bold text-white group-hover:text-sky-400 transition-colors uppercase truncate">{proj.title}</h3>
                                  {proj.featured && (
                                    <span className="text-[8px] font-mono text-amber-400 bg-amber-950 border border-amber-500/10 px-1.5 py-0.5 rounded-full font-bold">HERO</span>
                                  )}
                                </div>
                                <p className="text-xs text-slate-400 font-mono mt-0.5">{proj.category} | {proj.year}</p>
                                <div className="flex gap-2.5 items-center mt-1 text-[9px] font-mono uppercase font-bold">
                                  <span className={proj.status === "published" ? "text-emerald-400" : "text-sky-400"}>
                                    ● {proj.status}
                                  </span>
                                  <span className="text-slate-500">
                                    • {proj.sections?.length || 0} modular blocks
                                  </span>
                                </div>
                              </div>
                            </div>

                            <div className="flex items-center gap-2 self-stretch sm:self-auto justify-end">
                              {/* Reorder arrows */}
                              <button 
                                onClick={(e) => handleMoveProject(i, "up", e)}
                                disabled={i === 0}
                                className="p-2 hover:bg-slate-800 border border-slate-800 rounded-xl disabled:opacity-20 text-slate-400 hover:text-white transition-all cursor-pointer"
                              >
                                <ArrowUp size={13} />
                              </button>
                              <button 
                                onClick={(e) => handleMoveProject(i, "down", e)}
                                disabled={i === cmsData.projects.length - 1}
                                className="p-2 hover:bg-slate-800 border border-slate-800 rounded-xl disabled:opacity-20 text-slate-400 hover:text-white transition-all cursor-pointer"
                              >
                                <ArrowDown size={13} />
                              </button>

                              <button 
                                onClick={(e) => { e.stopPropagation(); setEditingProject(proj); }}
                                className="px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white font-mono text-[10px] rounded-lg border border-slate-700 transition-all cursor-pointer"
                              >
                                STUDIO EDIT
                              </button>
                              <button 
                                onClick={(e) => handleDeleteProject(proj.id, e)}
                                className="p-2 hover:bg-red-950/20 text-red-400 rounded-xl transition-all cursor-pointer"
                              >
                                <Trash2 size={13} />
                              </button>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* TAB 3: PROFILE & EXPERIENCE */}
                  {activeTab === "profile" && (
                    <div className="space-y-8">
                      <div className="space-y-1">
                        <span className="text-[10px] font-mono text-blue-400 uppercase tracking-widest font-bold">BIOGRAPHY DATABASE</span>
                        <h2 className="text-2xl font-black text-white">UPDATE BIOGRAPHY PROFILE</h2>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-5 bg-slate-900 border border-slate-800 p-6 rounded-2xl">
                        <div className="space-y-1">
                          <label className="text-[10px] font-mono uppercase tracking-widest text-slate-500 font-bold block">NAME TITLE</label>
                          <input 
                            type="text" 
                            value={cmsData.profile.name || ""}
                            onChange={(e) => handleProfileChange("name", e.target.value)}
                            className="w-full px-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white" 
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-mono uppercase tracking-widest text-slate-500 font-bold block">PROFESSIONAL STATUS</label>
                          <input 
                            type="text" 
                            value={cmsData.profile.title || ""}
                            onChange={(e) => handleProfileChange("title", e.target.value)}
                            className="w-full px-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white" 
                          />
                        </div>

                        <div className="space-y-1 md:col-span-2">
                          <label className="text-[10px] font-mono uppercase tracking-widest text-slate-500 font-bold block">HERO TAGLINE / ELEVATOR PITCH</label>
                          <input 
                            type="text" 
                            value={cmsData.profile.tagline || ""}
                            onChange={(e) => handleProfileChange("tagline", e.target.value)}
                            className="w-full px-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white" 
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-mono uppercase tracking-widest text-slate-500 font-bold block">LOCATED CITY</label>
                          <input 
                            type="text" 
                            value={cmsData.profile.location || ""}
                            onChange={(e) => handleProfileChange("location", e.target.value)}
                            className="w-full px-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white" 
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-mono uppercase tracking-widest text-slate-500 font-bold block">EMAIL OFFICE ADDRESS</label>
                          <input 
                            type="email" 
                            value={cmsData.profile.email || ""}
                            onChange={(e) => handleProfileChange("email", e.target.value)}
                            className="w-full px-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white" 
                          />
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-mono uppercase tracking-widest text-slate-500 font-bold block">PORTRAIT IMAGE URL</label>
                          <div className="flex gap-2">
                            <input 
                              type="text" 
                              value={cmsData.profile.portraitUrl || ""}
                              onChange={(e) => handleProfileChange("portraitUrl", e.target.value)}
                              className="flex-1 px-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white" 
                            />
                            <button 
                              type="button"
                              onClick={() => openMediaLibraryForField("portraitUrl", undefined, undefined, true)} 
                              className="px-3 bg-slate-850 border border-slate-800 hover:bg-slate-800 rounded-xl text-slate-300 text-xs font-mono tracking-wider cursor-pointer transition-colors"
                            >
                              SELECT
                            </button>
                          </div>
                        </div>

                        <div className="space-y-1">
                          <label className="text-[10px] font-mono uppercase tracking-widest text-slate-500 font-bold block">RESUME / CV DOCUMENT URL</label>
                          <div className="flex gap-2">
                            <input 
                              type="text" 
                              value={cmsData.profile.resumeUrl || ""}
                              onChange={(e) => handleProfileChange("resumeUrl", e.target.value)}
                              className="flex-1 px-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-white" 
                            />
                            <button 
                              type="button"
                              onClick={() => openMediaLibraryForField("resumeUrl", undefined, undefined, true)} 
                              className="px-3 bg-slate-850 border border-slate-800 hover:bg-slate-800 rounded-xl text-slate-300 text-xs font-mono tracking-wider cursor-pointer transition-colors"
                            >
                              SELECT
                            </button>
                          </div>
                        </div>

                        <div className="space-y-1 md:col-span-2">
                          <label className="text-[10px] font-mono uppercase tracking-widest text-slate-500 font-bold block">PRIMARY BIOGRAPHY INTRO</label>
                          <textarea 
                            value={cmsData.profile.bio || ""}
                            onChange={(e) => handleProfileChange("bio", e.target.value)}
                            rows={3}
                            className="w-full px-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-300 font-mono leading-relaxed" 
                          />
                        </div>
                      </div>

                      {/* WORK EXPERIENCE HISTORY SECTION */}
                      <div className="space-y-4 pt-4 border-t border-slate-900">
                        <div className="flex justify-between items-center">
                          <div className="space-y-1">
                            <span className="text-[10px] font-mono text-sky-400 uppercase tracking-widest font-bold">PROFESSIONAL ROLES</span>
                            <h3 className="text-lg font-bold text-white">WORK EXPERIENCE TIMELINE</h3>
                          </div>
                          <button
                            type="button"
                            onClick={handleAddExperience}
                            className="px-4 py-2 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-sky-400 hover:text-sky-300 rounded-xl text-xs font-mono font-bold tracking-wider flex items-center gap-2 transition-colors cursor-pointer"
                          >
                            <Plus size={14} /> ADD WORK ROLE
                          </button>
                        </div>

                        <div className="space-y-4">
                          {(cmsData.profile.experience || []).length === 0 ? (
                            <div className="bg-slate-900/50 border border-slate-800/80 rounded-2xl p-8 text-center">
                              <Briefcase className="mx-auto text-slate-600 mb-2" size={24} />
                              <p className="text-xs text-slate-400 font-mono">No work experience entries yet.</p>
                              <p className="text-[10px] text-slate-600 font-mono mt-1">Click the button above to add your first work role.</p>
                            </div>
                          ) : (
                            (cmsData.profile.experience || []).map((exp, expIdx) => (
                              <div key={expIdx} className="bg-slate-900 border border-slate-800/80 p-5 rounded-2xl space-y-4 relative group">
                                <div className="absolute top-4 right-4 flex items-center gap-1.5 opacity-60 group-hover:opacity-100 transition-opacity">
                                  <button
                                    type="button"
                                    disabled={expIdx === 0}
                                    onClick={() => handleMoveExperience(expIdx, "up")}
                                    className="p-1 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 disabled:text-slate-700 hover:text-white rounded transition-colors cursor-pointer disabled:cursor-not-allowed"
                                    title="Move Up"
                                  >
                                    <ArrowUp size={12} />
                                  </button>
                                  <button
                                    type="button"
                                    disabled={expIdx === (cmsData.profile.experience || []).length - 1}
                                    onClick={() => handleMoveExperience(expIdx, "down")}
                                    className="p-1 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 disabled:text-slate-700 hover:text-white rounded transition-colors cursor-pointer disabled:cursor-not-allowed"
                                    title="Move Down"
                                  >
                                    <ArrowDown size={12} />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleDeleteExperience(expIdx)}
                                    className="p-1.5 bg-red-950/20 hover:bg-red-950/40 border border-red-900/30 text-red-400 hover:text-red-300 rounded transition-colors cursor-pointer"
                                    title="Delete Experience"
                                  >
                                    <Trash size={12} />
                                  </button>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                  <div className="space-y-1">
                                    <label className="text-[9px] font-mono uppercase tracking-widest text-slate-500 font-bold block">ROLE / TITLE</label>
                                    <input 
                                      type="text"
                                      value={exp.role || ""}
                                      onChange={(e) => handleExperienceChange(expIdx, "role", e.target.value)}
                                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white font-bold"
                                      placeholder="e.g. Lead Product Designer"
                                    />
                                  </div>

                                  <div className="space-y-1">
                                    <label className="text-[9px] font-mono uppercase tracking-widest text-slate-500 font-bold block">COMPANY / ORG</label>
                                    <input 
                                      type="text"
                                      value={exp.company || ""}
                                      onChange={(e) => handleExperienceChange(expIdx, "company", e.target.value)}
                                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white"
                                      placeholder="e.g. Acme Hardware"
                                    />
                                  </div>

                                  <div className="space-y-1">
                                    <label className="text-[9px] font-mono uppercase tracking-widest text-slate-500 font-bold block">PERIOD / TIMELINE</label>
                                    <input 
                                      type="text"
                                      value={exp.period || ""}
                                      onChange={(e) => handleExperienceChange(expIdx, "period", e.target.value)}
                                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white"
                                      placeholder="e.g. 2021 - Present"
                                    />
                                  </div>
                                </div>

                                 <div className="space-y-1">
                                  <label className="text-[9px] font-mono uppercase tracking-widest text-slate-500 font-bold block">ROLE RESPONSIBILITIES & ACHIEVEMENTS</label>
                                  <textarea
                                    value={exp.description || ""}
                                    onChange={(e) => handleExperienceChange(expIdx, "description", e.target.value)}
                                    rows={3}
                                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-300 font-mono leading-relaxed"
                                    placeholder="Describe your core contributions, CAD methodologies, manufacturing hand-offs, or milestones..."
                                  />
                                </div>
                              </div>
                            ))
                          )}
                        </div>
                      </div>

                      {/* ACADEMIC HISTORY SECTION */}
                      <div className="space-y-4 pt-6 border-t border-slate-900">
                        <div className="flex justify-between items-center">
                          <div className="space-y-1">
                            <span className="text-[10px] font-mono text-sky-400 uppercase tracking-widest font-bold">ACADEMIC TIMELINE</span>
                            <h3 className="text-lg font-bold text-white">EDUCATION & DEGREES</h3>
                          </div>
                          <button
                            type="button"
                            onClick={handleAddEducation}
                            className="px-4 py-2 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-sky-400 hover:text-sky-300 rounded-xl text-xs font-mono font-bold tracking-wider flex items-center gap-2 transition-colors cursor-pointer"
                          >
                            <Plus size={14} /> ADD ACADEMIC ITEM
                          </button>
                        </div>

                        <div className="space-y-4">
                          {(cmsData.profile.education || []).length === 0 ? (
                            <div className="bg-slate-900/50 border border-slate-800/80 rounded-2xl p-8 text-center">
                              <GraduationCap className="mx-auto text-slate-600 mb-2" size={24} />
                              <p className="text-xs text-slate-400 font-mono">No educational items defined yet.</p>
                            </div>
                          ) : (
                            (cmsData.profile.education || []).map((edu, eduIdx) => (
                              <div key={eduIdx} className="bg-slate-900 border border-slate-800/80 p-5 rounded-2xl space-y-4 relative group">
                                <div className="absolute top-4 right-4 flex items-center gap-1.5 opacity-60 group-hover:opacity-100 transition-opacity">
                                  <button
                                    type="button"
                                    disabled={eduIdx === 0}
                                    onClick={() => handleMoveEducation(eduIdx, "up")}
                                    className="p-1 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 disabled:text-slate-700 hover:text-white rounded transition-colors cursor-pointer disabled:cursor-not-allowed"
                                    title="Move Up"
                                  >
                                    <ArrowUp size={12} />
                                  </button>
                                  <button
                                    type="button"
                                    disabled={eduIdx === (cmsData.profile.education || []).length - 1}
                                    onClick={() => handleMoveEducation(eduIdx, "down")}
                                    className="p-1 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 disabled:text-slate-700 hover:text-white rounded transition-colors cursor-pointer disabled:cursor-not-allowed"
                                    title="Move Down"
                                  >
                                    <ArrowDown size={12} />
                                  </button>
                                  <button
                                    type="button"
                                    onClick={() => handleDeleteEducation(eduIdx)}
                                    className="p-1.5 bg-red-950/20 hover:bg-red-950/40 border border-red-900/30 text-red-400 hover:text-red-300 rounded transition-colors cursor-pointer"
                                    title="Delete Education Item"
                                  >
                                    <Trash size={12} />
                                  </button>
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                  <div className="space-y-1">
                                    <label className="text-[9px] font-mono uppercase tracking-widest text-slate-500 font-bold block">DEGREE / STUDY</label>
                                    <input 
                                      type="text"
                                      value={edu.degree || ""}
                                      onChange={(e) => handleEducationChange(eduIdx, "degree", e.target.value)}
                                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white font-bold"
                                      placeholder="e.g. Bachelor of Design (B.Des)"
                                    />
                                  </div>

                                  <div className="space-y-1">
                                    <label className="text-[9px] font-mono uppercase tracking-widest text-slate-500 font-bold block">INSTITUTION / SCHOOL</label>
                                    <input 
                                      type="text"
                                      value={edu.school || ""}
                                      onChange={(e) => handleEducationChange(eduIdx, "school", e.target.value)}
                                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white"
                                      placeholder="e.g. National Institute of Design"
                                    />
                                  </div>

                                  <div className="space-y-1">
                                    <label className="text-[9px] font-mono uppercase tracking-widest text-slate-500 font-bold block">YEAR / PERIOD</label>
                                    <input 
                                      type="text"
                                      value={edu.year || ""}
                                      onChange={(e) => handleEducationChange(eduIdx, "year", e.target.value)}
                                      className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white"
                                      placeholder="e.g. 2017 - 2021"
                                    />
                                  </div>
                                </div>
                              </div>
                            ))
                          )}
                        </div>
                      </div>

                      {/* SOFTWARE TOOLS & CAPABILITIES SECTION */}
                      <div className="space-y-4 pt-6 border-t border-slate-900">
                        <div className="flex justify-between items-center">
                          <div className="space-y-1">
                            <span className="text-[10px] font-mono text-sky-400 uppercase tracking-widest font-bold">SOFTWARE TOOLS</span>
                            <h3 className="text-lg font-bold text-white">SOFTWARE & CAD CAPABILITIES</h3>
                          </div>
                          <button
                            type="button"
                            onClick={handleAddSoftware}
                            className="px-4 py-2 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-sky-400 hover:text-sky-300 rounded-xl text-xs font-mono font-bold tracking-wider flex items-center gap-2 transition-colors cursor-pointer"
                          >
                            <Plus size={14} /> ADD SOFTWARE TOOL
                          </button>
                        </div>

                        <div className="space-y-4">
                          {(cmsData.profile.software || []).length === 0 ? (
                            <div className="bg-slate-900/50 border border-slate-800/80 rounded-2xl p-8 text-center">
                              <Laptop className="mx-auto text-slate-600 mb-2" size={24} />
                              <p className="text-xs text-slate-400 font-mono">No software tools defined yet.</p>
                            </div>
                          ) : (
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              {(cmsData.profile.software || []).map((soft, softIdx) => (
                                <div key={softIdx} className="bg-slate-900 border border-slate-800/80 p-4 rounded-2xl space-y-3 relative group">
                                  <div className="absolute top-4 right-4 flex items-center gap-1.5 opacity-60 group-hover:opacity-100 transition-opacity">
                                    <button
                                      type="button"
                                      disabled={softIdx === 0}
                                      onClick={() => handleMoveSoftware(softIdx, "up")}
                                      className="p-1 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 disabled:text-slate-700 hover:text-white rounded transition-colors cursor-pointer disabled:cursor-not-allowed"
                                      title="Move Up"
                                    >
                                      <ArrowUp size={11} />
                                    </button>
                                    <button
                                      type="button"
                                      disabled={softIdx === (cmsData.profile.software || []).length - 1}
                                      onClick={() => handleMoveSoftware(softIdx, "down")}
                                      className="p-1 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 disabled:text-slate-700 hover:text-white rounded transition-colors cursor-pointer disabled:cursor-not-allowed"
                                      title="Move Down"
                                    >
                                      <ArrowDown size={11} />
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => handleDeleteSoftware(softIdx)}
                                      className="p-1.5 bg-red-950/20 hover:bg-red-950/40 border border-red-900/30 text-red-400 hover:text-red-300 rounded transition-colors cursor-pointer"
                                      title="Delete Software"
                                    >
                                      <Trash size={11} />
                                    </button>
                                  </div>

                                  <div className="space-y-2 pr-16">
                                    <div className="space-y-1">
                                      <label className="text-[9px] font-mono uppercase tracking-widest text-slate-500 font-bold block">TOOL / CAPABILITY NAME</label>
                                      <input 
                                        type="text"
                                        value={soft.name || ""}
                                        onChange={(e) => handleSoftwareChange(softIdx, "name", e.target.value)}
                                        className="w-full px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white font-bold"
                                        placeholder="e.g. SOLIDWORKS"
                                      />
                                    </div>

                                    <div className="grid grid-cols-2 gap-2">
                                      <div className="space-y-1">
                                        <label className="text-[9px] font-mono uppercase tracking-widest text-slate-500 font-bold block">CATEGORY</label>
                                        <select
                                          value={soft.category || "CAD"}
                                          onChange={(e) => handleSoftwareChange(softIdx, "category", e.target.value)}
                                          className="w-full px-2 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-300 font-bold"
                                        >
                                          <option value="CAD">CAD</option>
                                          <option value="Rendering">Rendering</option>
                                          <option value="Adobe">Adobe CC</option>
                                          <option value="Prototyping">Prototyping</option>
                                          <option value="Other">Other</option>
                                        </select>
                                      </div>

                                      <div className="space-y-1">
                                        <label className="text-[9px] font-mono uppercase tracking-widest text-slate-500 font-bold block">PROFICIENCY ({soft.level}%)</label>
                                        <input 
                                          type="range"
                                          min={0}
                                          max={100}
                                          value={soft.level || 0}
                                          onChange={(e) => handleSoftwareChange(softIdx, "level", parseInt(e.target.value))}
                                          className="w-full h-1.5 bg-slate-950 rounded-lg appearance-none cursor-pointer accent-sky-400 mt-2.5"
                                        />
                                      </div>
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* CORE SPECIALTIES & SKILLS SECTION */}
                      <div className="space-y-4 pt-6 border-t border-slate-900">
                        <div className="flex justify-between items-center">
                          <div className="space-y-1">
                            <span className="text-[10px] font-mono text-sky-400 uppercase tracking-widest font-bold">CORE SKILLS</span>
                            <h3 className="text-lg font-bold text-white">PORTFOLIO SPECIALTIES & CORE SKILLS</h3>
                          </div>
                          <button
                            type="button"
                            onClick={handleAddSkill}
                            className="px-4 py-2 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-sky-400 hover:text-sky-300 rounded-xl text-xs font-mono font-bold tracking-wider flex items-center gap-2 transition-colors cursor-pointer"
                          >
                            <Plus size={14} /> ADD SPECIALTY
                          </button>
                        </div>

                        <div className="space-y-2">
                          {(cmsData.profile.skills || []).length === 0 ? (
                            <div className="bg-slate-900/50 border border-slate-800/80 rounded-2xl p-8 text-center">
                              <Wrench className="mx-auto text-slate-600 mb-2" size={24} />
                              <p className="text-xs text-slate-400 font-mono">No skills defined yet.</p>
                            </div>
                          ) : (
                            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
                              {(cmsData.profile.skills || []).map((skill, skIdx) => (
                                <div key={skIdx} className="flex gap-2 items-center bg-slate-900 border border-slate-800/80 px-3 py-2 rounded-xl">
                                  <input 
                                    type="text"
                                    value={skill || ""}
                                    onChange={(e) => handleSkillChange(skIdx, e.target.value)}
                                    className="flex-1 px-2.5 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white"
                                    placeholder="e.g. Ergonomics Design"
                                  />
                                  <button
                                    type="button"
                                    onClick={() => handleDeleteSkill(skIdx)}
                                    className="p-1.5 bg-red-950/20 hover:bg-red-950/40 border border-red-900/30 text-red-400 hover:text-red-300 rounded transition-colors cursor-pointer"
                                    title="Delete Skill"
                                  >
                                    <Trash size={12} />
                                  </button>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>

                      {/* DIGITAL SOCIAL LINKS SECTION */}
                      <div className="space-y-4 pt-6 border-t border-slate-900">
                        <div className="flex justify-between items-center">
                          <div className="space-y-1">
                            <span className="text-[10px] font-mono text-sky-400 uppercase tracking-widest font-bold">DIGITAL CHANNELS</span>
                            <h3 className="text-lg font-bold text-white">SOCIAL CHANNELS & EXTERNAL LINKS</h3>
                          </div>
                          <button
                            type="button"
                            onClick={handleAddSocial}
                            className="px-4 py-2 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-sky-400 hover:text-sky-300 rounded-xl text-xs font-mono font-bold tracking-wider flex items-center gap-2 transition-colors cursor-pointer"
                          >
                            <Plus size={14} /> ADD SOCIAL LINK
                          </button>
                        </div>

                        <div className="space-y-4">
                          {(cmsData.profile.socials || []).length === 0 ? (
                            <div className="bg-slate-900/50 border border-slate-800/80 rounded-2xl p-8 text-center">
                              <Globe className="mx-auto text-slate-600 mb-2" size={24} />
                              <p className="text-xs text-slate-400 font-mono">No digital channels defined yet.</p>
                            </div>
                          ) : (
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                              {(cmsData.profile.socials || []).map((soc, socIdx) => (
                                <div key={socIdx} className="bg-slate-900 border border-slate-800/80 p-4 rounded-2xl space-y-3 relative group">
                                  <div className="absolute top-4 right-4 flex items-center gap-1.5 opacity-60 group-hover:opacity-100 transition-opacity">
                                    <button
                                      type="button"
                                      disabled={socIdx === 0}
                                      onClick={() => handleMoveSocial(socIdx, "up")}
                                      className="p-1 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 disabled:text-slate-700 hover:text-white rounded transition-colors cursor-pointer disabled:cursor-not-allowed"
                                      title="Move Up"
                                    >
                                      <ArrowUp size={11} />
                                    </button>
                                    <button
                                      type="button"
                                      disabled={socIdx === (cmsData.profile.socials || []).length - 1}
                                      onClick={() => handleMoveSocial(socIdx, "down")}
                                      className="p-1 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 disabled:text-slate-700 hover:text-white rounded transition-colors cursor-pointer disabled:cursor-not-allowed"
                                      title="Move Down"
                                    >
                                      <ArrowDown size={11} />
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => handleDeleteSocial(socIdx)}
                                      className="p-1.5 bg-red-950/20 hover:bg-red-950/40 border border-red-900/30 text-red-400 hover:text-red-300 rounded transition-colors cursor-pointer"
                                      title="Delete Social Channel"
                                    >
                                      <Trash size={11} />
                                    </button>
                                  </div>

                                  <div className="space-y-2 pr-16">
                                    <div className="space-y-1">
                                      <label className="text-[9px] font-mono uppercase tracking-widest text-slate-500 font-bold block">PLATFORM NAME</label>
                                      <input 
                                        type="text"
                                        value={soc.name || ""}
                                        onChange={(e) => handleSocialChange(socIdx, "name", e.target.value)}
                                        className="w-full px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white font-bold"
                                        placeholder="e.g. LinkedIn"
                                      />
                                    </div>

                                    <div className="space-y-1">
                                      <label className="text-[9px] font-mono uppercase tracking-widest text-slate-500 font-bold block">REDIRECT URL</label>
                                      <input 
                                        type="text"
                                        value={soc.url || ""}
                                        onChange={(e) => handleSocialChange(socIdx, "url", e.target.value)}
                                        className="w-full px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-xs text-slate-300 font-mono"
                                        placeholder="e.g. https://linkedin.com/in/pawan"
                                      />
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  )}

                  {/* TAB 4: METHODOLOGY STAGES */}
                  {activeTab === "stages" && (
                    <div className="space-y-6">
                      <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
                        <div className="space-y-1">
                          <span className="text-[10px] font-mono text-blue-400 uppercase tracking-widest font-bold">METHODOLOGY FLOW</span>
                          <h2 className="text-2xl font-black text-white">DESIGN TIMELINE METHODOLOGY</h2>
                        </div>
                        <button
                          type="button"
                          onClick={handleAddStage}
                          className="px-4 py-2.5 bg-slate-900 hover:bg-slate-850 border border-slate-800 text-sky-400 hover:text-sky-300 rounded-xl text-xs font-mono font-bold tracking-wider flex items-center gap-2 transition-colors cursor-pointer"
                        >
                          <Plus size={14} /> ADD NEW STAGE
                        </button>
                      </div>

                      <div className="space-y-4">
                        {(cmsData.stages || []).length === 0 ? (
                          <div className="bg-slate-900/50 border border-slate-800/80 rounded-2xl p-8 text-center">
                            <Workflow className="mx-auto text-slate-600 mb-2" size={24} />
                            <p className="text-xs text-slate-400 font-mono">No methodology stages defined yet.</p>
                            <p className="text-[10px] text-slate-600 font-mono mt-1">Click the "ADD NEW STAGE" button above to add one.</p>
                          </div>
                        ) : (
                          (cmsData.stages || []).map((stg, i) => (
                            <div key={stg.id} className="bg-slate-900 border border-slate-800 p-5 rounded-2xl space-y-4 relative group">
                              {/* Stage Reordering & Deletion Overlay */}
                              <div className="absolute top-4 right-4 flex items-center gap-1.5 opacity-60 group-hover:opacity-100 transition-opacity">
                                <button
                                  type="button"
                                  disabled={i === 0}
                                  onClick={() => handleMoveStage(i, "up")}
                                  className="p-1 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 disabled:text-slate-700 hover:text-white rounded transition-colors cursor-pointer disabled:cursor-not-allowed"
                                  title="Move Stage Up"
                                >
                                  <ArrowUp size={11} />
                                </button>
                                <button
                                  type="button"
                                  disabled={i === (cmsData.stages || []).length - 1}
                                  onClick={() => handleMoveStage(i, "down")}
                                  className="p-1 bg-slate-950 hover:bg-slate-800 border border-slate-800 text-slate-400 disabled:text-slate-700 hover:text-white rounded transition-colors cursor-pointer disabled:cursor-not-allowed"
                                  title="Move Stage Down"
                                >
                                  <ArrowDown size={11} />
                                </button>
                                <button
                                  type="button"
                                  onClick={() => handleDeleteStage(i)}
                                  className="p-1.5 bg-red-950/20 hover:bg-red-950/40 border border-red-900/30 text-red-400 hover:text-red-300 rounded transition-colors cursor-pointer"
                                  title="Delete Stage"
                                >
                                  <Trash size={11} />
                                </button>
                              </div>

                              <div className="grid grid-cols-1 md:grid-cols-12 gap-4 items-start pr-20 md:pr-24">
                                <div className="md:col-span-4 space-y-1">
                                  <span className="text-[10px] font-mono text-sky-400 uppercase tracking-widest font-bold">STAGE {String(i + 1).padStart(2, "0")} (ID: {stg.id})</span>
                                  <input 
                                    type="text" 
                                    value={stg.title}
                                    onChange={(e) => handleStageChange(i, "title", e.target.value)}
                                    className="w-full px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-xs font-bold text-white uppercase" 
                                  />
                                </div>
                                <div className="md:col-span-8 space-y-1">
                                  <label className="text-[9px] font-mono uppercase tracking-widest text-slate-500 font-bold block">DESCRIPTION</label>
                                  <textarea 
                                    value={stg.description}
                                    onChange={(e) => handleStageChange(i, "description", e.target.value)}
                                    rows={2}
                                    className="w-full px-3 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs text-slate-300 font-mono leading-relaxed" 
                                  />
                                </div>
                              </div>

                              {/* Stage Deliverables & Artifacts list */}
                              <div className="space-y-2.5 pt-3 border-t border-slate-950">
                                <div className="flex justify-between items-center">
                                  <span className="text-[9px] font-mono uppercase tracking-widest text-slate-400 font-bold block">Artifacts & Deliverables</span>
                                  <button
                                    type="button"
                                    onClick={() => handleAddStageDetail(i)}
                                    className="px-2.5 py-1 bg-slate-950 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 text-sky-400 text-[10px] font-mono font-bold tracking-wider rounded-lg flex items-center gap-1.5 transition-colors cursor-pointer"
                                  >
                                    <Plus size={11} /> ADD ITEM
                                  </button>
                                </div>

                                <div className="space-y-2">
                                  {(stg.details || []).map((det, dIdx) => (
                                    <div key={dIdx} className="flex gap-2 items-center">
                                      <input
                                        type="text"
                                        value={det}
                                        onChange={(e) => handleStageDetailChange(i, dIdx, e.target.value)}
                                        className="flex-1 px-3 py-1.5 bg-slate-950 border border-slate-850 rounded-lg text-xs text-slate-300"
                                        placeholder="Deliverable item description..."
                                      />
                                      <button
                                        type="button"
                                        disabled={dIdx === 0}
                                        onClick={() => handleMoveStageDetail(i, dIdx, "up")}
                                        className="p-1 bg-slate-950 hover:bg-slate-800 border border-slate-850 text-slate-500 hover:text-white rounded disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
                                        title="Move Up"
                                      >
                                        <ArrowUp size={11} />
                                      </button>
                                      <button
                                        type="button"
                                        disabled={dIdx === (stg.details || []).length - 1}
                                        onClick={() => handleMoveStageDetail(i, dIdx, "down")}
                                        className="p-1 bg-slate-950 hover:bg-slate-800 border border-slate-850 text-slate-500 hover:text-white rounded disabled:opacity-30 disabled:cursor-not-allowed cursor-pointer"
                                        title="Move Down"
                                      >
                                        <ArrowDown size={11} />
                                      </button>
                                      <button
                                        type="button"
                                        onClick={() => handleDeleteStageDetail(i, dIdx)}
                                        className="p-1.5 bg-red-950/20 hover:bg-red-950/40 border border-red-900/30 text-red-400 hover:text-red-300 rounded cursor-pointer"
                                        title="Delete Item"
                                      >
                                        <Trash size={11} />
                                      </button>
                                    </div>
                                  ))}
                                  {(stg.details || []).length === 0 && (
                                    <p className="text-[10px] text-slate-500 italic font-mono pl-1">No artifact details defined. Click ADD ITEM above.</p>
                                  )}
                                </div>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  )}

                  {/* TAB 5: CENTRALIZED MEDIA LIBRARY */}
                  {activeTab === "media" && (
                    <div className="space-y-6">
                      <div className="flex flex-col sm:flex-row gap-4 justify-between items-start sm:items-center">
                        <div className="space-y-1">
                          <span className="text-[10px] font-mono text-blue-400 uppercase tracking-widest font-bold">ASSET DIRECTORY MANAGER</span>
                          <h2 className="text-2xl font-black text-white">CENTRALIZED MEDIA LIBRARY</h2>
                        </div>

                        {/* File Upload Trigger */}
                        <label className="px-5 py-3.5 bg-sky-500 hover:bg-sky-600 text-slate-950 rounded-xl font-mono text-xs tracking-wider font-bold flex items-center justify-center gap-2.5 transition-all cursor-pointer shadow-lg">
                          <Upload size={14} /> CHOOSE / UPLOAD MEDIA
                          <input 
                            type="file" 
                            multiple 
                            accept="image/*,video/*,application/pdf"
                            onChange={handleMediaUpload}
                            className="hidden" 
                          />
                        </label>
                      </div>

                      {/* Folder filters row */}
                      <div className="flex flex-col sm:flex-row gap-4 justify-between bg-slate-900 border border-slate-800 p-4 rounded-2xl">
                        <div className="flex flex-wrap gap-2">
                          <button 
                            onClick={() => setMediaFolder("all")}
                            className={`px-3 py-1.5 rounded-lg font-mono text-[10px] tracking-wider transition-all cursor-pointer ${mediaFolder === "all" ? "bg-slate-800 text-white font-bold" : "text-slate-400 hover:text-white"}`}
                          >
                            All Files
                          </button>
                          <button 
                            onClick={() => setMediaFolder("images")}
                            className={`px-3 py-1.5 rounded-lg font-mono text-[10px] tracking-wider transition-all cursor-pointer ${mediaFolder === "images" ? "bg-slate-800 text-white font-bold" : "text-slate-400 hover:text-white"}`}
                          >
                            Images
                          </button>
                          <button 
                            onClick={() => setMediaFolder("videos")}
                            className={`px-3 py-1.5 rounded-lg font-mono text-[10px] tracking-wider transition-all cursor-pointer ${mediaFolder === "videos" ? "bg-slate-800 text-white font-bold" : "text-slate-400 hover:text-white"}`}
                          >
                            Videos
                          </button>
                          <button 
                            onClick={() => setMediaFolder("pdfs")}
                            className={`px-3 py-1.5 rounded-lg font-mono text-[10px] tracking-wider transition-all cursor-pointer ${mediaFolder === "pdfs" ? "bg-slate-800 text-white font-bold" : "text-slate-400 hover:text-white"}`}
                          >
                            PDFs / Blueprints
                          </button>
                        </div>

                        {/* Search field */}
                        <div className="relative">
                          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" size={13} />
                          <input 
                            type="text" 
                            placeholder="Search library..."
                            value={mediaSearch}
                            onChange={(e) => setMediaSearch(e.target.value)}
                            className="pl-8 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-lg text-xs text-white placeholder-slate-600 focus:outline-hidden font-mono"
                          />
                        </div>
                      </div>

                      {/* Bulk controls */}
                      {bulkSelected.length > 0 && (
                        <div className="flex justify-between items-center bg-red-950/15 border border-red-900/30 p-3.5 rounded-xl text-xs font-mono text-red-400">
                          <span>{bulkSelected.length} assets marked for removal</span>
                          <button onClick={handleBulkDelete} className="px-3 py-1.5 bg-red-900/10 hover:bg-red-900 text-red-400 hover:text-white rounded border border-red-500/20 transition-all cursor-pointer">
                            REMOVE BULK
                          </button>
                        </div>
                      )}

                      {/* Active simulation upload progress lists */}
                      {Object.keys(uploadProgress).length > 0 && (
                        <div className="space-y-2 bg-slate-900/50 p-4 border border-slate-800 rounded-2xl">
                          <span className="text-[10px] font-mono text-sky-400 uppercase font-bold block mb-1">Active Transfers:</span>
                          {Object.entries(uploadProgress).map(([fileName, progress]) => (
                            <div key={fileName} className="flex flex-col gap-1 text-[10px] font-mono">
                              <div className="flex justify-between text-slate-400">
                                <span className="truncate max-w-xs">{fileName}</span>
                                <span>{progress}%</span>
                              </div>
                              <div className="w-full h-1 bg-slate-950 rounded-full overflow-hidden">
                                <div className="h-full bg-sky-400 transition-all duration-300" style={{ width: `${progress}%` }} />
                              </div>
                            </div>
                          ))}
                        </div>
                      )}

                      {/* Media Assets list cards */}
                      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                        {filteredMedia.length === 0 ? (
                          <div className="col-span-full border border-dashed border-slate-800 p-12 text-center rounded-2xl">
                            <Folder size={32} className="text-slate-700 mx-auto mb-3" />
                            <p className="text-xs text-slate-500 font-mono">No matching media files in folder.</p>
                          </div>
                        ) : (
                          filteredMedia.map((asset) => (
                            <div 
                              key={asset.id} 
                              className={`group bg-slate-900 border rounded-2xl overflow-hidden flex flex-col justify-between relative transition-all ${
                                bulkSelected.includes(asset.id) ? "border-red-500/50 ring-1 ring-red-500/20" : "border-slate-800 hover:border-slate-700"
                              }`}
                            >
                              {/* Selection overlay */}
                              <button 
                                onClick={() => toggleBulkSelect(asset.id)}
                                className="absolute left-3 top-3 z-10 p-1 bg-slate-950/80 border border-slate-800 rounded-lg text-slate-400 hover:text-white"
                              >
                                <CheckSquareIcon size={12} className={bulkSelected.includes(asset.id) ? "text-red-400" : ""} />
                              </button>

                              {/* Asset preview */}
                              <div className="aspect-square bg-slate-950 flex items-center justify-center relative overflow-hidden">
                                {asset.type.startsWith("image/") ? (
                                  <img src={asset.url} alt="" className="w-full h-full object-cover group-hover:scale-102 transition-transform" referrerPolicy="no-referrer" />
                                ) : asset.type.startsWith("video/") ? (
                                  <div className="space-y-1.5 text-center">
                                    <Video className="mx-auto text-yellow-500" size={24} />
                                    <span className="text-[9px] font-mono text-slate-500 uppercase block">VIDEO</span>
                                  </div>
                                ) : (
                                  <div className="space-y-1.5 text-center">
                                    <FileText className="mx-auto text-blue-400" size={24} />
                                    <span className="text-[9px] font-mono text-slate-500 uppercase block">PDF BLUEPRINT</span>
                                  </div>
                                )}
                              </div>

                              {/* Asset details bottom */}
                              <div className="p-3 bg-slate-900 space-y-2">
                                <p className="text-[10px] font-bold text-slate-300 truncate font-mono">{asset.name}</p>
                                <div className="flex justify-between items-center text-[9px] font-mono text-slate-500">
                                  <span>{(asset.size / 1024).toFixed(0)} KB</span>
                                  <button 
                                    onClick={() => {
                                      navigator.clipboard.writeText(asset.url);
                                      showToast("Copied asset link", "info");
                                    }}
                                    className="text-sky-400 hover:text-white"
                                  >
                                    LINK
                                  </button>
                                </div>

                                <button 
                                  onClick={() => handleDeleteMedia(asset.id)}
                                  className="w-full py-1 bg-red-950/10 hover:bg-red-950/30 text-red-400 hover:text-white border border-red-500/10 hover:border-red-500/25 rounded-lg text-[9px] uppercase tracking-wider font-bold transition-all cursor-pointer"
                                >
                                  DELETE FILE
                                </button>
                              </div>
                            </div>
                          ))
                        )}
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        )}
      </motion.div>

      {/* ASSET SELECTOR OVERLAY DRAWER PANEL */}
      <AnimatePresence>
        {isAssetSelectorOpen && (
          <div className="fixed inset-0 z-50 overflow-hidden bg-slate-950/90 backdrop-blur-md flex items-center justify-center p-6">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.95, opacity: 0 }}
              className="w-full max-w-4xl bg-slate-950 border border-slate-800 rounded-2xl h-[90vh] flex flex-col text-slate-100"
            >
              <header className="px-6 py-4 border-b border-slate-850 flex justify-between items-center">
                <div className="flex items-center gap-2">
                  <Folder className="text-yellow-400" size={16} />
                  <h3 className="text-sm font-mono tracking-wider font-black text-white">SELECT FROM MEDIA LIBRARY</h3>
                </div>
                <button onClick={() => setIsAssetSelectorOpen(false)} className="p-1 hover:bg-slate-900 border border-slate-800 rounded-lg text-slate-400 hover:text-white">
                  <X size={15} />
                </button>
              </header>

              <div className="flex-1 overflow-y-auto p-6 space-y-6">
                <div className="flex flex-col sm:flex-row gap-4 justify-between bg-slate-900 border border-slate-800 p-4 rounded-xl">
                  <div className="flex gap-2">
                    <button onClick={() => setMediaFolder("all")} className={`px-2.5 py-1 rounded text-[10px] font-mono ${mediaFolder === "all" ? "bg-slate-800 text-white" : "text-slate-400"}`}>All Files</button>
                    <button onClick={() => setMediaFolder("images")} className={`px-2.5 py-1 rounded text-[10px] font-mono ${mediaFolder === "images" ? "bg-slate-800 text-white" : "text-slate-400"}`}>Images</button>
                    <button onClick={() => setMediaFolder("videos")} className={`px-2.5 py-1 rounded text-[10px] font-mono ${mediaFolder === "videos" ? "bg-slate-800 text-white" : "text-slate-400"}`}>Videos</button>
                    <button onClick={() => setMediaFolder("pdfs")} className={`px-2.5 py-1 rounded text-[10px] font-mono ${mediaFolder === "pdfs" ? "bg-slate-800 text-white" : "text-slate-400"}`}>PDFs</button>
                  </div>
                  <input 
                    type="text" 
                    placeholder="Search files..."
                    value={mediaSearch}
                    onChange={(e) => setMediaSearch(e.target.value)}
                    className="px-3 py-1.5 bg-slate-950 border border-slate-800 rounded-lg text-xs"
                  />
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
                  {filteredMedia.map((asset) => (
                    <div 
                      key={asset.id} 
                      onClick={() => applySelectedAssetUrl(asset.url)}
                      className="group bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-sky-500/50 rounded-xl overflow-hidden cursor-pointer flex flex-col justify-between"
                    >
                      <div className="aspect-square bg-slate-950 flex items-center justify-center relative overflow-hidden">
                        {asset.type.startsWith("image/") ? (
                          <img src={asset.url} alt="" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                        ) : asset.type.startsWith("video/") ? (
                          <Video className="text-yellow-500" size={24} />
                        ) : (
                          <FileText className="text-blue-400" size={24} />
                        )}
                      </div>
                      <div className="p-2.5 bg-slate-900 border-t border-slate-850">
                        <p className="text-[10px] text-slate-300 font-bold truncate font-mono">{asset.name}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </div>
  );
}

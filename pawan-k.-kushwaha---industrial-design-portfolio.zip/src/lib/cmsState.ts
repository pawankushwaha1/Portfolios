import { CMSData, Profile, Project, DesignStage } from "../types";
import { initialCMSData } from "./seedData";

const STORAGE_KEY = "pawan_portfolio_cms_data";

export function getCMSData(): CMSData {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    if (stored) {
      const parsed = JSON.parse(stored);
      // Validate structure loosely to ensure compatibility
      if (parsed.profile && parsed.projects && parsed.stages) {
        return parsed as CMSData;
      }
    }
  } catch (e) {
    console.error("Failed to parse stored CMS data, falling back to seed data", e);
  }
  // Initialize storage if missing
  localStorage.setItem(STORAGE_KEY, JSON.stringify(initialCMSData));
  return initialCMSData;
}

export function saveCMSData(data: CMSData): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  } catch (e) {
    console.error("Failed to save CMS data to localStorage", e);
  }
}

export function resetCMSData(): CMSData {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(initialCMSData));
  } catch (e) {
    console.error("Failed to reset CMS data", e);
  }
  return initialCMSData;
}

export function exportCMSDataAsJSON(data: CMSData): void {
  const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(data, null, 2));
  const downloadAnchor = document.createElement("a");
  downloadAnchor.setAttribute("href", dataStr);
  downloadAnchor.setAttribute("download", `pawan-portfolio-cms-backup-${new Date().toISOString().split("T")[0]}.json`);
  document.body.appendChild(downloadAnchor);
  downloadAnchor.click();
  downloadAnchor.remove();
}

export function importCMSDataFromJSON(jsonString: string): CMSData | null {
  try {
    const parsed = JSON.parse(jsonString);
    if (parsed.profile && parsed.projects && parsed.stages) {
      saveCMSData(parsed);
      return parsed as CMSData;
    }
  } catch (e) {
    console.error("Failed to parse imported JSON string", e);
  }
  return null;
}

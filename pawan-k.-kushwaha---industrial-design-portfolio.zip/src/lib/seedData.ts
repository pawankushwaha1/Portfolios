import { CMSData } from "../types";

export const initialCMSData: CMSData = {
  profile: {
    name: "Pawan K. Kushwaha",
    title: "Industrial & Product Designer",
    tagline: "Designing physical products that bridge the gap between human intuition and elegant engineering.",
    bio: "I am a dedicated Industrial Designer specializing in user-centric product architecture, functional aesthetics, and Design for Manufacturing and Assembly (DFMA). My process is rooted in a deep understanding of materials, ergonomics, and modern manufacturing constraints. Over the years, I have collaborated with start-ups and leading research labs to translate complex technologies into intuitive, award-winning hardware experiences.",
    portraitUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=600&auto=format&fit=crop", // Elegant professional portrait representation
    resumeUrl: "#",
    email: "kushwahapawan9572@gmail.com",
    location: "Bangalore, India",
    socials: [
      { name: "LinkedIn", url: "https://linkedin.com/in/pawankushwaha" },
      { name: "Behance", url: "https://behance.net/pawankushwaha" },
      { name: "Instagram", url: "https://instagram.com/pawan.design" },
      { name: "Resume", url: "#" }
    ],
    software: [
      { name: "SolidWorks", level: 95, category: "CAD" },
      { name: "Autodesk Fusion 360", level: 90, category: "CAD" },
      { name: "Rhino 3D", level: 85, category: "CAD" },
      { name: "KeyShot", level: 92, category: "Rendering" },
      { name: "Blender", level: 80, category: "Rendering" },
      { name: "Adobe Photoshop", level: 88, category: "Adobe" },
      { name: "Adobe Illustrator", level: 85, category: "Adobe" },
      { name: "Figma (UI/UX)", level: 82, category: "Other" },
      { name: "3D Printing & Cura", level: 90, category: "Prototyping" }
    ],
    education: [
      {
        degree: "Bachelor of Design in Product & Industrial Design",
        school: "National Institute of Design (NID)",
        year: "2018 - 2022"
      },
      {
        degree: "Advanced Certification in Digital Sculpting & CAD",
        school: "Autodesk Design Academy",
        year: "2023"
      }
    ],
    experience: [
      {
        role: "Lead Industrial Designer",
        company: "Veloct Tech Labs",
        period: "2024 - Present",
        description: "Directing the hardware division to develop enterprise IoT systems and consumer electronics. Supervising product styling, mechanical integration, and factory handoffs for injection molding."
      },
      {
        role: "Product Designer",
        company: "Studio Minimal",
        period: "2022 - 2024",
        description: "Designed office accessories, custom furniture lines, and boutique electronics. Conducted extensive user research, hand sketching sessions, and rapid physical modeling with foam and 3D printing."
      },
      {
        role: "Industrial Design Intern",
        company: "Tata Elxsi",
        period: "2021",
        description: "Assisted the automotive and consumer product divisions. Contributed to interior ergonomic layout studies, visual branding directions, and CMF (Color, Material, Finish) specification sheets."
      }
    ],
    skills: [
      "User-Centered Design (UCD)",
      "Ergonomics & Anthropometry",
      "DFMA (Design for Manufacturing & Assembly)",
      "Injection Molding & Sheet Metal Design",
      "Rapid Foam & Clay Prototyping",
      "CMF (Color, Material, Finish) Selection",
      "FDM/SLA 3D Printing",
      "Interactive Hardware UI Integration",
      "High-Fidelity CAD Surface Modeling"
    ]
  },
  stages: [
    {
      id: "discover",
      title: "Discover & Observe",
      description: "Uncovering user frustrations and market gaps in the field.",
      details: [
        "In-depth user observations and behavioral shadowing.",
        "Identifying pain points, physical challenges, and contextual usage constraints.",
        "Market analysis, competitive reviews, and initial project framing."
      ]
    },
    {
      id: "research",
      title: "Research & Synthesis",
      description: "Validating user habits, materials, and ergonomic profiles.",
      details: [
        "Defining target anthropometric percentages (e.g., 5th to 95th percentile).",
        "Material testing, sustainability evaluations, and legislative constraint audits.",
        "Creating affinity maps, design personas, and engineering design specifications."
      ]
    },
    {
      id: "insights",
      title: "Core Insights",
      description: "Translating data into actionable product design requirements.",
      details: [
        "Establishing design principles: Simplicity, Repairability, Spatial Efficiency.",
        "Synthesizing primary criteria for interface layout and functional geometry.",
        "Formulating the 'How Might We' design direction statements."
      ]
    },
    {
      id: "concept",
      title: "Concept Generation",
      description: "Brainstorming and sketching initial layout and form variations.",
      details: [
        "Exploding forms through multi-view silhouettes and rough volumetric models.",
        "Exploring layout of internal PCBs, batteries, and mechanical interfaces.",
        "Rapid validation of conceptual form factors with core design stakeholders."
      ]
    },
    {
      id: "sketch",
      title: "Analog & Digital Sketching",
      description: "Refining form, proportions, and details through dynamic line work.",
      details: [
        "Hand sketching focus areas: joints, parting lines, and tactile controls.",
        "Digital sketch renders to communicate shadows, texture contrast, and light direction.",
        "Orthographic dimensioned orthographic line sheets to check scale boundaries."
      ]
    },
    {
      id: "cad",
      title: "High-Fidelity CAD Surface Modeling",
      description: "Building production-grade parametric surfaces and solid assemblies.",
      details: [
        "Creating G2 curvature-continuous fillets and clean parting surfaces.",
        "Designing internal snap fits, screw bosses, heat-stakes, and rib reinforcements.",
        "Draft angle analysis to guarantee smooth mold injection release."
      ]
    },
    {
      id: "prototype",
      title: "Physical Prototyping",
      description: "Translating digital mathematics into tangible, scale models.",
      details: [
        "Low-fidelity cardboard and high-density blue foam study models for volume check.",
        "3D printing high-resolution SLA/FDM component prototypes.",
        "Sanding, priming, and painting cosmetic prototypes to verify CMF."
      ]
    },
    {
      id: "testing",
      title: "Rigorous Functional Testing",
      description: "Putting prototypes into user hands and laboratory stress rigs.",
      details: [
        "Conducting usability testing sessions to identify blind spots in interaction.",
        "Analyzing physical stress, temperature dissipation, and hinge lifespans.",
        "Iterating mechanical fits and interface layout based on testing diagnostics."
      ]
    },
    {
      id: "manufacturing",
      title: "Manufacturing Transfer (DFM)",
      description: "Prepping files for tooling, material formulation, and assembly.",
      details: [
        "Creating 2D technical drawings with Geometric Dimensioning & Tolerancing (GD&T).",
        "Direct collaboration with tooling engineers, defining gate locations and weld lines.",
        "Supervising Golden Sample approvals and establishing Quality Control benchmarks."
      ]
    },
    {
      id: "reflection",
      title: "Lifecycle & Reflection",
      description: "Analyzing post-launch feedback and environmental footprint.",
      details: [
        "Reflecting on the product lifecycle, disassembly capability, and circularity.",
        "Gathering user reviews to inform Gen-2 hardware features and firmware updates.",
        "Assessing resource optimization and packaging waste reductions."
      ]
    }
  ],
  projects: [
    {
      id: "orbit-lamp",
      title: "Orbit Desk Lamp",
      category: "Furniture & Lighting",
      year: "2025",
      description: "A counterbalanced, dual-axis desk lamp embodying architectural minimalism and precise tactile control.",
      heroImage: "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?q=80&w=1200",
      featured: true,
      status: "published",
      role: "Lead Industrial Designer",
      timeline: "6 Months",
      tools: ["SolidWorks", "KeyShot", "Rapid Prototyping", "Anodized Aluminum Fabrication"],
      duration: "Sept 2024 - Feb 2025",
      team: "Solo Project (Supervised by Studio Minimal)",
      overview: "The Orbit Desk Lamp reimagines office illumination. Rather than hiding the mechanical parts, Orbit highlights them as kinetic sculpture. Built with aviation-grade anodized aluminum and carbon-fiber counterweights, it rotates seamlessly across two axes, providing targeted and ambient light on demand.",
      problem: "Traditional task lamps are either statically rigid, or utilize low-quality friction joints that droop over time. Additionally, cable routing is often an afterthought, creating visual clutter on premium, minimalist workspaces.",
      research: "I shadowed creative professionals, architects, and writers, noting how they adjusted their workspaces throughout the day. I found that user needs shifted from intense, high-concentration task lighting (drafting, sketching) to diffused, warm, ambient lighting (screen reading, brainstorming). This demanded a lamp that could transform instantly and hold its position with absolute stability.",
      insights: "1. The joint is the soul of the lamp: it must feel smooth, fluid, and self-locking without ugly thumb-screws.\n2. Invisible cable integration maintains architectural elegance.\n3. A tactile, analog dial feels more deliberate and luxury than a capacitive touch sensor on a plastic panel.",
      ideation: "I drafted over 40 sketches exploring counterbalance mechanisms. I drew inspiration from architectural cable-stayed bridges and fine horology. Initial foam models helped define the sweep of the counterweight arms and the precise volumetric scale of the LED head.",
      sketches: [
        "https://images.unsplash.com/photo-1513542789411-b6a5d4f31634?q=80&w=600",
        "https://images.unsplash.com/photo-1515564895776-c50729557a3e?q=80&w=600"
      ],
      cad: "Using SolidWorks, I designed a fully parametric assembly. I developed a custom hidden brass-clutch joint with self-lubricating Teflon washers, ensuring effortless motion that remains tight for over 50,000 cycles. I routed the braided power cable through the extruded aluminum tubes, hidden from view.",
      cadRenders: [
        "https://images.unsplash.com/photo-1542838132-92c53300491e?q=80&w=800",
        "https://images.unsplash.com/photo-1555041469-a586c61ea9bc?q=80&w=800"
      ],
      prototype: "I built five physical prototypes. The first was cardboard for raw scale. The third was 3D printed with weighted iron sand in the base. The final cosmetic model utilized CNC-machined 6061-T6 aluminum, which was hand-polished, sandblasted with glass beads, and sand-anodized in deep space gray.",
      prototypePhotos: [
        "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?q=80&w=600",
        "https://images.unsplash.com/photo-1581092580497-e0d23cbdf1dc?q=80&w=600"
      ],
      testing: "We tested the friction clutching with pneumatic rigs to simulate years of user adjustments. I also conducted a CMF study with five focus groups to determine the optimal sandblasting micron rating, selecting a ultra-fine bead that reduces fingerprint oils.",
      finalDesign: "The final product features a heavy circular cast-iron base, a fluid dual-arm linkage, and a light-guide panel that diffuses 95 CRI LEDs to eliminate glare. A knurled brass control knob at the joint base serves as the power switch and smooth dimming interface.",
      reflection: "Orbit taught me the balance of engineering tolerance and aesthetic minimalism. A half-millimeter variance in the hinge would completely break the smooth kinetic balance. Working closely with precision CNC operators expanded my understanding of design-for-machining.",
      gallery: [
        "https://images.unsplash.com/photo-1507473885765-e6ed057f782c?q=80&w=1200",
        "https://images.unsplash.com/photo-1533090161767-e6ffed986c88?q=80&w=800"
      ]
    },
    {
      id: "holocase",
      title: "HoloCase Medical Diagnostics",
      category: "Medical Device",
      year: "2024",
      description: "A rugged, handheld, non-invasive diagnostic scanner designed for emergency medical responders in extreme environments.",
      heroImage: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?q=80&w=1200",
      featured: true,
      status: "published",
      role: "Industrial & UX Designer",
      timeline: "8 Months",
      tools: ["Fusion 360", "Ergonomic Testing", "TPU Overmolding", "KeyShot Rendering"],
      duration: "Feb 2024 - Oct 2024",
      team: "Collaborative project with Veloct Tech Labs & Apex Health",
      overview: "HoloCase is a portable diagnostic terminal that allows EMTs to scan vital signs, pulmonary functions, and internal trauma using localized infrared spectroscopy. Built to survive an 8-foot drop onto solid concrete, the device merges medical-grade precision with severe environmental ruggedness.",
      problem: "Standard diagnostic gear is fragile, heavy, and requires dual-hand operation. In chaotic emergency zones (earthquakes, battlefield triage, alpine rescues), paramedics need a single-hand diagnostic system that operates with gloved hands under torrential rain or intense glare.",
      research: "We rode alongside emergency response teams for 48 hours. I observed paramedics dropping devices in mud, scrambling over wreckage, and struggling to read touchscreens in bright sunlight. I analyzed glove ergonomics and grip fatigue.",
      insights: "1. Tactile physical controls must override touch interfaces under cold/wet environments.\n2. Overmolded elastomeric bumpers must be strategically placed at high-impact corners.\n3. The handle must support multiple grip postures: pistol, trigger, and flat-rest.",
      ideation: "Initial sketches explored rugged industrial architectures resembling power tools rather than clinical electronics. I sculpted several high-density foam handles to test palm comfort and trigger reach for various hand sizes (5th percentile female to 95th percentile male).",
      sketches: [
        "https://images.unsplash.com/photo-1506784983877-45594efa4cbe?q=80&w=600",
        "https://images.unsplash.com/photo-1580234810907-b40315b76418?q=80&w=600"
      ],
      cad: "I constructed the CAD in Fusion 360 using a robust split-shell assembly. The main housing is polycarbonate-ABS (PC-ABS) for rigidity, overmolded with thermoplastic polyurethane (TPU) for impact absorption. All ports are sealed with integrated silicone gaskets, achieving IP67 dust and water rating.",
      cadRenders: [
        "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=800",
        "https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?q=80&w=800"
      ],
      prototype: "Prototypes were SLA printed with medical-grade resins. For the TPU grip, we used custom multi-material silicone molding to simulate the actual durometer (hardness) of the overmolded elastomeric handle. A functional weight-simulated core was added to test gravity balance.",
      prototypePhotos: [
        "https://images.unsplash.com/photo-1581092160607-ee22621dd758?q=80&w=600",
        "https://images.unsplash.com/photo-1576086213369-97a306d36557?q=80&w=600"
      ],
      testing: "We drop-tested housings from 3 meters onto concrete, tracking deformation via high-speed cameras. Paramedics verified the ergonomics in simulated cold conditions with thick arctic gloves, leading to a 15% increase in button spacing.",
      finalDesign: "HoloCase features an ultra-bright transflective display, a high-contrast safety yellow and graphite body, and a magnetic self-locating probe charging dock on the base. A physical mechanical dial cycles through primary vital tabs with loud, positive click feedback.",
      reflection: "Designing for high-stress safety applications requires setting aside personal aesthetic desires in favor of pure, absolute utility and cognitive clarity. Color contrast, visual hierarchy, and mechanical reliability are literally life-or-death parameters in this domain.",
      gallery: [
        "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?q=80&w=1200",
        "https://images.unsplash.com/photo-1530026405186-ed1ea0ac7a63?q=80&w=800"
      ]
    },
    {
      id: "onyx-chair",
      title: "Onyx Cantilever Chair",
      category: "Furniture & Interior",
      year: "2023",
      description: "A monobloc cantilever chair made from recycled glass-reinforced polymer, optimized for spine ergonomics and material circularity.",
      heroImage: "https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?q=80&w=1200",
      featured: true,
      status: "published",
      role: "Lead Product Designer",
      timeline: "5 Months",
      tools: ["Rhino 3D", "Finite Element Analysis (FEA)", "1:1 CNC Wood Prototyping"],
      duration: "May 2023 - Oct 2023",
      team: "Solo project in partnership with EcoForm Furnishings",
      overview: "Onyx is a modern cantilever chair that uses a single continuous loop of material to achieve natural mechanical flex. Constructed from 100% post-consumer recycled nylon reinforced with microscopic glass beads, the chair eliminates the need for steel frames or polyurethane foams, creating a beautifully circular furniture solution.",
      problem: "Traditional office and side chairs utilize multi-material assemblies (steel screws, wood cores, PU foam, textiles) that are virtually impossible to separate and recycle. Most end up in landfills. Additionally, static chairs cause lumbar fatigue by discouraging micromovements.",
      research: "I reviewed structural cantilever chairs throughout history, starting with Marcel Breuer and Verner Panton. I mapped pressure points on the seat and backrest using pressure-sensing mats across different sitting heights, tracking spinal alignment during passive leaning.",
      insights: "1. The chair must act as a natural spring, flexing slightly when the user shifts weight.\n2. The ribbing on the underside must provide strength only where required, keeping overall weight under 5.2 kg.\n3. The material must be 100% recyclable without downcycling.",
      ideation: "I drew Hundreds of continuous-profile lines, looking for a silhouette that balance structural strength with fluid, sweeping curves. I developed rapid wire and cardboard miniature models to see where the continuous loop would twist or buckle.",
      sketches: [
        "https://images.unsplash.com/photo-1513542789411-b6a5d4f31634?q=80&w=600",
        "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=600"
      ],
      cad: "Using Rhino and Grasshopper, I developed a generative ribbing pattern on the underside of the seat shell. I performed extensive Finite Element Analysis (FEA) to simulate 150 kg static loads and dynamic cyclic drop tests, moving material thickness from low-stress zones (2.5mm) to the high-stress rear bend (12mm) to optimize weight.",
      cadRenders: [
        "https://images.unsplash.com/photo-1586023492125-27b2c045efd7?q=80&w=800",
        "https://images.unsplash.com/photo-1505691938895-1758d7feb511?q=80&w=800"
      ],
      prototype: "I built a 1:1 scale wood-machined prototype on a large 5-axis CNC router to check ergonomics and physical deflection. Later, we built a full-scale composite model using fiberglass layups to replicate the deflection properties of the injection-molded glass-nylon blend.",
      prototypePhotos: [
        "https://images.unsplash.com/photo-1503174971373-b1f69850bded?q=80&w=600",
        "https://images.unsplash.com/photo-1531403009284-440f080d1e12?q=80&w=600"
      ],
      testing: "Physical testing involved cyclical fatigue rigs pushing down on the backrest with 100,000 repetitions. We identified a hairline fracture zone at the bottom junction, which we solved by widening the radiused blend from 15mm to 28mm.",
      finalDesign: "Onyx stands as an elegant sculpture in space. The matte textured surface highlights the organic transition from the razor-thin upper backrest to the deep structural curves underneath. The open backrest slot acts as an integrated handle.",
      reflection: "This project deepened my knowledge of polymer flows and mechanical stress. Working with FEA software forced me to understand the mathematical physics of structures, proving that true product beauty is often a direct result of engineering logic.",
      gallery: [
        "https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?q=80&w=1200",
        "https://images.unsplash.com/photo-1592078615290-033ee584e267?q=80&w=800"
      ]
    },
    {
      id: "aerovent",
      title: "AeroVent Desktop Air Purifier",
      category: "Consumer Appliance",
      year: "2023",
      description: "A compact, whisper-quiet desktop air purifier featuring a premium leather handle and an innovative 360° intake layout.",
      heroImage: "https://images.unsplash.com/photo-1585338107529-13afc5f02586?q=80&w=1200",
      featured: false,
      status: "published",
      role: "Industrial Designer",
      timeline: "4 Months",
      tools: ["SolidWorks", "Ansys Fluent CFD", "CMF Exploration", "3D Printing"],
      duration: "Jan 2023 - May 2023",
      team: "In-house project for Studio Minimal",
      overview: "AeroVent is a personal air purifier designed specifically for desktop environments, such as work desks and nightstands. Combining an elegant cylindrical aluminum housing with a high-efficiency HEPA H13 filter, AeroVent runs below 24dB, providing clean air silently without looking like an industrial appliance.",
      problem: "Most air purifiers are oversized, white plastic boxes that clutter living spaces. Desktop options often rely on weak, noisy fans and have inefficient single-direction intakes that limit performance.",
      research: "I analyzed noise frequencies and airflow drag. I discovered that high-pitched blade noise is what annoys users most. Additionally, I found that purifiers placed on tables are highly visible, meaning the materials must feel premium and textile-integrated rather than sterile and medical.",
      insights: "1. A cylindrical 360° air intake optimizes airflow volume in a compact footprint.\n2. Integrating acoustic foam baffles and a centrifugal impellor dampens high-frequency fan buzz.\n3. Utilizing premium, long-lasting tactile details (like genuine saddle leather and spun aluminum) shifts the product from an appliance to home decor.",
      ideation: "My sketches focused on simple geometric volumes—cylinders, cones, and spheres. I explored combining warm materials (beech wood bases, felt wraps) with cold metals. To test flow paths, I sketched several centrifugal impeller housings to find the tightest efficient scroll shape.",
      sketches: [
        "https://images.unsplash.com/photo-1513542789411-b6a5d4f31634?q=80&w=600",
        "https://images.unsplash.com/photo-1512290923902-8a9f81dc236c?q=80&w=600"
      ],
      cad: "Using Computational Fluid Dynamics (CFD) in Ansys, I designed a custom curved impeller blade system in SolidWorks. The outer shell features over 1,800 CNC-drilled intake micro-holes. I modeled internal snap closures that let users change the filter by simply twisting the rubberized base plate.",
      cadRenders: [
        "https://images.unsplash.com/photo-1518770660439-4636190af475?q=80&w=800",
        "https://images.unsplash.com/photo-1581092335397-9583fe92d232?q=80&w=800"
      ],
      prototype: "I 3D printed multiple intake hole configurations to test acoustic whistle. The final prototype featured a precision-spun aluminum cylinder that was clear-anodized, integrated with a genuine hand-stitched tan leather strap secured by knurled brass rivets.",
      prototypePhotos: [
        "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?q=80&w=600",
        "https://images.unsplash.com/photo-1581092160562-40aa08e78837?q=80&w=600"
      ],
      testing: "We tested airflow rate (Clean Air Delivery Rate, CADR) inside a sealed smoke chamber. AeroVent cleared 99.97% of airborne particles in 12 minutes, while keeping its noise profile below a quiet library level (22dB in Eco Mode).",
      finalDesign: "AeroVent is a masterpiece of compact CMF. The silver-anodized spun aluminum top panel houses a smooth glowing LED touch indicator. The contrasting saddle-leather handle allows easy transport between rooms, and the soft rubber base dampens motor vibrations.",
      reflection: "Consumer appliances represent a complex intersection of thermodynamics, acoustics, and interior fashion. AeroVent proved that a product can perform exceptionally well without shouting, and that premium tactile details make a massive emotional difference in consumer acceptance.",
      gallery: [
        "https://images.unsplash.com/photo-1585338107529-13afc5f02586?q=80&w=1200",
        "https://images.unsplash.com/photo-1542838132-92c53300491e?q=80&w=800"
      ]
    }
  ]
};

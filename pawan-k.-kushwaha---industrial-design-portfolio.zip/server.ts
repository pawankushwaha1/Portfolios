import express from "express";
import path from "path";
import fs from "fs";
import crypto from "crypto";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const PORT = 3000;

// Set high body limit for base64 file uploads up to 100MB (perfect for images and assets)
app.use(express.json({ limit: "100mb" }));
app.use(express.urlencoded({ limit: "100mb", extended: true }));

const DB_PATH = path.join(process.cwd(), "db.json");
const UPLOADS_DIR = path.join(process.cwd(), "uploads");

// Ensure uploads folder exists
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// Serve uploaded files statically at /uploads
app.use("/uploads", express.static(UPLOADS_DIR));

// Helper for loading/saving DB
function getDB() {
  if (!fs.existsSync(DB_PATH)) {
    // Generate default structure with a default admin user
    const defaultData = {
      users: [
        {
          id: "usr-1",
          email: "kushwahapawan.design@gmail.com",
          // sha256 hash for password "pawan@portfolio"
          passwordHash: "f6e5e54baad21dfcc929d9445de7f7552d6610d180c15dc38dfbb6f06b1bb8f9",
          name: "Pawan K. Kushwaha",
          role: "admin",
        },
      ],
      profile: {
        name: "Pawan K. Kushwaha",
        title: "Industrial & Product Designer",
        tagline: "Designing physical products that bridge the gap between human intuition and elegant engineering.",
        bio: "I am a dedicated Industrial Designer specializing in user-centric product architecture, functional aesthetics, and Design for Manufacturing and Assembly (DFMA). My process is rooted in a deep understanding of materials, ergonomics, and modern manufacturing constraints. Over the years, I have collaborated with start-ups and leading research labs to translate complex technologies into intuitive, award-winning hardware experiences.",
        portraitUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=600&auto=format&fit=crop",
        resumeUrl: "#",
        email: "kushwahapawan9572@gmail.com",
        location: "Bangalore, India",
        socials: [
          { name: "LinkedIn", url: "https://linkedin.com/in/pawankushwaha" },
          { name: "Behance", url: "https://behance.net/pawankushwaha" },
          { name: "Instagram", url: "https://instagram.com/pawan.design" },
          { name: "Resume", url: "#" }
        ],
        software: [
          { name: "SolidWorks", level: 95, category: "CAD" },
          { name: "Autodesk Fusion 360", level: 90, category: "CAD" },
          { name: "Rhino 3D", level: 85, category: "CAD" },
          { name: "KeyShot", level: 92, category: "Rendering" },
          { name: "Blender", level: 80, category: "Rendering" },
          { name: "Adobe Photoshop", level: 88, category: "Adobe" },
          { name: "Adobe Illustrator", level: 85, category: "Adobe" },
          { name: "Figma (UI/UX)", level: 82, category: "Other" },
          { name: "3D Printing & Cura", level: 90, category: "Prototyping" }
        ],
        education: [
          {
            degree: "Bachelor of Design in Product & Industrial Design",
            school: "National Institute of Design (NID)",
            year: "2018 - 2022"
          },
          {
            degree: "Advanced Certification in Digital Sculpting & CAD",
            school: "Autodesk Design Academy",
            year: "2023"
          }
        ],
        experience: [
          {
            role: "Lead Industrial Designer",
            company: "Veloct Tech Labs",
            period: "2024 - Present",
            description: "Directing the hardware division to develop enterprise IoT systems and consumer electronics. Supervising product styling, mechanical integration, and factory handoffs for injection molding."
          },
          {
            role: "Product Designer",
            company: "Studio Minimal",
            period: "2022 - 2024",
            description: "Designed office accessories, custom furniture lines, and boutique electronics. Conducted extensive user research, hand sketching sessions, and rapid physical modeling with foam and 3D printing."
          }
        ],
        skills: ["Form Giving", "Ergonomics", "Rapid Prototyping", "Design for Manufacturing", "DFMA", "KeyShot Rendering", "SolidWorks Parametric", "Catering & Materials Selection"]
      },
      projects: [],
      stages: [
        {
          id: "stage-1",
          title: "User Research & Context",
          description: "Analyzing target demographics, visual trends, spatial boundaries, and real-world user workflows.",
          details: ["Competitor benchmarking", "User persona maps", "Ergonomic workspace study", "CMF trend analysis"]
        },
        {
          id: "stage-2",
          title: "Form-Giving & Ideation",
          description: "Exploring aesthetic directions, scale volumes, and geometric profiles via rapid 2D hand sketches.",
          details: ["Thumbnails & sketch-passes", "Form-exploration boards", "Scale mockups in blue-foam", "Proportions validation"]
        },
        {
          id: "stage-3",
          title: "Mechanical CAD Styling",
          description: "Building production-grade parametric CAD in Solidworks with strict draft-angles and internal bosses.",
          details: ["A-class surface modeling", "Draft analysis for injection molding", "Wall thickness optimization", "Snap-fit mechanism testing"]
        },
        {
          id: "stage-4",
          title: "DFMA & Factory Delivery",
          description: "Compiling detailed 2D tolerance specification sheets, CMF charts, and factory-ready STEP files.",
          details: ["2D technical drawing package", "CMF spec formulation", "Bill of Materials (BOM)", "Tooling coordination"]
        }
      ],
      media: [],
      settings: {
        siteName: "Pawan K. Kushwaha Portfolio",
        analyticsId: "UA-LOCAL-CMS",
        theme: "dark",
        seoDescription: "Industrial & Product Design Portfolio of Pawan K. Kushwaha",
        seoKeywords: "Industrial Design, Product Design, NID, SolidWorks, KeyShot, CAD, Bangalore",
        storageProvider: "local",
      },
      analytics: {
        totalViews: 1420,
        totalSessions: 382,
        recentUploadsCount: 0,
        lastUpdated: new Date().toISOString(),
      },
    };
    
    // Attempt to load starting projects from frontend seedData if it exists
    try {
      const seedFilePath = path.join(process.cwd(), "src", "lib", "seedData.ts");
      if (fs.existsSync(seedFilePath)) {
        const fileContent = fs.readFileSync(seedFilePath, "utf-8");
        // Simple extraction of projects from the source code
        const pJsonMatch = fileContent.match(/projects:\s*(\[[\s\S]+?\]),\s*stages/);
        if (pJsonMatch && pJsonMatch[1]) {
          // Evaluating simple JSON inside typescript
          // We can replace imports, trailing commas, or load roughly
          const cleanProjectsText = pJsonMatch[1]
            .replace(/,\s*\]/g, "]")
            .replace(/,\s*\}/g, "}")
            .replace(/\/\/.*$/gm, ""); // strip comments
          try {
            // Evaluated clean JSON safely with standard regex or function constructor (safer inside dev app container)
            const resolvedProjects = new Function(`return ${cleanProjectsText}`)();
            if (Array.isArray(resolvedProjects)) {
              defaultData.projects = resolvedProjects;
            }
          } catch (e) {
            console.error("Soft fail parsing seed projects via evaluator, continuing with empty array", e);
          }
        }
      }
    } catch (e) {
      console.warn("Could not load seeds from seedData file", e);
    }

    fs.writeFileSync(DB_PATH, JSON.stringify(defaultData, null, 2), "utf-8");
  }
  return JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
}

function saveDB(data: any) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), "utf-8");
}

// In-memory sessions store
const sessions = new Map<string, { email: string; name: string; role: string; expires: number }>();

// Auth Middleware
function requireAuth(req: express.Request, res: express.Response, next: express.NextFunction) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ error: "Unauthorized. Missing token." });
  }
  const token = authHeader.substring(7);
  const session = sessions.get(token);
  if (!session || session.expires < Date.now()) {
    if (session) sessions.delete(token); // cleanup
    return res.status(401).json({ error: "Session expired or invalid. Please login again." });
  }
  
  // Extend session duration on active request
  session.expires = Date.now() + 2 * 60 * 60 * 1000; // +2 hours
  next();
}

// -------------------------------------------------------------
// API Endpoints
// -------------------------------------------------------------

// 1. Auth Login / Logout / Me
app.post("/api/auth/login", (req, res) => {
  const { email, password } = req.body;
  const db = getDB();
  
  const user = db.users.find((u: any) => u.email === email);
  if (!user) {
    return res.status(400).json({ error: "Invalid email or password" });
  }

  // Pure cryptographic SHA-256 password hash check
  const hash = crypto.createHash("sha256").update(password).digest("hex");
  if (hash !== user.passwordHash) {
    return res.status(400).json({ error: "Invalid email or password" });
  }

  // Create token
  const token = crypto.randomBytes(32).toString("hex");
  const sessionData = {
    email: user.email,
    name: user.name,
    role: user.role,
    expires: Date.now() + 2 * 60 * 60 * 1000, // 2 hours
  };
  
  sessions.set(token, sessionData);
  res.json({ token, user: { email: user.email, name: user.name, role: user.role } });
});

app.post("/api/auth/logout", (req, res) => {
  const authHeader = req.headers.authorization;
  if (authHeader && authHeader.startsWith("Bearer ")) {
    const token = authHeader.substring(7);
    sessions.delete(token);
  }
  res.json({ success: true, message: "Logged out successfully" });
});

app.get("/api/auth/me", (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith("Bearer ")) {
    return res.status(401).json({ loggedIn: false });
  }
  const token = authHeader.substring(7);
  const session = sessions.get(token);
  if (!session || session.expires < Date.now()) {
    return res.status(401).json({ loggedIn: false });
  }
  res.json({ loggedIn: true, user: { email: session.email, name: session.name, role: session.role } });
});

// 2. Fetch full CMS data package
app.get("/api/cms-data", (req, res) => {
  const db = getDB();
  
  // Track website analytics views silently on live load
  db.analytics.totalViews += 1;
  if (Math.random() > 0.8) {
    db.analytics.totalSessions += 1;
  }
  db.analytics.lastUpdated = new Date().toISOString();
  saveDB(db);

  // Exclude sensitive hashed passwords from payload
  const safeData = {
    profile: db.profile,
    projects: db.projects,
    stages: db.stages,
    media: db.media || [],
    settings: db.settings,
    analytics: db.analytics,
  };
  res.json(safeData);
});

// 2.5 Save full CMS data package
app.post("/api/cms-data", requireAuth, (req, res) => {
  const db = getDB();
  const { profile, projects, stages, media, settings } = req.body;
  
  if (profile) db.profile = profile;
  if (projects) db.projects = projects;
  if (stages) db.stages = stages;
  if (media) db.media = media;
  if (settings) db.settings = settings;
  
  saveDB(db);
  res.json({ success: true, message: "CMS data fully updated" });
});

// 3. Update Profile Data
app.put("/api/profile", requireAuth, (req, res) => {
  const db = getDB();
  db.profile = req.body;
  saveDB(db);
  res.json({ success: true, message: "Profile updated successfully", data: db.profile });
});

// 4. Update Stages Data
app.put("/api/stages", requireAuth, (req, res) => {
  const db = getDB();
  db.stages = req.body;
  saveDB(db);
  res.json({ success: true, message: "Design stages updated", data: db.stages });
});

// 5. Projects CRUD
app.get("/api/projects", (req, res) => {
  const db = getDB();
  res.json(db.projects);
});

app.get("/api/projects/:id", (req, res) => {
  const db = getDB();
  const project = db.projects.find((p: any) => p.id === req.params.id);
  if (!project) return res.status(404).json({ error: "Project not found" });
  res.json(project);
});

app.post("/api/projects", requireAuth, (req, res) => {
  const db = getDB();
  const newProject = {
    id: "proj-" + crypto.randomBytes(8).toString("hex"),
    title: req.body.title || "Untitled Project",
    category: req.body.category || "Industrial Design",
    year: req.body.year || new Date().getFullYear().toString(),
    description: req.body.description || "",
    heroImage: req.body.heroImage || "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?q=80&w=800&auto=format&fit=crop",
    featured: req.body.featured || false,
    status: req.body.status || "draft",
    role: req.body.role || "Lead Designer",
    timeline: req.body.timeline || "4 Weeks",
    tools: req.body.tools || [],
    duration: req.body.duration || "4 Weeks",
    team: req.body.team || "Solo Project",
    overview: req.body.overview || "",
    problem: req.body.problem || "",
    research: req.body.research || "",
    insights: req.body.insights || "",
    ideation: req.body.ideation || "",
    sketches: req.body.sketches || [],
    cad: req.body.cad || "",
    cadRenders: req.body.cadRenders || [],
    prototype: req.body.prototype || "",
    prototypePhotos: req.body.prototypePhotos || [],
    testing: req.body.testing || "",
    finalDesign: req.body.finalDesign || "",
    reflection: req.body.reflection || "",
    gallery: req.body.gallery || [],
    sections: req.body.sections || [],
    videoUrl: req.body.videoUrl || "",
    downloadUrl: req.body.downloadUrl || "",
  };
  
  db.projects.push(newProject);
  saveDB(db);
  res.status(201).json(newProject);
});

app.put("/api/projects/:id", requireAuth, (req, res) => {
  const db = getDB();
  const idx = db.projects.findIndex((p: any) => p.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: "Project not found" });
  
  db.projects[idx] = {
    ...db.projects[idx],
    ...req.body,
    id: req.params.id, // prevent id hijacking
  };
  
  saveDB(db);
  res.json(db.projects[idx]);
});

app.delete("/api/projects/:id", requireAuth, (req, res) => {
  const db = getDB();
  const filtered = db.projects.filter((p: any) => p.id !== req.params.id);
  if (filtered.length === db.projects.length) {
    return res.status(404).json({ error: "Project not found" });
  }
  db.projects = filtered;
  saveDB(db);
  res.json({ success: true, message: "Project deleted successfully" });
});

// Duplicate Project End Point
app.post("/api/projects/:id/duplicate", requireAuth, (req, res) => {
  const db = getDB();
  const projectToClone = db.projects.find((p: any) => p.id === req.params.id);
  if (!projectToClone) return res.status(404).json({ error: "Source project not found" });

  const duplicatedProject = {
    ...projectToClone,
    id: "proj-" + crypto.randomBytes(8).toString("hex"),
    title: `${projectToClone.title} (Copy)`,
    featured: false,
    status: "draft" as const,
  };

  db.projects.push(duplicatedProject);
  saveDB(db);
  res.status(201).json(duplicatedProject);
});

// 6. Central Media Asset Library Management
app.get("/api/media", (req, res) => {
  const db = getDB();
  res.json(db.media || []);
});

// Base64 Multi-Format Asset Uploader & Optimizer (JPG, PNG, WEBP, SVG, AVIF, MP4, PDFs up to 100MB)
app.post("/api/media/upload", requireAuth, (req, res) => {
  const { name, size, type, data, folder, projectAssociation } = req.body;
  if (!name || !type || !data) {
    return res.status(400).json({ error: "Invalid upload payload. Missing fields." });
  }

  try {
    // Decode base64 data
    const matches = data.match(/^data:([A-Za-z-+\/]+);base64,(.+)$/);
    let base64Body = data;
    if (matches && matches.length === 3) {
      base64Body = matches[2];
    }
    const buffer = Buffer.from(base64Body, "base64");

    // Clean filename and create unique hash prefix
    const ext = path.extname(name) || "." + type.split("/")[1] || ".bin";
    const baseName = path.basename(name, ext).replace(/[^a-zA-Z0-9]/g, "_");
    const uniqueName = `${crypto.randomBytes(4).toString("hex")}_${baseName}${ext}`;
    const filePath = path.join(UPLOADS_DIR, uniqueName);

    // Save actual file to Server Storage
    fs.writeFileSync(filePath, buffer);

    const assetUrl = `/uploads/${uniqueName}`;

    // Create relation asset record in database
    const db = getDB();
    if (!db.media) db.media = [];

    const newAsset = {
      id: "media-" + crypto.randomBytes(8).toString("hex"),
      name: name,
      url: assetUrl,
      size: size || buffer.length,
      type: type,
      uploadDate: new Date().toISOString(),
      projectAssociation: projectAssociation || "",
      tags: [folder || "Images"],
      folder: folder || "Images",
    };

    db.media.push(newAsset);
    db.analytics.recentUploadsCount = (db.analytics.recentUploadsCount || 0) + 1;
    saveDB(db);

    res.status(201).json(newAsset);
  } catch (error: any) {
    console.error("Upload error", error);
    res.status(500).json({ error: "Failed to write file to storage. " + error.message });
  }
});

// Update Media Record Details
app.put("/api/media/:id", requireAuth, (req, res) => {
  const db = getDB();
  if (!db.media) db.media = [];
  const idx = db.media.findIndex((m: any) => m.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: "Media item not found" });

  db.media[idx] = {
    ...db.media[idx],
    ...req.body,
    id: req.params.id,
  };

  saveDB(db);
  res.json(db.media[idx]);
});

// Delete Media Record and File on disk
app.delete("/api/media/:id", requireAuth, (req, res) => {
  const db = getDB();
  if (!db.media) db.media = [];
  const idx = db.media.findIndex((m: any) => m.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: "Media item not found" });

  const mediaItem = db.media[idx];
  
  // Remove file on disk if it is local
  if (mediaItem.url.startsWith("/uploads/")) {
    const filename = mediaItem.url.replace("/uploads/", "");
    const diskPath = path.join(UPLOADS_DIR, filename);
    if (fs.existsSync(diskPath)) {
      try {
        fs.unlinkSync(diskPath);
      } catch (err) {
        console.warn("Failed to delete physical file", diskPath, err);
      }
    }
  }

  db.media.splice(idx, 1);
  saveDB(db);
  res.json({ success: true, message: "Asset deleted completely" });
});

// Bulk Delete Media Files
app.post("/api/media/bulk-delete", requireAuth, (req, res) => {
  const { ids } = req.body;
  if (!ids || !Array.isArray(ids)) {
    return res.status(400).json({ error: "Invalid array of IDs" });
  }

  const db = getDB();
  if (!db.media) db.media = [];

  let count = 0;
  ids.forEach((id) => {
    const idx = db.media.findIndex((m: any) => m.id === id);
    if (idx !== -1) {
      const mediaItem = db.media[idx];
      // Disk delete
      if (mediaItem.url.startsWith("/uploads/")) {
        const filename = mediaItem.url.replace("/uploads/", "");
        const diskPath = path.join(UPLOADS_DIR, filename);
        if (fs.existsSync(diskPath)) {
          try {
            fs.unlinkSync(diskPath);
          } catch (err) {}
        }
      }
      db.media.splice(idx, 1);
      count++;
    }
  });

  saveDB(db);
  res.json({ success: true, message: `Successfully deleted ${count} assets` });
});

// Bulk Move Folder structure
app.post("/api/media/bulk-move", requireAuth, (req, res) => {
  const { ids, folder } = req.body;
  if (!ids || !Array.isArray(ids) || !folder) {
    return res.status(400).json({ error: "Invalid inputs" });
  }

  const db = getDB();
  if (!db.media) db.media = [];

  let count = 0;
  db.media = db.media.map((m: any) => {
    if (ids.includes(m.id)) {
      count++;
      return { ...m, folder, tags: Array.from(new Set([...m.tags, folder])) };
    }
    return m;
  });

  saveDB(db);
  res.json({ success: true, message: `Successfully moved ${count} items to folder ${folder}` });
});

// 7. Settings GET / PUT
app.get("/api/settings", (req, res) => {
  const db = getDB();
  res.json(db.settings || {});
});

app.put("/api/settings", requireAuth, (req, res) => {
  const db = getDB();
  db.settings = { ...(db.settings || {}), ...req.body };
  saveDB(db);
  res.json(db.settings);
});

// 8. Analytics
app.get("/api/analytics", (req, res) => {
  const db = getDB();
  res.json(db.analytics || {});
});

// -------------------------------------------------------------
// Vite dev middleware & production fallback router setup
// -------------------------------------------------------------
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    console.log("Setting up Vite developer middleware...");
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    // SPA Fallback for production hosting
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`CMS Engine Backend successfully listening on port ${PORT}`);
    console.log(`Credentials: email: kushwahapawan.design@gmail.com | password: pawan@portfolio`);
  });
}

startServer();
